"""
THERMO-X | ReportLab PDF Report Generator
Generates clean, professional PDF engineering calculation summaries.
"""

import io
from datetime import datetime
from typing import List, Dict, Any

from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    KeepTogether,
)


def generate_pdf_report_bytes(
    analysis_title: str,
    analysis_type: str,
    governing_equation: str,
    inputs: List[Dict[str, str]],
    results: List[Dict[str, str]],
    assumptions: List[str],
    interpretation: str,
) -> bytes:
    """
    Builds an in-memory PDF report buffer using ReportLab.
    """
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=36,
        leftMargin=36,
        topMargin=36,
        bottomMargin=36,
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "HeaderTitle",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=16,
        leading=20,
        textColor=colors.HexColor("#0f172a"),
    )
    subtitle_style = ParagraphStyle(
        "HeaderSub",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=9,
        leading=12,
        textColor=colors.HexColor("#64748b"),
    )
    section_style = ParagraphStyle(
        "SectionHeading",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=11,
        leading=14,
        textColor=colors.HexColor("#ea580c"),
        spaceBefore=10,
        spaceAfter=4,
    )
    body_style = ParagraphStyle(
        "Body",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=8.5,
        leading=11,
        textColor=colors.HexColor("#334155"),
    )
    eq_style = ParagraphStyle(
        "Equation",
        parent=styles["Normal"],
        fontName="Courier-Bold",
        fontSize=9,
        leading=11,
        textColor=colors.HexColor("#0f172a"),
    )

    story = []

    # Title block
    timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
    story.append(Paragraph("THERMO-X | Heat Transfer Analyser", title_style))
    story.append(Paragraph(f"Engineering-Grade Thermal Analysis Report &bull; {analysis_title} &bull; Generated: {timestamp}", subtitle_style))
    story.append(Spacer(1, 10))

    # Governing Equation box
    eq_data = [[Paragraph("<b>Governing Equation:</b>", body_style), Paragraph(governing_equation, eq_style)]]
    eq_table = Table(eq_data, colWidths=[120, 420])
    eq_table.setStyle(
        TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8fafc")),
            ("BOX", (0, 0), (-1, -1), 1, colors.HexColor("#cbd5e1")),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ])
    )
    story.append(eq_table)
    story.append(Spacer(1, 12))

    # 1. Inputs Table
    story.append(Paragraph("1. Operating & Boundary Parameters", section_style))
    input_data = [["Parameter Description", "Symbol", "Entered Value", "SI Unit"]]
    for inp in inputs:
        input_data.append([inp.get("name", ""), inp.get("symbol", ""), str(inp.get("value", "")), inp.get("unit", "")])

    inp_table = Table(input_data, colWidths=[200, 70, 150, 120])
    inp_table.setStyle(
        TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#334155")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.HexColor("#ffffff"), colors.HexColor("#f1f5f9")]),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
            ("ALIGN", (2, 1), (2, -1), "RIGHT"),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ])
    )
    story.append(inp_table)
    story.append(Spacer(1, 12))

    # 2. Results Table
    story.append(Paragraph("2. Computed Engineering Results", section_style))
    res_data = [["Parameter Description", "Symbol", "Calculated Value", "SI Unit", "Meaning"]]
    for res in results:
        res_data.append([
            res.get("parameter", ""),
            res.get("symbol", ""),
            str(res.get("value", "")),
            res.get("unit", ""),
            res.get("description", ""),
        ])

    res_table = Table(res_data, colWidths=[150, 60, 110, 60, 160])
    res_table.setStyle(
        TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#ea580c")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.HexColor("#ffffff"), colors.HexColor("#fff7ed")]),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#fed7aa")),
            ("ALIGN", (2, 1), (2, -1), "RIGHT"),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ])
    )
    story.append(res_table)
    story.append(Spacer(1, 12))

    # 3. Assumptions
    story.append(Paragraph("3. Governing Assumptions", section_style))
    for a in assumptions:
        story.append(Paragraph(f"&bull; {a}", body_style))
    story.append(Spacer(1, 10))

    # 4. Engineering Interpretation
    story.append(Paragraph("4. Engineering Interpretation & Insights", section_style))
    story.append(Paragraph(interpretation, body_style))
    story.append(Spacer(1, 14))

    # Disclaimer
    disclaimer_text = (
        "<b>DISCLAIMER:</b> THERMO-X is an educational and engineering analysis tool. "
        "Results should be independently verified before use in safety-critical, design-critical, or commercial applications."
    )
    story.append(Paragraph(disclaimer_text, subtitle_style))

    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()
