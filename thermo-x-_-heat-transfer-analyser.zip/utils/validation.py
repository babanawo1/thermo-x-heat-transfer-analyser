"""
THERMO-X | Validation Utilities
Physical consistency and bounds verification
"""

from typing import Tuple, List


def validate_positive(value: float, name: str) -> Tuple[bool, str]:
    """Validates that a physical parameter is strictly positive."""
    if value <= 0:
        return False, f"{name} must be strictly greater than zero (entered: {value})."
    return True, ""


def validate_temperature(t_kelvin: float, name: str) -> Tuple[bool, str]:
    """Validates temperature is above absolute zero."""
    if t_kelvin <= 0:
        return False, f"{name} must be strictly positive on the Kelvin scale (> 0 K, entered: {t_kelvin} K)."
    return True, ""


def validate_emissivity(eps: float) -> Tuple[bool, str]:
    """Validates surface emissivity is between 0 and 1."""
    if eps < 0.0 or eps > 1.0:
        return False, f"Emissivity must be between 0.0 and 1.0 (entered: {eps})."
    return True, ""
