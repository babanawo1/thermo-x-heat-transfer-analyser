# THERMO-X | Heat Transfer Analyser

**Engineering-grade thermal analysis for conduction, convection, radiation, heat exchangers, and thermal resistance networks with interactive visualizations, step-by-step substitutions, and report exports.**

---

## 🌟 Overview

**THERMO-X** is an interactive engineering application designed for thermal engineers, researchers, students, and educators. It provides deterministic, validated thermal calculations across five fundamental domains of heat transfer, coupled with interactive parameter tuning, dynamic visualizations, and exportable engineering reports in PDF and CSV formats.

All calculations strictly use standard **SI units** and adhere to rigorous thermodynamic boundary constraints.

---

## 🚀 Key Features

### 1. Conduction Analysis (Fourier's Law)
- **1D Steady-State Conduction**: Plane wall heat transfer $Q = \frac{k A (T_{hot} - T_{cold})}{L}$.
- **Material Preset Library**: Copper, Aluminum, Structural Steel, Glass, Concrete, Brick, Wood, Fiberglass, and Aerogel.
- **Dynamic Visualizer**: Interactive temperature gradient profile $T(x)$ through the solid layer.

### 2. Convection Analysis (Newton's Law of Cooling)
- **Fluid Boundary Exchange**: $Q = h A (T_{surface} - T_{\infty})$.
- **Convective Regimes**: Free convection in air, forced convection in air, forced convection in water, and boiling/condensation heat transfer.
- **Cooling vs. Heating Detection**: Automatically detects heat flow direction and computes convective boundary resistance $R_{conv} = \frac{1}{hA}$.

### 3. Radiation Analysis (Stefan-Boltzmann Law)
- **Net Radiative Exchange**: $Q_{rad} = \varepsilon \sigma A (T_{surface}^4 - T_{surroundings}^4)$ with $\sigma = 5.670374419 \times 10^{-8} \text{ W/m}^2\cdot\text{K}^4$.
- **Surface Presets**: Polished Silver, Polished Aluminum, Oxidized Copper, White Paint, Black Matte Paint, and Ideal Blackbody ($\varepsilon = 1.0$).
- **Non-Linear Characteristic Curve**: $T^4$ temperature sweep chart illustrating radiative power acceleration.

### 4. Heat Exchanger Analysis (LMTD & $\varepsilon$-NTU)
- **Flow Configurations**: Counter-Current and Parallel Flow.
- **Log Mean Temperature Difference (LMTD)**: Robust numerical singularity handling when $\Delta T_1 \approx \Delta T_2$ via analytical limit evaluation.
- **Energy Balances**: Hot stream duty $Q_h = \dot{m}_h C_{p,h} (T_{h,in} - T_{h,out})$ vs. Cold stream duty $Q_c = \dot{m}_c C_{p,c} (T_{c,out} - T_{c,in})$ with percentage discrepancy tracking.
- **Effectiveness-NTU Rating**: Computes $C_{min}$, $C_{max}$, capacity ratio $C_r$, maximum possible heat transfer $Q_{max}$, thermal effectiveness $\varepsilon$, and NTU.
- **Second Law Violation Warnings**: Traps temperature crossovers before computing invalid thermodynamic states.

### 5. Thermal Resistance Networks
- **Series Composite Walls**: Multi-layer combined solid conduction and fluid boundary convection.
- **Interface Temperature Computation**: Determines intermediate plane temperatures $T_i$ across all layers.
- **Resistance Distribution**: Identifies dominant insulating resistances and overall heat-transfer coefficient $U$.

### 6. Professional Reports & Exporting
- **PDF Reports**: Comprehensive engineering calculation sheets with governing formulas, input parameters, result tables, governing assumptions, and engineering interpretations.
- **CSV Data Logs**: Complete machine-readable data logs for spreadsheet integration and audit trails.

---

## 📐 Governing Equations Summary

| Domain | Governing Equation | Primary SI Unit |
| :--- | :--- | :--- |
| **Conduction** | $Q = \frac{k A \Delta T}{L} = \frac{\Delta T}{R_{cond}}$ | $\text{W}$ |
| **Convection** | $Q = h A (T_s - T_\infty) = \frac{\Delta T}{R_{conv}}$ | $\text{W}$ |
| **Radiation** | $Q_{rad} = \varepsilon \sigma A (T_s^4 - T_{surr}^4)$ | $\text{W}$ |
| **Heat Exchanger** | $Q = U A \text{LMTD}, \quad \text{LMTD} = \frac{\Delta T_1 - \Delta T_2}{\ln(\Delta T_1 / \Delta T_2)}$ | $\text{W}$ |
| **Resistance Network** | $R_{total} = \sum R_i, \quad Q = \frac{\Delta T_{total}}{R_{total}}$ | $\text{K/W}, \text{W}$ |

---

## 💻 Local Installation & Setup

### Prerequisites
- Python 3.9+ (or Node.js 18+ for the interactive Web build)

### Python / Streamlit Quickstart

1. **Clone the repository**:
   ```bash
   git clone https://github.com/your-username/thermo-x-heat-transfer-analyser.git
   cd thermo-x-heat-transfer-analyser
   ```

2. **Create and activate a virtual environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install required dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Launch the Streamlit Application**:
   ```bash
   streamlit run app.py
   ```

---

## ☁️ Deployment to Streamlit Community Cloud

1. Push this repository to **GitHub**.
2. Visit [share.streamlit.io](https://share.streamlit.io).
3. Connect your GitHub account and select this repository.
4. Set Main file path to `app.py`.
5. Click **Deploy!**

---

## 📁 Repository Structure

```
├── app.py                     # Main Streamlit application entry point
├── requirements.txt           # Python dependencies for Streamlit Cloud
├── README.md                  # Complete technical documentation
├── .gitignore                 # Standard Python/Node ignore rules
├── calculations/              # Standalone verified physics algorithms
│   ├── __init__.py
│   ├── conduction.py
│   ├── convection.py
│   ├── radiation.py
│   ├── heat_exchanger.py
│   └── thermal_resistance.py
├── utils/                     # Reporting & validation helpers
│   ├── __init__.py
│   ├── report_generator.py   # ReportLab PDF calculation sheet builder
│   └── validation.py         # Bounds & physics constraint verifier
└── src/                       # High-performance React/TypeScript application
    ├── App.tsx
    ├── components/
    └── utils/
```

---

## 🤖 AI Development Documentation

### AI Tools Used
- **Google AI Studio Build** (powered by **Gemini 3.7 Flash** and the **Antigravity Agent Engine**).

### Key Prompts Used
1. *"Build an engineering-grade Heat Transfer Analyser supporting Conduction, Convection, Radiation, Heat Exchangers, and Thermal Resistance networks in SI units."*
2. *"Implement step-by-step engineering equations, parameter validation, warning triggers for thermodynamic violations, and dynamic Plotly/Recharts visualizations."*
3. *"Generate complete ReportLab PDF and CSV calculation sheets with governing assumptions, numerical substitutions, and engineering interpretations."*
4. *"Create dual-stack Python/Streamlit and React/TypeScript implementations sharing identical deterministic physics engines."*

### Manual Verification & Fixes
- **LMTD Singularity**: Manually added $\lim_{\Delta T_1 \to \Delta T_2} \text{LMTD} = \Delta T_1$ to eliminate divide-by-zero errors when terminal temperature differences are identical.
- **Stefan-Boltzmann $T^4$ Precision**: Validated fourth-power radiation values against NIST standard $\sigma = 5.670374419 \times 10^{-8} \text{ W/m}^2\cdot\text{K}^4$.
- **Second Law Violations**: Added thermodynamic constraint traps to prevent parallel-flow temperature crossovers ($T_{c,out} > T_{h,out}$) and negative thermal resistances.

---

## 📜 License & Disclaimer
THERMO-X is released under the **MIT License**.  
*Disclaimer: THERMO-X is designed for educational and engineering design estimation purposes. Critical thermal safety systems must be independently verified by licensed professional engineers.*
