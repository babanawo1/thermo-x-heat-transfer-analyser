"""
AI DEVELOPMENT DOCUMENTATION

AI tools used:
- Google AI Studio Build (Gemini 3.7 Flash & Antigravity Agent Engine)

Key prompts used:
1. Build a Streamlit engineering application for heat-transfer analysis with interactive inputs, charts, Pandas results tables, validation, GitHub documentation and Streamlit deployment.
2. Implement and validate conduction, convection, radiation, heat exchanger and thermal resistance calculations using SI units.
3. Improve the application's UI, error handling, engineering validation, downloadable CSV/PDF reports, GitHub structure and deployment readiness.

Manual verification/fix:
The engineering equations, units, numerical results, heat-exchanger energy balances, physical input constraints, singularity edge cases (e.g. LMTD ΔT1 ≈ ΔT2), and Stefan-Boltzmann T⁴ radiation limits were manually reviewed, cross-tested against analytical benchmark test cases, and verified for production-grade engineering deployment.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from datetime import datetime

# Import local calculation engines
from calculations.conduction import calculate_conduction
from calculations.convection import calculate_convection
from calculations.radiation import calculate_radiation, STEFAN_BOLTZMANN_CONSTANT
from calculations.heat_exchanger import calculate_heat_exchanger
from calculations.thermal_resistance import calculate_thermal_resistance
from utils.report_generator import generate_pdf_report_bytes


# -------------------------------------------------------------
# PAGE CONFIGURATION & BRANDING
# -------------------------------------------------------------
st.set_page_config(
    page_title="THERMO-X | Heat Transfer Analyser",
    page_icon="🔥",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS for Professional Engineering Theme
st.markdown(
    """
    <style>
    .main { background-color: #f8fafc; }
    .stMetric { background-color: #ffffff; padding: 14px; border-radius: 10px; border: 1px solid #e2e8f0; }
    .stMetric label { font-size: 0.8rem; font-weight: 700; color: #475569; }
    .stMetric div[data-testid="stMetricValue"] { font-size: 1.4rem; font-weight: 800; color: #0f172a; }
    .css-1d391kg { padding-top: 1.5rem; }
    .block-container { padding-top: 2rem; padding-bottom: 2rem; }
    </style>
    """,
    unsafe_allow_html=True,
)

# -------------------------------------------------------------
# SIDEBAR NAVIGATION
# -------------------------------------------------------------
with st.sidebar:
    st.markdown("### 🔥 **THERMO-X**")
    st.caption("**Heat Transfer Analyser &bull; SI PRO**")
    st.markdown("---")

    analysis_mode = st.selectbox(
        "Select Analysis Type",
        [
            "Home / Dashboard",
            "Conduction",
            "Convection",
            "Radiation",
            "Heat Exchanger",
            "Thermal Resistance",
        ],
        index=0,
        help="Select the thermodynamic domain to analyse.",
    )

    st.markdown("---")
    st.markdown("#### **SI Engineering Standards**")
    st.markdown(
        """
        - Temperature: **K**
        - Heat Rate: **W**
        - Heat Flux: **W/m²**
        - Conductivity: **W/m·K**
        - Convection Coeff: **W/m²·K**
        - Resistance: **K/W**
        """
    )
    st.markdown("---")
    st.caption("Streamlit Community Cloud Ready &bull; v2.4")


# -------------------------------------------------------------
# 1. HOME / DASHBOARD PAGE
# -------------------------------------------------------------
if analysis_mode == "Home / Dashboard":
    st.title("THERMO-X")
    st.subheader("Heat Transfer Analyser")
    st.markdown("#### **Engineering-grade thermal analysis for students, engineers and researchers.**")

    st.info(
        "THERMO-X is an interactive engineering tool for analysing heat-transfer systems using "
        "established thermal engineering equations. Select an analysis method, enter your operating "
        "conditions, and obtain calculated engineering results, visualisations, and downloadable reports."
    )

    st.markdown("---")
    st.subheader("📖 How to use THERMO-X")

    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown(
            """
            **1. Select Analysis Type**  
            Choose Conduction, Convection, Radiation, Heat Exchanger, or Thermal Resistance from the sidebar.
            
            **2. Enter Parameters**  
            Input physical values in standard SI units (Kelvin, Watts, meters) or choose from standard presets.
            """
        )
    with col2:
        st.markdown(
            """
            **3. Review Calculated Results**  
            Examine automatically calculated metrics (Q, flux, resistance, LMTD, effectiveness) with instant error checking.
            
            **4. Examine Engineering Charts**  
            Inspect dynamic temperature distributions, fourth-power curvature, and axial fluid profiles.
            """
        )
    with col3:
        st.markdown(
            """
            **5. Review Step-by-Step Equations**  
            Verify governing equations, numerical substitutions, and review physical assumptions.
            
            **6. Download Reports**  
            Export structured CSV data logs or formal ReportLab PDF engineering reports.
            """
        )

    st.markdown("---")
    st.subheader("📊 Analysis Modules")

    m_col1, m_col2, m_col3 = st.columns(3)
    with m_col1:
        st.markdown(
            """
            **Conduction Analysis**  
            Analyse 1D steady-state conductive transport through solids using Fourier's Law ($Q = kA\\Delta T/L$).
            """
        )
    with m_col2:
        st.markdown(
            """
            **Convection Analysis**  
            Evaluate boundary convective heat transfer and cooling/heating modes using Newton's Law of Cooling ($Q = hA\\Delta T$).
            """
        )
    with m_col3:
        st.markdown(
            """
            **Radiation Analysis**  
            Calculate net thermal radiation exchange and $T^4$ curvature with Stefan-Boltzmann Law ($Q = \\varepsilon \\sigma A (T^4 - T_{surr}^4)$).
            """
        )

    m2_col1, m2_col2, _ = st.columns(3)
    with m2_col1:
        st.markdown(
            """
            **Heat Exchanger Analysis**  
            Evaluate Counter-Current and Parallel Flow heat exchangers with LMTD rating, First Law energy balances, and $\\varepsilon$-NTU sizing.
            """
        )
    with m2_col2:
        st.markdown(
            """
            **Thermal Resistance Networks**  
            Build multi-layer series composite walls with internal/external convection boundaries and evaluate interface temperatures.
            """
        )


# -------------------------------------------------------------
# 2. CONDUCTION ANALYSIS (FOURIER'S LAW)
# -------------------------------------------------------------
elif analysis_mode == "Conduction":
    st.title("Conduction Analysis")
    st.caption("One-dimensional steady-state heat conduction through a plane wall (Fourier's Law)")

    col_in, col_res = st.columns([1, 1])

    with col_in:
        st.markdown("### Operating Parameters")
        k = st.number_input("Thermal Conductivity k [W/m·K]", min_value=0.001, value=0.50, step=0.05, format="%.3f")
        area = st.number_input("Cross-Sectional Area A [m²]", min_value=0.001, value=10.0, step=0.5, format="%.2f")
        length = st.number_input("Wall Thickness L [m]", min_value=0.0001, value=0.10, step=0.01, format="%.4f")
        t_hot = st.number_input("Hot Surface Temperature T_hot [K]", min_value=1.0, value=400.0, step=5.0)
        t_cold = st.number_input("Cold Surface Temperature T_cold [K]", min_value=1.0, value=300.0, step=5.0)

    # Perform calculation
    res = calculate_conduction(k=k, area=area, length=length, t_hot=t_hot, t_cold=t_cold)

    # Warnings
    for w in res["warnings"]:
        if res["is_valid"]:
            st.warning(w)
        else:
            st.error(w)

    with col_res:
        st.markdown("### Principal Results")
        m1, m2 = st.columns(2)
        m1.metric("Heat Rate Q", f"{res['q']:,.2f} W", f"{res['q']/1000:,.3f} kW")
        m2.metric("Heat Flux q''", f"{res['q_flux']:,.2f} W/m²")

        m3, m4 = st.columns(2)
        m3.metric("Thermal Resistance R_cond", f"{res['r_cond']:.4f} K/W")
        m4.metric("Temperature Potential ΔT", f"{res['delta_t']:.2f} K")

    st.markdown("---")

    # Interactive Temperature Profile Chart
    st.subheader("📈 Temperature Profile T(x) Through Solid Wall")
    if res["is_valid"]:
        x_vals = np.linspace(0, length, 50)
        t_vals = t_hot - (res["q_flux"] / k) * x_vals

        fig = go.Figure()
        fig.add_trace(go.Scatter(x=x_vals, y=t_vals, mode="lines", name="T(x) Profile", line=dict(color="#ea580c", width=3)))
        fig.update_layout(
            xaxis_title="Position x [m]",
            yaxis_title="Temperature T [K]",
            margin=dict(l=40, r=20, t=20, b=40),
            height=320,
        )
        st.plotly_chart(fig, use_container_width=True)

    # Engineering Calculation Display
    st.subheader("🧮 Engineering Calculation Breakdown")
    c_eq, c_sub, c_res = st.columns(3)
    with c_eq:
        st.markdown("**1. Governing Equations**")
        st.latex(r"R_{cond} = \frac{L}{k A}")
        st.latex(r"Q = \frac{k A (T_{hot} - T_{cold})}{L} = \frac{\Delta T}{R_{cond}}")
        st.latex(r"q'' = \frac{Q}{A}")
    with c_sub:
        st.markdown("**2. Numerical Substitution**")
        st.markdown(f"- $R = {length} / ({k} \\times {area}) = {res['r_cond']:.4f} \\text{{ K/W}}$")
        st.markdown(f"- $\\Delta T = {t_hot} - {t_cold} = {res['delta_t']:.2f} \\text{{ K}}$")
        st.markdown(f"- $Q = {res['delta_t']:.2f} / {res['r_cond']:.4f}$")
    with c_res:
        st.markdown("**3. Computed Quantities**")
        st.markdown(f"- **Q** = **{res['q']:,.2f} W** ({res['q']/1e3:.3f} kW)")
        st.markdown(f"- **q''** = **{res['q_flux']:,.2f} W/m²**")
        st.markdown(f"- **R_cond** = **{res['r_cond']:.4f} K/W**")

    # Pandas Results Table
    st.subheader("📋 Results Table")
    df_results = pd.DataFrame([
        {"Parameter": "Temperature Difference", "Symbol": "ΔT", "Value": f"{res['delta_t']:.2f}", "Unit": "K", "Description": "Thermal potential across plane wall"},
        {"Parameter": "Thermal Resistance", "Symbol": "R_cond", "Value": f"{res['r_cond']:.4f}", "Unit": "K/W", "Description": "Conduction resistance L/(kA)"},
        {"Parameter": "Heat-Transfer Rate", "Symbol": "Q", "Value": f"{res['q']:,.2f}", "Unit": "W", "Description": "Total steady heat dissipation rate"},
        {"Parameter": "Heat Flux", "Symbol": "q''", "Value": f"{res['q_flux']:,.2f}", "Unit": "W/m²", "Description": "Heat rate per unit area (Q/A)"},
    ])
    st.dataframe(df_results, use_container_width=True, hide_index=True)

    # Assumptions & Interpretation
    assumptions = [
        "Steady-state 1D heat flow in the x-direction.",
        "Constant and uniform thermal conductivity k.",
        "No internal volumetric heat generation.",
        "Constant cross-sectional planar area A.",
    ]
    interpretation = (
        f"Under steady-state 1D conduction, a total heat rate of {res['q']:,.2f} W passes through the wall "
        f"with conductive resistance {res['r_cond']:.4f} K/W. The heat flux is {res['q_flux']:,.2f} W/m². "
        f"Increasing thickness L increases resistance and reduces heat loss; increasing conductivity k enhances heat dissipation."
    )

    col_a, col_i = st.columns(2)
    with col_a:
        st.markdown("#### 📌 Governing Assumptions")
        for a in assumptions:
            st.markdown(f"- {a}")
    with col_i:
        st.markdown("#### 💡 Engineering Interpretation")
        st.markdown(interpretation)

    # Export Buttons
    st.markdown("---")
    c_csv, c_pdf = st.columns(2)
    with c_csv:
        csv_data = df_results.to_csv(index=False).encode("utf-8")
        st.download_button("📥 Download Results as CSV", csv_data, "THERMO_X_Conduction.csv", "text/csv")
    with c_pdf:
        pdf_bytes = generate_pdf_report_bytes(
            analysis_title="1D Plane Wall Conduction Analysis",
            analysis_type="Conduction",
            governing_equation="Q = kA(T_hot - T_cold)/L = ΔT/R_cond",
            inputs=[
                {"name": "Thermal Conductivity", "symbol": "k", "value": str(k), "unit": "W/m·K"},
                {"name": "Cross-Sectional Area", "symbol": "A", "value": str(area), "unit": "m²"},
                {"name": "Wall Thickness", "symbol": "L", "value": str(length), "unit": "m"},
                {"name": "Hot Surface Temp", "symbol": "T_hot", "value": str(t_hot), "unit": "K"},
                {"name": "Cold Surface Temp", "symbol": "T_cold", "value": str(t_cold), "unit": "K"},
            ],
            results=[
                {"parameter": row["Parameter"], "symbol": row["Symbol"], "value": row["Value"], "unit": row["Unit"], "description": row["Description"]}
                for _, row in df_results.iterrows()
            ],
            assumptions=assumptions,
            interpretation=interpretation,
        )
        st.download_button("📄 Generate Engineering Report (PDF)", pdf_bytes, "THERMO_X_Conduction_Report.pdf", "application/pdf")


# -------------------------------------------------------------
# 3. CONVECTION ANALYSIS (NEWTON'S LAW)
# -------------------------------------------------------------
elif analysis_mode == "Convection":
    st.title("Convection Analysis")
    st.caption("Newton's Law of Cooling for fluid boundary convective exchange")

    col_in, col_res = st.columns([1, 1])

    with col_in:
        st.markdown("### Operating Parameters")
        h = st.number_input("Heat Transfer Coefficient h [W/m²·K]", min_value=0.1, value=20.0, step=2.0)
        area = st.number_input("Surface Area A [m²]", min_value=0.001, value=5.0, step=0.5)
        t_surface = st.number_input("Surface Temperature T_surface [K]", min_value=1.0, value=350.0, step=5.0)
        t_fluid = st.number_input("Fluid Temperature T_fluid [K]", min_value=1.0, value=300.0, step=5.0)

    res = calculate_convection(h=h, area=area, t_surface=t_surface, t_fluid=t_fluid)

    for w in res["warnings"]:
        if res["is_valid"]:
            st.warning(w)
        else:
            st.error(w)

    with col_res:
        st.markdown("### Principal Results")
        m1, m2 = st.columns(2)
        m1.metric("Heat Rate Q", f"{res['q']:,.2f} W", f"{res['q']/1000:,.3f} kW")
        m2.metric("Heat Flux q''", f"{res['q_flux']:,.2f} W/m²")

        m3, m4 = st.columns(2)
        m3.metric("Convective Resistance R_conv", f"{res['r_conv']:.5f} K/W")
        m4.metric("Temperature Potential ΔT", f"{res['delta_t']:.2f} K")

    st.markdown("---")

    # Chart: Q vs T_surface
    st.subheader("📈 Heat Transfer Rate Q vs Surface Temperature T_surface")
    if res["is_valid"]:
        ts_range = np.linspace(max(10, t_fluid - 100), t_fluid + 150, 50)
        q_range = h * area * (ts_range - t_fluid)

        fig = go.Figure()
        fig.add_trace(go.Scatter(x=ts_range, y=q_range, mode="lines", name="Q vs Ts", line=dict(color="#2563eb", width=3)))
        fig.update_layout(
            xaxis_title="Surface Temperature T_surface [K]",
            yaxis_title="Heat Rate Q [W]",
            margin=dict(l=40, r=20, t=20, b=40),
            height=320,
        )
        st.plotly_chart(fig, use_container_width=True)

    # Engineering Calculation Display
    st.subheader("🧮 Engineering Calculation Breakdown")
    c_eq, c_sub, c_res = st.columns(3)
    with c_eq:
        st.markdown("**1. Governing Equations**")
        st.latex(r"R_{conv} = \frac{1}{h A}")
        st.latex(r"Q = h A (T_s - T_\infty) = \frac{\Delta T}{R_{conv}}")
        st.latex(r"q'' = h (T_s - T_\infty)")
    with c_sub:
        st.markdown("**2. Numerical Substitution**")
        st.markdown(f"- $R_{{conv}} = 1 / ({h} \\times {area}) = {res['r_conv']:.5f} \\text{{ K/W}}$")
        st.markdown(f"- $\\Delta T = {t_surface} - {t_fluid} = {res['delta_t']:.2f} \\text{{ K}}$")
        st.markdown(f"- $Q = {res['delta_t']:.2f} / {res['r_conv']:.5f}$")
    with c_res:
        st.markdown("**3. Computed Quantities**")
        st.markdown(f"- **Q** = **{res['q']:,.2f} W** ({res['q']/1e3:.3f} kW)")
        st.markdown(f"- **q''** = **{res['q_flux']:,.2f} W/m²**")
        st.markdown(f"- **Mode** = **{res['mode'].upper()}**")

    # Table
    df_conv = pd.DataFrame([
        {"Parameter": "Temperature Difference", "Symbol": "ΔT", "Value": f"{res['delta_t']:.2f}", "Unit": "K", "Description": "Surface to fluid temperature potential"},
        {"Parameter": "Convective Resistance", "Symbol": "R_conv", "Value": f"{res['r_conv']:.5f}", "Unit": "K/W", "Description": "Boundary layer resistance 1/(hA)"},
        {"Parameter": "Heat-Transfer Rate", "Symbol": "Q", "Value": f"{res['q']:,.2f}", "Unit": "W", "Description": f"Convective heat transfer ({res['mode']} mode)"},
        {"Parameter": "Heat Flux", "Symbol": "q''", "Value": f"{res['q_flux']:,.2f}", "Unit": "W/m²", "Description": "Heat flux h*(Ts - T_inf)"},
    ])
    st.dataframe(df_conv, use_container_width=True, hide_index=True)

    assumptions = [
        "Steady-state convective conditions.",
        "Uniform convective coefficient h over entire surface.",
        "Newton's Law of Cooling applies.",
        "Bulk fluid temperature remains constant.",
    ]
    interpretation = (
        f"Newton's law of cooling indicates a net convective heat-transfer rate of {res['q']:,.2f} W with "
        f"convective resistance {res['r_conv']:.5f} K/W. The heat flux is {res['q_flux']:,.2f} W/m² in {res['mode']} mode."
    )

    col_a, col_i = st.columns(2)
    with col_a:
        st.markdown("#### 📌 Governing Assumptions")
        for a in assumptions:
            st.markdown(f"- {a}")
    with col_i:
        st.markdown("#### 💡 Engineering Interpretation")
        st.markdown(interpretation)

    st.markdown("---")
    c_csv, c_pdf = st.columns(2)
    with c_csv:
        csv_data = df_conv.to_csv(index=False).encode("utf-8")
        st.download_button("📥 Download Results as CSV", csv_data, "THERMO_X_Convection.csv", "text/csv")
    with c_pdf:
        pdf_bytes = generate_pdf_report_bytes(
            analysis_title="Convective Heat Transfer Analysis",
            analysis_type="Convection",
            governing_equation="Q = hA(T_surface - T_fluid) = ΔT/R_conv",
            inputs=[
                {"name": "Heat Transfer Coefficient", "symbol": "h", "value": str(h), "unit": "W/m²·K"},
                {"name": "Surface Area", "symbol": "A", "value": str(area), "unit": "m²"},
                {"name": "Surface Temp", "symbol": "T_surface", "value": str(t_surface), "unit": "K"},
                {"name": "Fluid Temp", "symbol": "T_fluid", "value": str(t_fluid), "unit": "K"},
            ],
            results=[
                {"parameter": row["Parameter"], "symbol": row["Symbol"], "value": row["Value"], "unit": row["Unit"], "description": row["Description"]}
                for _, row in df_conv.iterrows()
            ],
            assumptions=assumptions,
            interpretation=interpretation,
        )
        st.download_button("📄 Generate Engineering Report (PDF)", pdf_bytes, "THERMO_X_Convection_Report.pdf", "application/pdf")


# -------------------------------------------------------------
# 4. RADIATION ANALYSIS (STEFAN-BOLTZMANN)
# -------------------------------------------------------------
elif analysis_mode == "Radiation":
    st.title("Radiation Analysis")
    st.caption("Stefan-Boltzmann T⁴ Law for diffuse-gray net thermal radiation exchange")

    col_in, col_res = st.columns([1, 1])

    with col_in:
        st.markdown("### Operating Parameters")
        emissivity = st.slider("Surface Emissivity ε [-]", min_value=0.0, max_value=1.0, value=0.80, step=0.01)
        area = st.number_input("Surface Area A [m²]", min_value=0.001, value=2.0, step=0.2)
        t_surface = st.number_input("Surface Temperature T_surface [K]", min_value=1.0, value=500.0, step=10.0)
        t_surroundings = st.number_input("Surroundings Temperature T_surr [K]", min_value=1.0, value=300.0, step=10.0)

    res = calculate_radiation(emissivity=emissivity, area=area, t_surface=t_surface, t_surroundings=t_surroundings)

    for w in res["warnings"]:
        if res["is_valid"]:
            st.warning(w)
        else:
            st.error(w)

    with col_res:
        st.markdown("### Principal Results")
        m1, m2 = st.columns(2)
        m1.metric("Net Radiation Q_rad", f"{res['q']:,.2f} W", f"{res['q']/1000:,.3f} kW")
        m2.metric("Radiative Flux q''_rad", f"{res['q_flux']:,.2f} W/m²")

        m3, m4 = st.columns(2)
        m3.metric("Linearized Coeff h_r", f"{res['hr']:.3f} W/m²·K")
        m4.metric("Radiative Resistance R_rad", f"{res['r_rad']:.5f} K/W")

    st.markdown("---")

    # T⁴ Chart
    st.subheader("📈 Stefan-Boltzmann T⁴ Radiation Characteristic Curve")
    if res["is_valid"]:
        ts_range = np.linspace(max(50, t_surroundings - 150), max(t_surface + 250, 800), 50)
        q_rad_range = emissivity * STEFAN_BOLTZMANN_CONSTANT * area * (ts_range**4 - t_surroundings**4)

        fig = go.Figure()
        fig.add_trace(go.Scatter(x=ts_range, y=q_rad_range, mode="lines", name="Q_rad (T⁴ Curve)", line=dict(color="#d97706", width=3)))
        fig.update_layout(
            xaxis_title="Surface Temperature T_surface [K]",
            yaxis_title="Net Radiative Heat Rate Q_rad [W]",
            margin=dict(l=40, r=20, t=20, b=40),
            height=320,
        )
        st.plotly_chart(fig, use_container_width=True)

    # Calculation Breakdown
    st.subheader("🧮 Engineering Calculation Breakdown")
    c_eq, c_sub, c_res = st.columns(3)
    with c_eq:
        st.markdown("**1. Governing Equations**")
        st.latex(r"Q_{rad} = \varepsilon \sigma A (T_s^4 - T_{surr}^4)")
        st.latex(r"\sigma = 5.670374 \times 10^{-8} \text{ W/m}^2\text{K}^4")
        st.latex(r"h_r = \varepsilon \sigma (T_s + T_{surr})(T_s^2 + T_{surr}^2)")
    with c_sub:
        st.markdown("**2. Numerical Substitution**")
        st.markdown(f"- $T_s^4 = {t_surface}^4 = {res['ts4']:.3e} \\text{{ K}}^4$")
        st.markdown(f"- $T_{{surr}}^4 = {t_surroundings}^4 = {res['tsurr4']:.3e} \\text{{ K}}^4$")
        st.markdown(f"- $Q = {emissivity} \\times 5.6704\\times 10^{{-8}} \\times {area} \\times ({res['ts4']:.2e} - {res['tsurr4']:.2e})$")
    with c_res:
        st.markdown("**3. Computed Quantities**")
        st.markdown(f"- **Q_rad** = **{res['q']:,.2f} W**")
        st.markdown(f"- **h_r** = **{res['hr']:.3f} W/m²·K**")
        st.markdown(f"- **R_rad** = **{res['r_rad']:.5f} K/W**")

    # Table
    df_rad = pd.DataFrame([
        {"Parameter": "Net Radiative Heat Rate", "Symbol": "Q_rad", "Value": f"{res['q']:,.2f}", "Unit": "W", "Description": "Net radiative energy exchange with surroundings"},
        {"Parameter": "Radiative Heat Flux", "Symbol": "q''_rad", "Value": f"{res['q_flux']:,.2f}", "Unit": "W/m²", "Description": "Radiative flux per unit area"},
        {"Parameter": "Linearized Radiation Coeff", "Symbol": "h_r", "Value": f"{res['hr']:.3f}", "Unit": "W/m²·K", "Description": "Effective radiative transfer coefficient"},
        {"Parameter": "Radiative Resistance", "Symbol": "R_rad", "Value": f"{res['r_rad']:.5f}", "Unit": "K/W", "Description": "Linearized equivalent resistance 1/(h_r*A)"},
    ])
    st.dataframe(df_rad, use_container_width=True, hide_index=True)

    assumptions = [
        "Diffuse and gray surface (absorptivity = emissivity: α = ε).",
        "Enclosed by large blackbody surroundings (view factor F = 1.0).",
        "Transparent non-participating intermediate medium.",
        "Stefan-Boltzmann constant σ = 5.670374419 × 10⁻⁸ W/m²·K⁴.",
    ]
    interpretation = (
        f"The net radiative heat-transfer rate is {res['q']:,.2f} W. Because radiation depends on the 4th power of "
        f"absolute temperature (T⁴), higher surface temperatures cause heat transfer to grow non-linearly."
    )

    col_a, col_i = st.columns(2)
    with col_a:
        st.markdown("#### 📌 Governing Assumptions")
        for a in assumptions:
            st.markdown(f"- {a}")
    with col_i:
        st.markdown("#### 💡 Engineering Interpretation")
        st.markdown(interpretation)

    st.markdown("---")
    c_csv, c_pdf = st.columns(2)
    with c_csv:
        csv_data = df_rad.to_csv(index=False).encode("utf-8")
        st.download_button("📥 Download Results as CSV", csv_data, "THERMO_X_Radiation.csv", "text/csv")
    with c_pdf:
        pdf_bytes = generate_pdf_report_bytes(
            analysis_title="Thermal Radiation Analysis",
            analysis_type="Radiation",
            governing_equation="Q_rad = ε·σ·A·(T_s⁴ - T_surr⁴)",
            inputs=[
                {"name": "Emissivity", "symbol": "ε", "value": str(emissivity), "unit": "-"},
                {"name": "Surface Area", "symbol": "A", "value": str(area), "unit": "m²"},
                {"name": "Surface Temp", "symbol": "T_surface", "value": str(t_surface), "unit": "K"},
                {"name": "Surroundings Temp", "symbol": "T_surr", "value": str(t_surroundings), "unit": "K"},
            ],
            results=[
                {"parameter": row["Parameter"], "symbol": row["Symbol"], "value": row["Value"], "unit": row["Unit"], "description": row["Description"]}
                for _, row in df_rad.iterrows()
            ],
            assumptions=assumptions,
            interpretation=interpretation,
        )
        st.download_button("📄 Generate Engineering Report (PDF)", pdf_bytes, "THERMO_X_Radiation_Report.pdf", "application/pdf")


# -------------------------------------------------------------
# 5. HEAT EXCHANGER ANALYSIS (LMTD & ε-NTU)
# -------------------------------------------------------------
elif analysis_mode == "Heat Exchanger":
    st.title("Heat Exchanger Analysis")
    st.caption("Counter-Current & Parallel Flow thermal rating, LMTD singularity handling, and ε-NTU evaluation")

    flow = st.radio("Flow Arrangement", ["Counter-Current", "Parallel Flow"], horizontal=True)
    flow_key = "counter_current" if flow == "Counter-Current" else "parallel_flow"

    col_h, col_c, col_s = st.columns(3)
    with col_h:
        st.markdown("#### Hot Fluid Stream")
        m_dot_hot = st.number_input("Mass Flow Rate ṁ_h [kg/s]", min_value=0.001, value=1.50, step=0.1)
        cp_hot = st.number_input("Specific Heat Cp_h [J/kg·K]", min_value=1.0, value=4184.0, step=50.0)
        t_hot_in = st.number_input("Inlet Temp T_h,in [K]", min_value=1.0, value=363.15, step=5.0)
        t_hot_out = st.number_input("Outlet Temp T_h,out [K]", min_value=1.0, value=323.15, step=5.0)

    with col_c:
        st.markdown("#### Cold Fluid Stream")
        m_dot_cold = st.number_input("Mass Flow Rate ṁ_c [kg/s]", min_value=0.001, value=2.00, step=0.1)
        cp_cold = st.number_input("Specific Heat Cp_c [J/kg·K]", min_value=1.0, value=4184.0, step=50.0)
        t_cold_in = st.number_input("Inlet Temp T_c,in [K]", min_value=1.0, value=293.15, step=5.0)
        t_cold_out = st.number_input("Outlet Temp T_c,out [K]", min_value=1.0, value=323.15, step=5.0)

    with col_s:
        st.markdown("#### Exchanger Sizing")
        u = st.number_input("Overall Coeff U [W/m²·K]", min_value=1.0, value=850.0, step=50.0)
        area = st.number_input("Exchanger Area A [m²]", min_value=0.01, value=12.0, step=1.0)

    res = calculate_heat_exchanger(
        flow_arrangement=flow_key,
        m_dot_hot=m_dot_hot,
        cp_hot=cp_hot,
        t_hot_in=t_hot_in,
        t_hot_out=t_hot_out,
        m_dot_cold=m_dot_cold,
        cp_cold=cp_cold,
        t_cold_in=t_cold_in,
        t_cold_out=t_cold_out,
        u=u,
        area=area,
    )

    for w in res["warnings"]:
        if res["is_valid"]:
            st.warning(w)
        else:
            st.error(w)

    st.markdown("---")
    st.subheader("Principal Performance Metrics")

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("LMTD", f"{res['lmtd']:.2f} K")
    m2.metric("Sizing Heat Duty Q", f"{res['q_sizing']:,.1f} W", f"{res['q_sizing']/1e3:,.2f} kW")
    m3.metric("Effectiveness ε", f"{res['effectiveness']*100:.1f} %")
    m4.metric("NTU", f"{res['ntu']:.3f}")

    # Axial Profiles Chart
    st.subheader("📈 Axial Temperature Profiles Through Exchanger")
    if res["is_valid"]:
        x_norm = np.linspace(0, 1, 30)
        if flow_key == "counter_current":
            th_prof = t_hot_in - (t_hot_in - t_hot_out) * x_norm
            tc_prof = t_cold_out - (t_cold_out - t_cold_in) * x_norm
        else:
            th_prof = t_hot_in - (t_hot_in - t_hot_out) * (1 - np.exp(-2.5 * x_norm))
            tc_prof = t_cold_in + (t_cold_out - t_cold_in) * (1 - np.exp(-2.5 * x_norm))

        fig = go.Figure()
        fig.add_trace(go.Scatter(x=x_norm, y=th_prof, mode="lines", name="Hot Stream T_h(x)", line=dict(color="#dc2626", width=3)))
        fig.add_trace(go.Scatter(x=x_norm, y=tc_prof, mode="lines", name="Cold Stream T_c(x)", line=dict(color="#2563eb", width=3)))
        fig.update_layout(
            xaxis_title="Normalized Position (x/L)",
            yaxis_title="Temperature [K]",
            margin=dict(l=40, r=20, t=20, b=40),
            height=320,
        )
        st.plotly_chart(fig, use_container_width=True)

    # Equations Breakdown
    st.subheader("🧮 Engineering Calculation Breakdown")
    c_eq, c_sub, c_res = st.columns(3)
    with c_eq:
        st.markdown("**1. Governing Equations**")
        st.latex(r"Q = U A \text{LMTD}")
        st.latex(r"\text{LMTD} = \frac{\Delta T_1 - \Delta T_2}{\ln(\Delta T_1 / \Delta T_2)}")
        st.latex(r"\varepsilon = \frac{Q}{C_{min}(T_{h,in} - T_{c,in})}")
    with c_sub:
        st.markdown("**2. Numerical Substitution**")
        st.markdown(f"- $\\Delta T_1 = {res['delta_t1']:.2f} \\text{{ K}}, \\Delta T_2 = {res['delta_t2']:.2f} \\text{{ K}}$")
        st.markdown(f"- $\\text{{LMTD}} = {res['lmtd']:.2f} \\text{{ K}}$")
        st.markdown(f"- $Q_{{sizing}} = {u} \\times {area} \\times {res['lmtd']:.2f}$")
    with c_res:
        st.markdown("**3. Computed Quantities**")
        st.markdown(f"- **LMTD** = **{res['lmtd']:.2f} K**")
        st.markdown(f"- **Q_sizing** = **{res['q_sizing']:,.1f} W**")
        st.markdown(f"- **Effectiveness ε** = **{res['effectiveness']*100:.2f}%**")

    # Table
    df_he = pd.DataFrame([
        {"Parameter": "Hot Stream Capacity Rate", "Symbol": "C_hot", "Value": f"{res['c_hot']:,.1f}", "Unit": "W/K", "Description": "ṁ_h * Cp_h"},
        {"Parameter": "Cold Stream Capacity Rate", "Symbol": "C_cold", "Value": f"{res['c_cold']:,.1f}", "Unit": "W/K", "Description": "ṁ_c * Cp_c"},
        {"Parameter": "Log Mean Temp Difference", "Symbol": "LMTD", "Value": f"{res['lmtd']:.2f}", "Unit": "K", "Description": "Mean driving temperature difference"},
        {"Parameter": "Sizing Heat Rate", "Symbol": "Q_sizing", "Value": f"{res['q_sizing']:,.1f}", "Unit": "W", "Description": "U * A * LMTD"},
        {"Parameter": "Thermal Effectiveness", "Symbol": "ε", "Value": f"{res['effectiveness']*100:.2f}", "Unit": "%", "Description": "Q / Q_max"},
        {"Parameter": "Number of Transfer Units", "Symbol": "NTU", "Value": f"{res['ntu']:.3f}", "Unit": "-", "Description": "UA / C_min"},
    ])
    st.dataframe(df_he, use_container_width=True, hide_index=True)

    assumptions = [
        "Steady-state adiabatic heat exchanger operation.",
        "Constant fluid specific heats (Cp) and overall U along exchanger.",
        "Negligible longitudinal conduction and potential/kinetic changes.",
        "No phase change occurring in either fluid.",
    ]
    interpretation = (
        f"In {flow} arrangement, the exchanger achieves an LMTD of {res['lmtd']:.2f} K and thermal effectiveness "
        f"of {res['effectiveness']*100:.1f}%. Counter-current flow allows the cold fluid outlet to exceed the hot fluid outlet."
    )

    col_a, col_i = st.columns(2)
    with col_a:
        st.markdown("#### 📌 Governing Assumptions")
        for a in assumptions:
            st.markdown(f"- {a}")
    with col_i:
        st.markdown("#### 💡 Engineering Interpretation")
        st.markdown(interpretation)

    st.markdown("---")
    c_csv, c_pdf = st.columns(2)
    with c_csv:
        csv_data = df_he.to_csv(index=False).encode("utf-8")
        st.download_button("📥 Download Results as CSV", csv_data, "THERMO_X_HeatExchanger.csv", "text/csv")
    with c_pdf:
        pdf_bytes = generate_pdf_report_bytes(
            analysis_title=f"Heat Exchanger Analysis ({flow})",
            analysis_type="HeatExchanger",
            governing_equation="Q = U * A * LMTD,  ε = Q / Q_max",
            inputs=[
                {"name": "Flow Arrangement", "symbol": "Flow", "value": flow, "unit": "-"},
                {"name": "Hot Mass Flow", "symbol": "ṁ_h", "value": str(m_dot_hot), "unit": "kg/s"},
                {"name": "Hot In/Out Temp", "symbol": "Th,in/out", "value": f"{t_hot_in}/{t_hot_out}", "unit": "K"},
                {"name": "Cold Mass Flow", "symbol": "ṁ_c", "value": str(m_dot_cold), "unit": "kg/s"},
                {"name": "Cold In/Out Temp", "symbol": "Tc,in/out", "value": f"{t_cold_in}/{t_cold_out}", "unit": "K"},
                {"name": "Overall U", "symbol": "U", "value": str(u), "unit": "W/m²·K"},
                {"name": "Area", "symbol": "A", "value": str(area), "unit": "m²"},
            ],
            results=[
                {"parameter": row["Parameter"], "symbol": row["Symbol"], "value": row["Value"], "unit": row["Unit"], "description": row["Description"]}
                for _, row in df_he.iterrows()
            ],
            assumptions=assumptions,
            interpretation=interpretation,
        )
        st.download_button("📄 Generate Engineering Report (PDF)", pdf_bytes, "THERMO_X_HeatExchanger_Report.pdf", "application/pdf")


# -------------------------------------------------------------
# 6. THERMAL RESISTANCE ANALYSIS (SERIES COMPOSITE)
# -------------------------------------------------------------
elif analysis_mode == "Thermal Resistance":
    st.title("Thermal Resistance Network")
    st.caption("Series composite wall and multi-layer thermal resistance network")

    col_in, col_res = st.columns([1, 1])

    with col_in:
        st.markdown("### Boundary Temperatures & Layer Properties")
        t_in = st.number_input("Inside Fluid Temperature T_inlet [K]", min_value=1.0, value=370.0, step=5.0)
        t_out = st.number_input("Outside Fluid Temperature T_outlet [K]", min_value=1.0, value=290.0, step=5.0)
        area = st.number_input("Surface Area A [m²]", min_value=0.01, value=4.0, step=0.5)

        st.markdown("#### Series Layers")
        h_in = st.number_input("Inside Convection h_in [W/m²·K]", min_value=0.1, value=25.0, step=2.0)
        k_wall = st.number_input("Wall Conductivity k_wall [W/m·K]", min_value=0.001, value=0.72, step=0.05)
        l_wall = st.number_input("Wall Thickness L_wall [m]", min_value=0.001, value=0.12, step=0.01)
        k_ins = st.number_input("Insulation Conductivity k_ins [W/m·K]", min_value=0.001, value=0.038, step=0.005)
        l_ins = st.number_input("Insulation Thickness L_ins [m]", min_value=0.001, value=0.05, step=0.01)
        h_out = st.number_input("Outside Convection h_out [W/m²·K]", min_value=0.1, value=50.0, step=5.0)

    layers_config = [
        {"name": "Inside Convection", "type": "convection", "h": h_in, "area": area},
        {"name": "Brick Wall", "type": "conduction", "k": k_wall, "thickness": l_wall, "area": area},
        {"name": "Fiberglass Insulation", "type": "conduction", "k": k_ins, "thickness": l_ins, "area": area},
        {"name": "Outside Convection", "type": "convection", "h": h_out, "area": area},
    ]

    res = calculate_thermal_resistance(t_inlet_fluid=t_in, t_outlet_fluid=t_out, layers=layers_config)

    for w in res["warnings"]:
        if res["is_valid"]:
            st.warning(w)
        else:
            st.error(w)

    with col_res:
        st.markdown("### Principal Results")
        m1, m2 = st.columns(2)
        m1.metric("Total Heat Rate Q", f"{res['q']:,.2f} W", f"{res['q']/1000:,.3f} kW")
        m2.metric("Total Resistance R_tot", f"{res['r_total']:.4f} K/W")

        m3, m4 = st.columns(2)
        m3.metric("Overall U-Value", f"{res['u_overall']:.3f} W/m²·K")
        m4.metric("Heat Flux q''", f"{res['q_flux']:,.2f} W/m²")

    st.markdown("---")

    # Resistance contribution chart
    st.subheader("📈 Series Layer Resistance Distribution")
    if res["is_valid"]:
        layer_names = [l["name"] for l in res["layers"]]
        layer_r = [l["r_value"] for l in res["layers"]]

        fig = go.Figure(go.Bar(x=layer_r, y=layer_names, orientation="h", marker=dict(color="#10b981")))
        fig.update_layout(
            xaxis_title="Thermal Resistance R [K/W]",
            yaxis_title="Layer",
            margin=dict(l=40, r=20, t=20, b=40),
            height=260,
        )
        st.plotly_chart(fig, use_container_width=True)

    # Engineering Calculation Display
    st.subheader("🧮 Engineering Calculation Breakdown")
    c_eq, c_sub, c_res = st.columns(3)
    with c_eq:
        st.markdown("**1. Governing Equations**")
        st.latex(r"R_{total} = \sum R_i = R_{conv,1} + \sum \frac{L_i}{k_i A} + R_{conv,2}")
        st.latex(r"Q = \frac{T_{in} - T_{out}}{R_{total}}")
    with c_sub:
        st.markdown("**2. Numerical Substitution**")
        st.markdown(f"- $\\Delta T = {t_in} - {t_out} = {res['delta_t_total']:.1f} \\text{{ K}}$")
        st.markdown(f"- $R_{{total}} = {res['r_total']:.4f} \\text{{ K/W}}$")
        st.markdown(f"- $Q = {res['delta_t_total']:.1f} / {res['r_total']:.4f}$")
    with c_res:
        st.markdown("**3. Computed Quantities**")
        st.markdown(f"- **Q** = **{res['q']:,.2f} W**")
        st.markdown(f"- **U_overall** = **{res['u_overall']:.3f} W/m²·K**")
        st.markdown(f"- **q''** = **{res['q_flux']:,.2f} W/m²**")

    # Table
    table_data = [
        {"Parameter": "Total Heat Rate", "Symbol": "Q", "Value": f"{res['q']:,.2f}", "Unit": "W", "Description": "ΔT_total / R_total"},
        {"Parameter": "Total Resistance", "Symbol": "R_total", "Value": f"{res['r_total']:.4f}", "Unit": "K/W", "Description": "Σ R_i"},
        {"Parameter": "Overall U-Value", "Symbol": "U", "Value": f"{res['u_overall']:.3f}", "Unit": "W/m²·K", "Description": "1 / (R_total * A)"},
    ]
    for l in res["layers"]:
        table_data.append({
            "Parameter": l["name"],
            "Symbol": "R_i",
            "Value": f"{l['r_value']:.4f} ({l['percent_of_total']:.1f}%)",
            "Unit": "K/W",
            "Description": f"T_in = {l['t_in']:.1f}K → T_out = {l['t_out']:.1f}K (ΔT = {l['delta_t']:.1f}K)",
        })

    df_tr = pd.DataFrame(table_data)
    st.dataframe(df_tr, use_container_width=True, hide_index=True)

    assumptions = [
        "1D steady-state heat conduction and convection.",
        "Negligible contact resistance between solid interfaces.",
        "Uniform heat transfer coefficients on both fluid sides.",
    ]
    interpretation = (
        f"Total resistance is {res['r_total']:.4f} K/W across ΔT = {res['delta_t_total']:.1f} K, "
        f"transferring {res['q']:,.2f} W. The highest resistance layer controls the overall heat transfer rate."
    )

    col_a, col_i = st.columns(2)
    with col_a:
        st.markdown("#### 📌 Governing Assumptions")
        for a in assumptions:
            st.markdown(f"- {a}")
    with col_i:
        st.markdown("#### 💡 Engineering Interpretation")
        st.markdown(interpretation)

    st.markdown("---")
    c_csv, c_pdf = st.columns(2)
    with c_csv:
        csv_data = df_tr.to_csv(index=False).encode("utf-8")
        st.download_button("📥 Download Results as CSV", csv_data, "THERMO_X_ThermalResistance.csv", "text/csv")
    with c_pdf:
        pdf_bytes = generate_pdf_report_bytes(
            analysis_title="Thermal Resistance Network Analysis",
            analysis_type="ThermalResistance",
            governing_equation="R_total = Σ R_i,  Q = ΔT / R_total",
            inputs=[
                {"name": "Inside Fluid Temp", "symbol": "T_in", "value": str(t_in), "unit": "K"},
                {"name": "Outside Fluid Temp", "symbol": "T_out", "value": str(t_out), "unit": "K"},
                {"name": "Surface Area", "symbol": "A", "value": str(area), "unit": "m²"},
            ],
            results=[
                {"parameter": row["Parameter"], "symbol": row["Symbol"], "value": row["Value"], "unit": row["Unit"], "description": row["Description"]}
                for _, row in df_tr.iterrows()
            ],
            assumptions=assumptions,
            interpretation=interpretation,
        )
        st.download_button("📄 Generate Engineering Report (PDF)", pdf_bytes, "THERMO_X_ThermalResistance_Report.pdf", "application/pdf")
