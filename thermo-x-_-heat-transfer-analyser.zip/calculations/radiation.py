"""
THERMO-X | Radiation Analysis Module
Stefan-Boltzmann Fourth-Power Law for Thermal Radiation
"""

from typing import Dict, Any

STEFAN_BOLTZMANN_CONSTANT = 5.670374419e-8  # W/m²·K⁴


def calculate_radiation(
    emissivity: float,
    area: float,
    t_surface: float,
    t_surroundings: float,
) -> Dict[str, Any]:
    """
    Calculates net radiative heat transfer between a diffuse-gray surface and large surroundings.

    Governing Equations:
        Q_rad = ε * σ * A * (T_surface⁴ - T_surroundings⁴)      [W]
        q''_rad = ε * σ * (T_surface⁴ - T_surroundings⁴)        [W/m²]
        h_r = ε * σ * (T_surface + T_surr) * (T_surface² + T_surr²) [W/m²·K]
        R_rad = 1 / (h_r * A)                                  [K/W]

    Args:
        emissivity: Surface emissivity (0.0 to 1.0)
        area: Radiating surface area [m²]
        t_surface: Surface absolute temperature [K]
        t_surroundings: Surroundings effective temperature [K]

    Returns:
        Dictionary with q, q_flux, hr, r_rad, ts4, tsurr4, mode, is_valid, warnings.
    """
    warnings = []

    if emissivity < 0.0 or emissivity > 1.0:
        warnings.append("Surface emissivity (ε) must be within physical bounds 0.0 ≤ ε ≤ 1.0.")
    if area <= 0:
        warnings.append("Surface area must be strictly greater than 0 m².")
    if t_surface <= 0 or t_surroundings <= 0:
        warnings.append("Absolute temperatures must be strictly greater than 0 K.")

    delta_t = t_surface - t_surroundings
    mode = "equilibrium"
    if delta_t > 0:
        mode = "emission"
    elif delta_t < 0:
        mode = "absorption"
    else:
        warnings.append("Radiative equilibrium (T_surface = T_surroundings): Net radiation is zero.")

    is_valid = (
        (len(warnings) == 0 or (len(warnings) == 1 and delta_t == 0))
        and (0 <= emissivity <= 1.0)
        and (area > 0)
        and (t_surface > 0)
        and (t_surroundings > 0)
    )

    if not is_valid:
        return {
            "q": 0.0,
            "q_flux": 0.0,
            "hr": 0.0,
            "r_rad": 0.0,
            "ts4": 0.0,
            "tsurr4": 0.0,
            "mode": mode,
            "is_valid": False,
            "warnings": warnings,
        }

    ts4 = t_surface**4
    tsurr4 = t_surroundings**4

    # Net radiative heat rate [W]
    q = emissivity * STEFAN_BOLTZMANN_CONSTANT * area * (ts4 - tsurr4)
    # Radiative heat flux [W/m²]
    q_flux = emissivity * STEFAN_BOLTZMANN_CONSTANT * (ts4 - tsurr4)

    # Linearized radiative coefficient [W/m²·K]
    hr = (
        emissivity
        * STEFAN_BOLTZMANN_CONSTANT
        * (t_surface + t_surroundings)
        * (t_surface**2 + t_surroundings**2)
    )
    # Radiative resistance [K/W]
    r_rad = 1.0 / (hr * area) if hr > 0 else 0.0

    return {
        "q": q,
        "q_flux": q_flux,
        "hr": hr,
        "r_rad": r_rad,
        "ts4": ts4,
        "tsurr4": tsurr4,
        "mode": mode,
        "is_valid": True,
        "warnings": warnings,
    }
