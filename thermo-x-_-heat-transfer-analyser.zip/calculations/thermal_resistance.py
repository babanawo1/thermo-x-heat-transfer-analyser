"""
THERMO-X | Thermal Resistance Module
Series Composite Network Analysis
"""

from typing import List, Dict, Any


def calculate_thermal_resistance(
    t_inlet_fluid: float,
    t_outlet_fluid: float,
    layers: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Evaluates 1D series thermal resistance networks with convection and conduction layers.

    Governing Equations:
        R_conv = 1 / (h * A)
        R_cond = L / (k * A)
        R_total = Σ R_i
        Q = (T_inlet - T_outlet) / R_total
        ΔT_i = Q * R_i

    Args:
        t_inlet_fluid: Inside bulk fluid temperature [K]
        t_outlet_fluid: Outside bulk fluid temperature [K]
        layers: List of layer dictionaries containing type, h or (k, thickness), area.

    Returns:
        Dictionary of network performance, interface temperatures, and total heat flow.
    """
    warnings = []

    if t_inlet_fluid <= 0 or t_outlet_fluid <= 0:
        warnings.append("Fluid temperatures must be strictly greater than 0 K.")
    if len(layers) == 0:
        warnings.append("At least one layer must be specified in the network.")

    delta_t_total = t_inlet_fluid - t_outlet_fluid

    r_total = 0.0
    calculated_layers = []

    for i, layer in enumerate(layers):
        name = layer.get("name", f"Layer {i+1}")
        l_type = layer.get("type", "conduction")
        area = layer.get("area", 1.0)
        r_val = 0.0

        if area <= 0:
            warnings.append(f"{name}: Area must be strictly positive.")
        elif l_type == "convection":
            h = layer.get("h", 0.0)
            if h <= 0:
                warnings.append(f"{name}: Convective coefficient h must be positive.")
            else:
                r_val = 1.0 / (h * area)
        elif l_type == "conduction":
            k = layer.get("k", 0.0)
            thickness = layer.get("thickness", 0.0)
            if k <= 0:
                warnings.append(f"{name}: Thermal conductivity k must be positive.")
            elif thickness <= 0:
                warnings.append(f"{name}: Thickness L must be positive.")
            else:
                r_val = thickness / (k * area)
        elif l_type == "contact":
            r_val = layer.get("r_specified", 0.0)

        r_total += r_val
        calculated_layers.append({
            "name": name,
            "type": l_type,
            "r_value": r_val,
            "area": area,
        })

    is_valid = len(warnings) == 0 and r_total > 0

    if not is_valid:
        return {
            "layers": [],
            "r_total": 0.0,
            "u_overall": 0.0,
            "q": 0.0,
            "q_flux": 0.0,
            "delta_t_total": delta_t_total,
            "is_valid": False,
            "warnings": warnings,
        }

    q = delta_t_total / r_total
    primary_area = layers[0].get("area", 1.0)
    q_flux = q / primary_area if primary_area > 0 else 0.0
    u_overall = 1.0 / (r_total * primary_area) if primary_area > 0 else 0.0

    current_t = t_inlet_fluid
    final_layers = []
    for item in calculated_layers:
        delta_t_layer = q * item["r_value"]
        t_in = current_t
        t_out = current_t - delta_t_layer
        current_t = t_out
        pct = (item["r_value"] / r_total * 100.0) if r_total > 0 else 0.0

        final_layers.append({
            **item,
            "t_in": t_in,
            "t_out": t_out,
            "delta_t": delta_t_layer,
            "percent_of_total": pct,
        })

    return {
        "layers": final_layers,
        "r_total": r_total,
        "u_overall": u_overall,
        "q": q,
        "q_flux": q_flux,
        "delta_t_total": delta_t_total,
        "is_valid": True,
        "warnings": warnings,
    }
