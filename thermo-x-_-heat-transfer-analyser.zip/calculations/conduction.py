"""
THERMO-X | Conduction Analysis Module
One-Dimensional Steady-State Heat Conduction (Fourier's Law)
"""

from typing import Dict, Any, Tuple


def calculate_conduction(
    k: float,
    area: float,
    length: float,
    t_hot: float,
    t_cold: float,
) -> Dict[str, Any]:
    """
    Calculates 1D steady-state heat conduction through a plane wall.

    Governing Equations:
        R_cond = L / (k * A)       [K/W]
        Q = k * A * (T_hot - T_cold) / L  [W]
        q'' = Q / A                 [W/m²]

    Args:
        k: Thermal conductivity [W/m·K]
        area: Cross-sectional area [m²]
        length: Wall thickness [m]
        t_hot: Hot boundary temperature [K]
        t_cold: Cold boundary temperature [K]

    Returns:
        Dictionary with delta_t, r_cond, q, q_flux, is_valid, warnings.
    """
    warnings = []

    if area <= 0:
        warnings.append("Area must be strictly greater than 0 m².")
    if length <= 0:
        warnings.append("Wall thickness (L) must be strictly greater than 0 m.")
    if k <= 0:
        warnings.append("Thermal conductivity (k) must be strictly greater than 0 W/m·K.")
    if t_hot <= 0 or t_cold <= 0:
        warnings.append("Temperatures must be strictly positive on absolute Kelvin scale (T > 0 K).")

    delta_t = t_hot - t_cold
    if delta_t == 0:
        warnings.append("Isothermal boundary condition: Heat transfer rate is zero.")

    is_valid = (len(warnings) == 0 or (len(warnings) == 1 and delta_t == 0)) and (area > 0 and length > 0 and k > 0)

    if not is_valid:
        return {
            "delta_t": delta_t,
            "r_cond": 0.0,
            "q": 0.0,
            "q_flux": 0.0,
            "is_valid": False,
            "warnings": warnings,
        }

    # Thermal resistance [K/W]
    r_cond = length / (k * area)
    # Heat transfer rate [W]
    q = delta_t / r_cond
    # Heat flux [W/m²]
    q_flux = q / area

    return {
        "delta_t": delta_t,
        "r_cond": r_cond,
        "q": q,
        "q_flux": q_flux,
        "is_valid": True,
        "warnings": warnings,
    }
