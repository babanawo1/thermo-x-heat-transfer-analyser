"""
THERMO-X | Convection Analysis Module
Newton's Law of Cooling
"""

from typing import Dict, Any


def calculate_convection(
    h: float,
    area: float,
    t_surface: float,
    t_fluid: float,
) -> Dict[str, Any]:
    """
    Calculates convective heat transfer from a solid surface to fluid.

    Governing Equations:
        R_conv = 1 / (h * A)                 [K/W]
        Q = h * A * (T_surface - T_fluid)    [W]
        q'' = h * (T_surface - T_fluid)      [W/m²]

    Args:
        h: Convection heat-transfer coefficient [W/m²·K]
        area: Wetted surface area [m²]
        t_surface: Surface temperature [K]
        t_fluid: Bulk fluid temperature [K]

    Returns:
        Dictionary with delta_t, r_conv, q, q_flux, mode, is_valid, warnings.
    """
    warnings = []

    if h <= 0:
        warnings.append("Convection coefficient (h) must be strictly greater than 0 W/m²·K.")
    if area <= 0:
        warnings.append("Surface area must be strictly greater than 0 m².")
    if t_surface <= 0 or t_fluid <= 0:
        warnings.append("Temperatures must be strictly positive on absolute Kelvin scale (T > 0 K).")

    delta_t = t_surface - t_fluid
    mode = "equilibrium"
    if delta_t > 0:
        mode = "cooling"
    elif delta_t < 0:
        mode = "heating"
    else:
        warnings.append("Thermal equilibrium (T_surface = T_fluid): Heat transfer rate is zero.")

    is_valid = (len(warnings) == 0 or (len(warnings) == 1 and delta_t == 0)) and (h > 0 and area > 0)

    if not is_valid:
        return {
            "delta_t": delta_t,
            "r_conv": 0.0,
            "q": 0.0,
            "q_flux": 0.0,
            "mode": mode,
            "is_valid": False,
            "warnings": warnings,
        }

    # Convective resistance [K/W]
    r_conv = 1.0 / (h * area)
    # Heat transfer rate [W]
    q = delta_t / r_conv
    # Heat flux [W/m²]
    q_flux = h * delta_t

    return {
        "delta_t": delta_t,
        "r_conv": r_conv,
        "q": q,
        "q_flux": q_flux,
        "mode": mode,
        "is_valid": True,
        "warnings": warnings,
    }
