"""
THERMO-X | Heat Exchanger Analysis Module
LMTD & Effectiveness-NTU Methods
"""

import math
from typing import Dict, Any


def calculate_lmtd(delta_t1: float, delta_t2: float) -> float:
    """
    Calculates the Log Mean Temperature Difference (LMTD) with singularity handling.

    Formula:
        LMTD = (ΔT1 - ΔT2) / ln(ΔT1 / ΔT2)
        If ΔT1 ≈ ΔT2, lim -> ΔT1

    Args:
        delta_t1: Terminal temperature difference 1 [K]
        delta_t2: Terminal temperature difference 2 [K]

    Returns:
        LMTD [K]
    """
    if delta_t1 <= 0 or delta_t2 <= 0:
        return 0.0
    if abs(delta_t1 - delta_t2) < 1e-6:
        return delta_t1
    return (delta_t1 - delta_t2) / math.log(delta_t1 / delta_t2)


def calculate_heat_exchanger(
    flow_arrangement: str,  # 'counter_current' or 'parallel_flow'
    m_dot_hot: float,
    cp_hot: float,
    t_hot_in: float,
    t_hot_out: float,
    m_dot_cold: float,
    cp_cold: float,
    t_cold_in: float,
    t_cold_out: float,
    u: float,
    area: float,
) -> Dict[str, Any]:
    """
    Performs heat exchanger energy balance, LMTD rating, and ε-NTU evaluation.

    Args:
        flow_arrangement: 'counter_current' or 'parallel_flow'
        m_dot_hot: Hot fluid mass flow rate [kg/s]
        cp_hot: Hot fluid specific heat capacity [J/kg·K]
        t_hot_in: Hot fluid inlet temperature [K]
        t_hot_out: Hot fluid outlet temperature [K]
        m_dot_cold: Cold fluid mass flow rate [kg/s]
        cp_cold: Cold fluid specific heat capacity [J/kg·K]
        t_cold_in: Cold fluid inlet temperature [K]
        t_cold_out: Cold fluid outlet temperature [K]
        u: Overall heat-transfer coefficient [W/m²·K]
        area: Heat-transfer surface area [m²]

    Returns:
        Comprehensive dictionary of heat exchanger performance metrics.
    """
    warnings = []

    # Basic input checks
    if m_dot_hot <= 0 or m_dot_cold <= 0:
        warnings.append("Mass flow rates must be strictly positive (ṁ > 0 kg/s).")
    if cp_hot <= 0 or cp_cold <= 0:
        warnings.append("Specific heat capacities must be strictly positive (Cp > 0 J/kg·K).")
    if t_hot_in <= 0 or t_hot_out <= 0 or t_cold_in <= 0 or t_cold_out <= 0:
        warnings.append("Inlet and outlet temperatures must be strictly greater than 0 K.")
    if t_hot_in <= t_cold_in:
        warnings.append("Hot stream inlet (T_h,in) must be hotter than cold stream inlet (T_c,in).")
    if t_hot_in <= t_hot_out:
        warnings.append("Hot stream must reject heat: T_h,in must exceed T_h,out.")
    if t_cold_out <= t_cold_in:
        warnings.append("Cold stream must absorb heat: T_c,out must exceed T_c,in.")
    if u <= 0 or area <= 0:
        warnings.append("Overall heat transfer coefficient U and area A must be strictly positive.")

    # Heat capacity rates [W/K]
    c_hot = m_dot_hot * cp_hot
    c_cold = m_dot_cold * cp_cold

    # Heat duties [W]
    q_hot = c_hot * (t_hot_in - t_hot_out)
    q_cold = c_cold * (t_cold_out - t_cold_in)
    q_avg = (q_hot + q_cold) / 2.0 if (q_hot + q_cold) > 0 else 0.0

    energy_discrepancy = abs(q_hot - q_cold)
    energy_discrepancy_pct = (energy_discrepancy / q_avg * 100.0) if q_avg > 0 else 0.0

    if energy_discrepancy_pct > 5.0 and q_avg > 0:
        warnings.append(
            f"Energy balance discrepancy: Q_hot ({q_hot/1e3:.2f} kW) and Q_cold ({q_cold/1e3:.2f} kW) differ by {energy_discrepancy_pct:.1f}%."
        )

    # Terminal temperature differences
    if flow_arrangement == "counter_current":
        delta_t1 = t_hot_in - t_cold_out
        delta_t2 = t_hot_out - t_cold_in
    else:  # parallel_flow
        delta_t1 = t_hot_in - t_cold_in
        delta_t2 = t_hot_out - t_cold_out

    has_crossover = False
    if delta_t1 <= 0 or delta_t2 <= 0:
        has_crossover = True
        warnings.append(
            f"Temperature Crossover Detected: ΔT1 = {delta_t1:.2f} K, ΔT2 = {delta_t2:.2f} K violates Second Law of Thermodynamics."
        )

    if flow_arrangement == "parallel_flow" and t_cold_out >= t_hot_out:
        has_crossover = True
        warnings.append("In parallel flow, T_c,out cannot exceed T_h,out.")

    # LMTD calculation
    lmtd = 0.0
    if not has_crossover and delta_t1 > 0 and delta_t2 > 0:
        lmtd = calculate_lmtd(delta_t1, delta_t2)

    q_sizing = u * area * lmtd

    # Effectiveness-NTU parameters
    c_min = min(c_hot, c_cold)
    c_max = max(c_hot, c_cold)
    cr = c_min / c_max if c_max > 0 else 0.0
    q_max = c_min * (t_hot_in - t_cold_in)
    effectiveness = q_avg / q_max if q_max > 0 else 0.0
    ntu = (u * area) / c_min if c_min > 0 else 0.0

    if effectiveness > 1.0:
        warnings.append(f"Calculated effectiveness ε = {effectiveness:.3f} > 1.0 is physically impossible.")

    is_valid = (
        not has_crossover
        and delta_t1 > 0
        and delta_t2 > 0
        and m_dot_hot > 0
        and m_dot_cold > 0
        and u > 0
        and area > 0
    )

    return {
        "c_hot": c_hot,
        "c_cold": c_cold,
        "q_hot": q_hot,
        "q_cold": q_cold,
        "q_avg": q_avg,
        "energy_discrepancy": energy_discrepancy,
        "energy_discrepancy_pct": energy_discrepancy_pct,
        "delta_t1": delta_t1,
        "delta_t2": delta_t2,
        "lmtd": lmtd,
        "q_sizing": q_sizing,
        "c_min": c_min,
        "c_max": c_max,
        "cr": cr,
        "q_max": q_max,
        "effectiveness": effectiveness,
        "ntu": ntu,
        "has_crossover": has_crossover,
        "is_valid": is_valid,
        "warnings": warnings,
    }
