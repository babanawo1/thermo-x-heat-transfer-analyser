/**
 * THERMO-X | Report Generator
 * Exports professional PDF engineering reports and CSV calculation logs
 */

import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { ResultTableRow } from '../types';

export interface ReportData {
  analysisTitle: string;
  analysisType: string;
  governingEquation: string;
  inputs: { name: string; symbol: string; value: string; unit: string }[];
  results: ResultTableRow[];
  assumptions: string[];
  interpretation: string;
  validationNotes: string[];
}

export function generatePdfReport(data: ReportData): void {
  const doc = new jsPDF();
  const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC';

  // Palette: Deep Navy & Thermal Orange
  const primaryColor: [number, number, number] = [15, 23, 42]; // slate-900
  const accentColor: [number, number, number] = [217, 70, 239]; // subtle highlight or thermal amber [234, 88, 12]
  const thermalColor: [number, number, number] = [234, 88, 12]; // orange-600

  // Header Banner
  doc.setFillColor(...primaryColor);
  doc.rect(0, 0, 210, 32, 'F');

  // Title & Subtitle
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('THERMO-X | Heat Transfer Analyser', 14, 15);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Engineering-Grade Thermal Analysis System (SI Units)', 14, 22);

  doc.setFontSize(8);
  doc.setTextColor(203, 213, 225);
  doc.text(`Generated: ${timestamp}`, 140, 22);

  let currentY = 40;

  // Analysis Title Header
  doc.setTextColor(...thermalColor);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text(`Analysis: ${data.analysisTitle}`, 14, currentY);
  currentY += 8;

  // Governing Equation box
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(14, currentY, 182, 16, 2, 2, 'FD');

  doc.setTextColor(51, 65, 85);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('Governing Equation:', 18, currentY + 6);
  doc.setFont('courier', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text(data.governingEquation, 60, currentY + 6);

  currentY += 22;

  // 1. Inputs Section
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(...primaryColor);
  doc.text('1. Operating & Boundary Parameters', 14, currentY);
  currentY += 4;

  const inputRows = data.inputs.map((inp) => [inp.name, inp.symbol, inp.value, inp.unit]);

  autoTable(doc, {
    startY: currentY,
    head: [['Parameter Description', 'Symbol', 'Entered Value', 'SI Unit']],
    body: inputRows,
    theme: 'striped',
    headStyles: { fillColor: [51, 65, 85], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 9 },
    bodyStyles: { fontSize: 8.5, textColor: [30, 41, 59] },
    columnStyles: {
      0: { cellWidth: 80 },
      1: { cellWidth: 25 },
      2: { cellWidth: 45, halign: 'right' },
      3: { cellWidth: 32 },
    },
    margin: { left: 14, right: 14 },
  });

  currentY = (doc as any).lastAutoTable.finalY + 10;

  // 2. Results Section
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(...primaryColor);
  doc.text('2. Computed Engineering Results', 14, currentY);
  currentY += 4;

  const resultRows = data.results.map((res) => [res.parameter, res.symbol, res.value, res.unit, res.description]);

  autoTable(doc, {
    startY: currentY,
    head: [['Result Parameter', 'Symbol', 'Calculated Value', 'SI Unit', 'Physical Meaning']],
    body: resultRows,
    theme: 'striped',
    headStyles: { fillColor: [234, 88, 12], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 9 },
    bodyStyles: { fontSize: 8.5, textColor: [30, 41, 59] },
    columnStyles: {
      0: { cellWidth: 50 },
      1: { cellWidth: 20 },
      2: { cellWidth: 35, halign: 'right', fontStyle: 'bold' },
      3: { cellWidth: 22 },
      4: { cellWidth: 55 },
    },
    margin: { left: 14, right: 14 },
  });

  currentY = (doc as any).lastAutoTable.finalY + 10;

  // Check if we need a new page
  if (currentY > 220) {
    doc.addPage();
    currentY = 20;
  }

  // 3. Assumptions
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(...primaryColor);
  doc.text('3. Governing Engineering Assumptions', 14, currentY);
  currentY += 6;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  data.assumptions.forEach((assump) => {
    doc.text(`•  ${assump}`, 18, currentY);
    currentY += 5;
  });

  currentY += 4;

  // 4. Engineering Interpretation
  if (currentY > 230) {
    doc.addPage();
    currentY = 20;
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(...primaryColor);
  doc.text('4. Engineering Interpretation & Insights', 14, currentY);
  currentY += 6;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(51, 65, 85);
  const splitInterpretation = doc.splitTextToSize(data.interpretation, 182);
  doc.text(splitInterpretation, 14, currentY);
  currentY += splitInterpretation.length * 4.5 + 8;

  // Disclaimer footer
  if (currentY > 255) {
    doc.addPage();
    currentY = 20;
  }

  doc.setFillColor(241, 245, 249);
  doc.rect(14, currentY, 182, 18, 'F');
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(7.5);
  doc.setTextColor(100, 116, 139);
  const disclaimer =
    'DISCLAIMER: THERMO-X is an educational and engineering analysis tool. Results are calculated from standard 1D/lumped thermodynamic relations and must be independently verified before use in safety-critical, design-critical, or commercial applications.';
  const splitDisclaimer = doc.splitTextToSize(disclaimer, 174);
  doc.text(splitDisclaimer, 18, currentY + 6);

  // Save PDF
  const filename = `THERMO_X_${data.analysisType.toUpperCase()}_REPORT_${Date.now()}.pdf`;
  doc.save(filename);
}

export function downloadCsv(filename: string, rows: Record<string, string | number>[]): void {
  if (rows.length === 0) return;

  const headers = Object.keys(rows[0]);
  const csvContent = [
    headers.join(','),
    ...rows.map((row) =>
      headers
        .map((h) => {
          const val = row[h] !== undefined ? String(row[h]) : '';
          return `"${val.replace(/"/g, '""')}"`;
        })
        .join(',')
    ),
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
