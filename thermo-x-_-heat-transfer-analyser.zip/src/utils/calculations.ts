/**
 * THERMO-X Physical Calculations Engine
 * Mathematically validated SI-unit heat transfer algorithms
 */

import {
  ConductionInputs,
  ConductionResults,
  ConvectionInputs,
  ConvectionResults,
  RadiationInputs,
  RadiationResults,
  HeatExchangerInputs,
  HeatExchangerResults,
  ThermalResistanceInputs,
  ThermalResistanceResults,
  CalculatedLayer,
} from '../types';

export const STEFAN_BOLTZMANN_CONSTANT = 5.670374419e-8; // W/m²·K⁴

/**
 * Standard material thermal conductivities (k in W/m·K at ~300 K)
 */
export const MATERIAL_PRESETS = [
  { name: 'Custom Material', k: 1.0 },
  { name: 'Pure Copper', k: 385.0 },
  { name: 'Pure Aluminum', k: 205.0 },
  { name: 'Carbon Steel (1% C)', k: 43.0 },
  { name: 'Stainless Steel (AISI 304)', k: 14.9 },
  { name: 'Window Glass', k: 1.4 },
  { name: 'Common Red Brick', k: 0.72 },
  { name: 'Dense Concrete', k: 1.4 },
  { name: 'Fiberglass Insulation (blanket)', k: 0.038 },
  { name: 'Expanded Polystyrene (EPS Foam)', k: 0.033 },
  { name: 'Air (quiescent, 300 K)', k: 0.0263 },
  { name: 'Water (liquid, 300 K)', k: 0.606 },
];

/**
 * Standard convection coefficient ranges (h in W/m²·K)
 */
export const CONVECTION_PRESETS = [
  { name: 'Custom Value', h: 25.0 },
  { name: 'Free Convection — Air (gases)', h: 10.0 },
  { name: 'Forced Convection — Air (moderate velocity)', h: 50.0 },
  { name: 'Forced Convection — High-velocity Air', h: 150.0 },
  { name: 'Free Convection — Water (liquids)', h: 500.0 },
  { name: 'Forced Convection — Water Flow', h: 3000.0 },
  { name: 'Forced Convection — Engine Oil', h: 600.0 },
  { name: 'Boiling Water (nucleate pool boiling)', h: 25000.0 },
  { name: 'Condensing Steam (filmwise)', h: 12000.0 },
];

/**
 * Standard surface emissivity presets
 */
export const EMISSIVITY_PRESETS = [
  { name: 'Custom Surface', emissivity: 0.85 },
  { name: 'Ideal Blackbody (theoretical)', emissivity: 1.00 },
  { name: 'Matte Black Paint', emissivity: 0.96 },
  { name: 'White Paint / Acrylic', emissivity: 0.92 },
  { name: 'Red Common Brick', emissivity: 0.93 },
  { name: 'Heavy Oxidized Steel', emissivity: 0.80 },
  { name: 'Anodized Aluminum', emissivity: 0.82 },
  { name: 'Commercial Stainless Steel (clean)', emissivity: 0.17 },
  { name: 'Polished Copper', emissivity: 0.03 },
  { name: 'Polished Highly Reflective Silver', emissivity: 0.02 },
];

// ==========================================
// 1. CONDUCTION CALCULATION (FOURIER'S LAW)
// ==========================================
export function calculateConduction(inputs: ConductionInputs): ConductionResults {
  const warnings: string[] = [];

  if (inputs.area <= 0) {
    warnings.push('Area must be strictly greater than 0 m².');
  }
  if (inputs.length <= 0) {
    warnings.push('Wall thickness (L) must be strictly greater than 0 m.');
  }
  if (inputs.k <= 0) {
    warnings.push('Thermal conductivity (k) must be strictly greater than 0 W/m·K.');
  }
  if (inputs.tHot <= 0 || inputs.tCold <= 0) {
    warnings.push('Temperatures must be strictly positive (T > 0 K) on the absolute Kelvin scale.');
  }

  const deltaT = inputs.tHot - inputs.tCold;
  if (deltaT === 0) {
    warnings.push('Isothermal condition (ΔT = 0 K): Zero net heat transfer.');
  }

  const isValid = warnings.length === 0 || (warnings.length === 1 && deltaT === 0);

  if (!isValid || inputs.area <= 0 || inputs.length <= 0 || inputs.k <= 0) {
    return {
      deltaT: 0,
      rCond: 0,
      q: 0,
      qFlux: 0,
      isValid: false,
      warnings,
    };
  }

  // R_cond = L / (k * A) [K/W]
  const rCond = inputs.length / (inputs.k * inputs.area);
  // Q = k * A * (T_hot - T_cold) / L = deltaT / R_cond [W]
  const q = deltaT / rCond;
  // q'' = Q / A = k * deltaT / L [W/m²]
  const qFlux = q / inputs.area;

  return {
    deltaT,
    rCond,
    q,
    qFlux,
    isValid: true,
    warnings,
  };
}

// ==========================================
// 2. CONVECTION CALCULATION (NEWTON'S LAW)
// ==========================================
export function calculateConvection(inputs: ConvectionInputs): ConvectionResults {
  const warnings: string[] = [];

  if (inputs.h <= 0) {
    warnings.push('Convective heat transfer coefficient (h) must be strictly positive (h > 0 W/m²·K).');
  }
  if (inputs.area <= 0) {
    warnings.push('Surface Area must be strictly greater than 0 m².');
  }
  if (inputs.tSurface <= 0 || inputs.tFluid <= 0) {
    warnings.push('Temperatures must be strictly positive (T > 0 K) on the absolute Kelvin scale.');
  }

  const deltaT = inputs.tSurface - inputs.tFluid;
  let mode: 'cooling' | 'heating' | 'equilibrium' = 'equilibrium';
  if (deltaT > 0) {
    mode = 'cooling'; // Surface cools as heat flows to colder fluid
  } else if (deltaT < 0) {
    mode = 'heating'; // Surface absorbs heat from hotter fluid
  } else {
    warnings.push('Thermal equilibrium (T_surface = T_fluid): Zero convective heat transfer.');
  }

  const isValid = warnings.length === 0 || (warnings.length === 1 && deltaT === 0);

  if (!isValid || inputs.h <= 0 || inputs.area <= 0) {
    return {
      deltaT: 0,
      rConv: 0,
      q: 0,
      qFlux: 0,
      mode,
      isValid: false,
      warnings,
    };
  }

  // R_conv = 1 / (h * A) [K/W]
  const rConv = 1 / (inputs.h * inputs.area);
  // Q = h * A * (T_surface - T_fluid) = deltaT / R_conv [W]
  const q = deltaT / rConv;
  // q'' = h * (T_surface - T_fluid) [W/m²]
  const qFlux = inputs.h * deltaT;

  return {
    deltaT,
    rConv,
    q,
    qFlux,
    mode,
    isValid: true,
    warnings,
  };
}

// ==========================================
// 3. RADIATION CALCULATION (STEFAN-BOLTZMANN)
// ==========================================
export function calculateRadiation(inputs: RadiationInputs): RadiationResults {
  const warnings: string[] = [];

  if (inputs.emissivity < 0 || inputs.emissivity > 1) {
    warnings.push('Surface emissivity (ε) must be within the physically valid range [0, 1].');
  }
  if (inputs.area <= 0) {
    warnings.push('Surface area must be strictly greater than 0 m².');
  }
  if (inputs.tSurface <= 0 || inputs.tSurr <= 0) {
    warnings.push('Temperatures must be strictly greater than absolute zero (T > 0 K).');
  }

  const deltaT = inputs.tSurface - inputs.tSurr;
  let mode: 'emission' | 'absorption' | 'equilibrium' = 'equilibrium';
  if (deltaT > 0) {
    mode = 'emission'; // Net heat emitted to surroundings
  } else if (deltaT < 0) {
    mode = 'absorption'; // Net heat absorbed from warmer surroundings
  } else {
    warnings.push('Radiative equilibrium (T_surface = T_surroundings): Net radiation exchange is zero.');
  }

  const isValid = warnings.length === 0 || (warnings.length === 1 && deltaT === 0);

  if (!isValid || inputs.area <= 0 || inputs.tSurface <= 0 || inputs.tSurr <= 0) {
    return {
      q: 0,
      qFlux: 0,
      hr: 0,
      rRad: 0,
      ts4: 0,
      tsurr4: 0,
      mode,
      isValid: false,
      warnings,
    };
  }

  const ts4 = Math.pow(inputs.tSurface, 4);
  const tsurr4 = Math.pow(inputs.tSurr, 4);

  // Q_rad = ε * σ * A * (T_s⁴ - T_surr⁴) [W]
  const q = inputs.emissivity * STEFAN_BOLTZMANN_CONSTANT * inputs.area * (ts4 - tsurr4);
  // q''_rad = ε * σ * (T_s⁴ - T_surr⁴) [W/m²]
  const qFlux = inputs.emissivity * STEFAN_BOLTZMANN_CONSTANT * (ts4 - tsurr4);

  // Linearized radiation coefficient h_r = ε * σ * (T_s + T_surr) * (T_s² + T_surr²) [W/m²·K]
  const hr = inputs.emissivity * STEFAN_BOLTZMANN_CONSTANT * (inputs.tSurface + inputs.tSurr) * (Math.pow(inputs.tSurface, 2) + Math.pow(inputs.tSurr, 2));
  
  // Radiative resistance R_rad = 1 / (h_r * A) [K/W]
  const rRad = hr > 0 ? 1 / (hr * inputs.area) : 0;

  return {
    q,
    qFlux,
    hr,
    rRad,
    ts4,
    tsurr4,
    mode,
    isValid: true,
    warnings,
  };
}

// ==========================================
// 4. HEAT EXCHANGER (LMTD & ε-NTU METHODS)
// ==========================================
export function calculateHeatExchanger(inputs: HeatExchangerInputs): HeatExchangerResults {
  const warnings: string[] = [];

  // Basic physical validation
  if (inputs.mDotHot <= 0 || inputs.mDotCold <= 0) {
    warnings.push('Mass flow rates must be strictly positive (ṁ > 0 kg/s).');
  }
  if (inputs.cpHot <= 0 || inputs.cpCold <= 0) {
    warnings.push('Specific heat capacities must be strictly positive (Cp > 0 J/kg·K).');
  }
  if (inputs.tHotIn <= 0 || inputs.tHotOut <= 0 || inputs.tColdIn <= 0 || inputs.tColdOut <= 0) {
    warnings.push('All inlet and outlet temperatures must be strictly positive (T > 0 K).');
  }
  if (inputs.tHotIn <= inputs.tColdIn) {
    warnings.push('Hot stream inlet temperature (T_hot,in) must exceed cold stream inlet (T_cold,in).');
  }
  if (inputs.tHotIn <= inputs.tHotOut) {
    warnings.push('Hot stream must lose heat (T_hot,in must be greater than T_hot,out).');
  }
  if (inputs.tColdOut <= inputs.tColdIn) {
    warnings.push('Cold stream must gain heat (T_cold,out must be greater than T_cold,in).');
  }
  if (inputs.u <= 0 || inputs.area <= 0) {
    warnings.push('Overall heat transfer coefficient (U) and area (A) must be strictly positive.');
  }

  // Calculate Heat Capacity Rates
  const cHot = inputs.mDotHot * inputs.cpHot; // W/K
  const cCold = inputs.mDotCold * inputs.cpCold; // W/K

  // Heat Duties
  const qHot = cHot * (inputs.tHotIn - inputs.tHotOut); // W
  const qCold = cCold * (inputs.tColdOut - inputs.tColdIn); // W
  const qAverage = (qHot + qCold) / 2;

  const energyDiscrepancy = Math.abs(qHot - qCold);
  const energyDiscrepancyPercent = qAverage > 0 ? (energyDiscrepancy / qAverage) * 100 : 0;

  if (energyDiscrepancyPercent > 5.0 && qAverage > 0) {
    warnings.push(
      `First Law Energy Balance Discrepancy: Q_hot (${(qHot / 1e3).toFixed(2)} kW) differs from Q_cold (${(qCold / 1e3).toFixed(2)} kW) by ${energyDiscrepancyPercent.toFixed(1)}%. Note: Under steady adiabatic conditions, Q_hot should equal Q_cold.`
    );
  }

  // Temperature differences based on flow arrangement
  let deltaT1 = 0;
  let deltaT2 = 0;

  if (inputs.flowArrangement === 'counter_current') {
    deltaT1 = inputs.tHotIn - inputs.tColdOut;
    deltaT2 = inputs.tHotOut - inputs.tColdIn;
  } else {
    // parallel_flow
    deltaT1 = inputs.tHotIn - inputs.tColdIn;
    deltaT2 = inputs.tHotOut - inputs.tColdOut;
  }

  let hasCrossover = false;
  if (deltaT1 <= 0 || deltaT2 <= 0) {
    hasCrossover = true;
    warnings.push(
      `Temperature Crossover / Inversion Detected: ΔT₁ = ${deltaT1.toFixed(2)} K, ΔT₂ = ${deltaT2.toFixed(2)} K. A terminal temperature difference is non-positive, violating the Second Law of Thermodynamics for this flow arrangement.`
    );
  }

  if (inputs.flowArrangement === 'parallel_flow' && inputs.tColdOut >= inputs.tHotOut) {
    hasCrossover = true;
    warnings.push('In parallel flow, the cold stream outlet temperature cannot exceed the hot stream outlet temperature (T_cold,out < T_hot,out).');
  }

  // Calculate LMTD with robust singularity handling
  let lmtd = 0;
  if (!hasCrossover && deltaT1 > 0 && deltaT2 > 0) {
    if (Math.abs(deltaT1 - deltaT2) < 1e-5) {
      // Limit as ΔT1 -> ΔT2
      lmtd = deltaT1;
    } else {
      lmtd = (deltaT1 - deltaT2) / Math.log(deltaT1 / deltaT2);
    }
  }

  const qSizing = inputs.u * inputs.area * lmtd;

  // ε-NTU parameters
  const cMin = Math.min(cHot, cCold);
  const cMax = Math.max(cHot, cCold);
  const cr = cMax > 0 ? cMin / cMax : 0;
  const qMax = cMin * (inputs.tHotIn - inputs.tColdIn);

  const effectiveness = qMax > 0 ? qAverage / qMax : 0;
  const ntu = cMin > 0 ? (inputs.u * inputs.area) / cMin : 0;

  if (effectiveness > 1.0) {
    warnings.push(`Calculated effectiveness ε = ${effectiveness.toFixed(3)} > 1.0, which is physically impossible. Verify stream flow rates and temperatures.`);
  }

  const isValid = !hasCrossover && deltaT1 > 0 && deltaT2 > 0 && inputs.mDotHot > 0 && inputs.mDotCold > 0;

  return {
    cHot,
    cCold,
    qHot,
    qCold,
    qAverage,
    energyDiscrepancy,
    energyDiscrepancyPercent,
    deltaT1,
    deltaT2,
    lmtd,
    qSizing,
    cMin,
    cMax,
    cr,
    qMax,
    effectiveness,
    ntu,
    hasCrossover,
    isValid,
    warnings,
  };
}

// ==========================================
// 5. THERMAL RESISTANCE NETWORK (SERIES)
// ==========================================
export function calculateThermalResistance(inputs: ThermalResistanceInputs): ThermalResistanceResults {
  const warnings: string[] = [];

  if (inputs.tInletFluid <= 0 || inputs.tOutletFluid <= 0) {
    warnings.push('Fluid temperatures must be strictly greater than absolute zero (T > 0 K).');
  }

  if (inputs.layers.length === 0) {
    warnings.push('At least one resistance layer must be configured.');
  }

  const deltaTTotal = inputs.tInletFluid - inputs.tOutletFluid;
  if (deltaTTotal === 0) {
    warnings.push('Isothermal boundary conditions (T_inlet = T_outlet): Zero heat transfer across network.');
  }

  // Calculate individual resistances
  let rTotal = 0;
  const intermediateLayers: { layer: (typeof inputs.layers)[0]; rValue: number }[] = [];

  for (let i = 0; i < inputs.layers.length; i++) {
    const layer = inputs.layers[i];
    let r = 0;

    if (layer.area <= 0) {
      warnings.push(`Layer ${i + 1} (${layer.name}): Area must be strictly positive.`);
      r = 0;
    } else if (layer.type === 'convection') {
      if (!layer.h || layer.h <= 0) {
        warnings.push(`Layer ${i + 1} (${layer.name}): Convection coefficient (h) must be strictly positive.`);
      } else {
        r = 1 / (layer.h * layer.area);
      }
    } else if (layer.type === 'conduction') {
      if (!layer.k || layer.k <= 0) {
        warnings.push(`Layer ${i + 1} (${layer.name}): Thermal conductivity (k) must be strictly positive.`);
      } else if (!layer.thickness || layer.thickness <= 0) {
        warnings.push(`Layer ${i + 1} (${layer.name}): Thickness (L) must be strictly positive.`);
      } else {
        r = layer.thickness / (layer.k * layer.area);
      }
    } else if (layer.type === 'contact') {
      r = layer.rSpecified && layer.rSpecified >= 0 ? layer.rSpecified : 0;
    }

    rTotal += r;
    intermediateLayers.push({ layer, rValue: r });
  }

  const isValid = warnings.length === 0 && rTotal > 0;

  if (!isValid || rTotal <= 0) {
    return {
      layers: [],
      rTotal: 0,
      uOverall: 0,
      q: 0,
      qFlux: 0,
      deltaTTotal,
      isValid: false,
      warnings,
    };
  }

  // Heat rate Q = ΔT_total / R_total [W]
  const q = deltaTTotal / rTotal;
  const primaryArea = inputs.layers[0]?.area || 1.0;
  const qFlux = primaryArea > 0 ? q / primaryArea : 0;
  // U_overall = 1 / (R_total * A) [W/m²·K]
  const uOverall = primaryArea > 0 ? 1 / (rTotal * primaryArea) : 0;

  // Temperature gradient profile along interfaces
  let currentTemp = inputs.tInletFluid;
  const calculatedLayers: CalculatedLayer[] = intermediateLayers.map((item) => {
    const percentOfTotal = rTotal > 0 ? (item.rValue / rTotal) * 100 : 0;
    const deltaTLayer = q * item.rValue;
    const tIn = currentTemp;
    const tOut = currentTemp - deltaTLayer;
    currentTemp = tOut;

    return {
      layer: item.layer,
      rValue: item.rValue,
      percentOfTotal,
      tIn,
      tOut,
      deltaT: deltaTLayer,
    };
  });

  return {
    layers: calculatedLayers,
    rTotal,
    uOverall,
    q,
    qFlux,
    deltaTTotal,
    isValid: true,
    warnings,
  };
}

/**
 * Engineering Formatters
 */
export function formatEng(value: number, decimals: number = 3): string {
  if (value === 0) return '0.000';
  const absVal = Math.abs(value);
  if (absVal >= 1e6) {
    return (value / 1e6).toFixed(decimals) + ' M';
  } else if (absVal >= 1e3) {
    return (value / 1e3).toFixed(decimals) + ' k';
  } else if (absVal < 0.001 && absVal > 0) {
    return value.toExponential(decimals);
  }
  return value.toFixed(decimals);
}

export function formatNum(value: number, decimals: number = 3): string {
  if (Math.abs(value) < 1e-4 && value !== 0) {
    return value.toExponential(decimals);
  }
  return value.toFixed(decimals);
}
