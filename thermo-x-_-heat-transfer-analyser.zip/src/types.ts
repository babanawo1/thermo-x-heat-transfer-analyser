/**
 * THERMO-X | Heat Transfer Analyser - Types
 * Standard SI Unit Definitions and Data Structures
 */

export type AnalysisType =
  | 'home'
  | 'how_to_use'
  | 'conduction'
  | 'convection'
  | 'radiation'
  | 'heat_exchanger'
  | 'thermal_resistance'
  | 'verification'
  | 'python_repo';

export interface ConductionInputs {
  materialPreset: string;
  k: number;          // Thermal conductivity [W/m·K]
  area: number;       // Cross-sectional Area [m²]
  length: number;     // Wall thickness [m]
  tHot: number;       // Hot-side temperature [K]
  tCold: number;      // Cold-side temperature [K]
}

export interface ConductionResults {
  deltaT: number;     // Temperature difference [K]
  rCond: number;      // Thermal resistance [K/W]
  q: number;          // Heat transfer rate [W]
  qFlux: number;      // Heat flux [W/m²]
  isValid: boolean;
  warnings: string[];
}

export interface ConvectionInputs {
  preset: string;
  h: number;          // Convection heat transfer coefficient [W/m²·K]
  area: number;       // Surface Area [m²]
  tSurface: number;   // Surface Temperature [K]
  tFluid: number;     // Fluid Temperature [K]
}

export interface ConvectionResults {
  deltaT: number;     // Temperature difference [K]
  rConv: number;      // Convective thermal resistance [K/W]
  q: number;          // Heat transfer rate [W]
  qFlux: number;      // Heat flux [W/m²]
  mode: 'cooling' | 'heating' | 'equilibrium';
  isValid: boolean;
  warnings: string[];
}

export interface RadiationInputs {
  preset: string;
  emissivity: number; // Surface emissivity (0 - 1)
  area: number;       // Surface Area [m²]
  tSurface: number;   // Surface Temperature [K]
  tSurr: number;      // Surroundings Temperature [K]
}

export interface RadiationResults {
  q: number;          // Net radiative heat transfer rate [W]
  qFlux: number;      // Radiative heat flux [W/m²]
  hr: number;         // Linearized radiation coefficient [W/m²·K]
  rRad: number;       // Radiative thermal resistance [K/W]
  ts4: number;        // T_surface^4 [K^4]
  tsurr4: number;     // T_surroundings^4 [K^4]
  mode: 'emission' | 'absorption' | 'equilibrium';
  isValid: boolean;
  warnings: string[];
}

export type HeatExchangerFlow = 'counter_current' | 'parallel_flow';

export interface HeatExchangerInputs {
  flowArrangement: HeatExchangerFlow;
  // Hot fluid
  mDotHot: number;    // Mass flow rate hot [kg/s]
  cpHot: number;      // Specific heat capacity hot [J/kg·K]
  tHotIn: number;     // Hot fluid inlet temp [K]
  tHotOut: number;    // Hot fluid outlet temp [K]
  // Cold fluid
  mDotCold: number;   // Mass flow rate cold [kg/s]
  cpCold: number;     // Specific heat capacity cold [J/kg·K]
  tColdIn: number;    // Cold fluid inlet temp [K]
  tColdOut: number;   // Cold fluid outlet temp [K]
  // Heat exchanger sizing
  u: number;          // Overall heat transfer coefficient [W/m²·K]
  area: number;       // Heat transfer area [m²]
}

export interface HeatExchangerResults {
  cHot: number;       // Hot heat capacity rate [W/K]
  cCold: number;      // Cold heat capacity rate [W/K]
  qHot: number;       // Hot side heat release [W]
  qCold: number;      // Cold side heat absorption [W]
  qAverage: number;   // Average heat duty [W]
  energyDiscrepancy: number; // Absolute difference |Q_h - Q_c| [W]
  energyDiscrepancyPercent: number; // % Difference
  deltaT1: number;    // Temperature difference 1 [K]
  deltaT2: number;    // Temperature difference 2 [K]
  lmtd: number;       // Log Mean Temperature Difference [K]
  qSizing: number;    // U * A * LMTD [W]
  cMin: number;       // Min heat capacity rate [W/K]
  cMax: number;       // Max heat capacity rate [W/K]
  cr: number;         // Capacity ratio Cr = Cmin / Cmax
  qMax: number;       // Maximum possible heat transfer [W]
  effectiveness: number; // Thermal effectiveness ε
  ntu: number;        // Number of Transfer Units NTU
  hasCrossover: boolean;
  isValid: boolean;
  warnings: string[];
}

export interface ThermalResistanceLayer {
  id: string;
  name: string;
  type: 'convection' | 'conduction' | 'contact';
  k?: number;         // For conduction [W/m·K]
  thickness?: number; // For conduction [m]
  h?: number;         // For convection [W/m²·K]
  rSpecified?: number;// Directly specified R [K/W]
  area: number;       // Area [m²]
}

export interface ThermalResistanceInputs {
  tInletFluid: number;  // Fluid temperature inside [K]
  tOutletFluid: number; // Fluid temperature outside [K]
  layers: ThermalResistanceLayer[];
}

export interface CalculatedLayer {
  layer: ThermalResistanceLayer;
  rValue: number;       // Resistance [K/W]
  percentOfTotal: number; // % of total resistance
  tIn: number;          // Temperature at layer inlet interface [K]
  tOut: number;         // Temperature at layer outlet interface [K]
  deltaT: number;       // Temperature drop across this layer [K]
}

export interface ThermalResistanceResults {
  layers: CalculatedLayer[];
  rTotal: number;       // Total resistance [K/W]
  uOverall: number;     // Overall heat transfer coefficient U [W/m²·K]
  q: number;            // Heat transfer rate [W]
  qFlux: number;        // Heat flux [W/m²]
  deltaTTotal: number;  // Total temperature difference [K]
  isValid: boolean;
  warnings: string[];
}

export interface ResultTableRow {
  parameter: string;
  symbol: string;
  value: string;
  unit: string;
  description: string;
}
