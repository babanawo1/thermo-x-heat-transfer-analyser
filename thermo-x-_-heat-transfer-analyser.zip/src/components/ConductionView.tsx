import React, { useState, useMemo } from 'react';
import {
  Layers,
  FileSpreadsheet,
  FileText,
  AlertTriangle,
  CheckCircle2,
  Info,
  Sliders,
  TrendingUp,
} from 'lucide-react';
import { ConductionInputs, ResultTableRow } from '../types';
import {
  calculateConduction,
  MATERIAL_PRESETS,
  formatEng,
  formatNum,
} from '../utils/calculations';
import { generatePdfReport, downloadCsv } from '../utils/reportGenerator';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';

export const ConductionView: React.FC = () => {
  // Inputs state
  const [inputs, setInputs] = useState<ConductionInputs>({
    materialPreset: 'Custom Material',
    k: 0.5,
    area: 10.0,
    length: 0.1,
    tHot: 400.0,
    tCold: 300.0,
  });

  // Calculate results dynamically
  const results = useMemo(() => calculateConduction(inputs), [inputs]);

  // Handle Preset Change
  const handlePresetChange = (name: string) => {
    const found = MATERIAL_PRESETS.find((m) => m.name === name);
    if (found) {
      setInputs((prev) => ({
        ...prev,
        materialPreset: name,
        k: found.k,
      }));
    }
  };

  // Generate Profile Data for Chart: T(x) = T_hot - (q'' / k) * x
  const profileData = useMemo(() => {
    if (!results.isValid || inputs.length <= 0) return [];
    const points = 25;
    const data = [];
    const step = inputs.length / (points - 1);
    for (let i = 0; i < points; i++) {
      const x = i * step;
      const t = inputs.tHot - (results.qFlux / inputs.k) * x;
      data.push({
        x: Number(x.toFixed(4)),
        temperature: Number(t.toFixed(2)),
      });
    }
    return data;
  }, [inputs, results]);

  // Generate Results Table Rows
  const tableRows: ResultTableRow[] = useMemo(() => {
    return [
      {
        parameter: 'Temperature Difference',
        symbol: 'ΔT',
        value: formatNum(results.deltaT, 2),
        unit: 'K',
        description: 'Thermal driving potential across solid plane wall',
      },
      {
        parameter: 'Conduction Thermal Resistance',
        symbol: 'R_cond',
        value: formatNum(results.rCond, 4),
        unit: 'K/W',
        description: 'Resistance to conductive heat transfer (L / kA)',
      },
      {
        parameter: 'Heat-Transfer Rate',
        symbol: 'Q',
        value: `${formatNum(results.q, 2)} (${formatEng(results.q, 3)}W)`,
        unit: 'W',
        description: 'Total thermal energy transferred per unit time',
      },
      {
        parameter: 'Heat Flux',
        symbol: "q''",
        value: `${formatNum(results.qFlux, 2)} (${formatEng(results.qFlux, 3)}W/m²)`,
        unit: 'W/m²',
        description: 'Heat transfer rate per unit cross-sectional area (Q / A)',
      },
    ];
  }, [results]);

  // Assumptions
  const assumptions = [
    'Steady-state one-dimensional heat transfer in the x-direction.',
    'Uniform, isotropic material with constant thermal conductivity (k independent of temperature).',
    'No internal volumetric thermal energy generation (q̇ = 0).',
    'Constant planar cross-sectional area (A) along the conduction path.',
    'Negligible contact resistance at the boundary surfaces.',
  ];

  // Engineering Interpretation
  const interpretation = `Under the specified steady-state operating conditions, a heat transfer rate of ${formatNum(
    results.q,
    2
  )} W (${formatEng(results.q, 2)}W) passes through the solid wall with a conductive thermal resistance of ${formatNum(
    results.rCond,
    4
  )} K/W. The heat flux is ${formatNum(
    results.qFlux,
    2
  )} W/m². Because thermal conductivity k is uniform and the geometry is planar 1D, the spatial temperature distribution is strictly linear from ${
    inputs.tHot
  } K down to ${
    inputs.tCold
  } K. Increasing the wall thickness L will proportionally increase thermal resistance and reduce heat loss; increasing conductivity k will increase heat dissipation.`;

  // Export handlers
  const handleExportCsv = () => {
    const exportData = [
      { Category: 'Metadata', Parameter: 'Analysis Type', Value: 'Conduction Analysis (Fourier Law)', Unit: '-' },
      { Category: 'Metadata', Parameter: 'Timestamp', Value: new Date().toISOString(), Unit: '-' },
      { Category: 'Input', Parameter: 'Material Preset', Value: inputs.materialPreset, Unit: '-' },
      { Category: 'Input', Parameter: 'Thermal Conductivity (k)', Value: inputs.k, Unit: 'W/m·K' },
      { Category: 'Input', Parameter: 'Cross-sectional Area (A)', Value: inputs.area, Unit: 'm²' },
      { Category: 'Input', Parameter: 'Wall Thickness (L)', Value: inputs.length, Unit: 'm' },
      { Category: 'Input', Parameter: 'Hot Surface Temperature (T_hot)', Value: inputs.tHot, Unit: 'K' },
      { Category: 'Input', Parameter: 'Cold Surface Temperature (T_cold)', Value: inputs.tCold, Unit: 'K' },
      { Category: 'Result', Parameter: 'Temperature Difference (ΔT)', Value: results.deltaT, Unit: 'K' },
      { Category: 'Result', Parameter: 'Thermal Resistance (R_cond)', Value: results.rCond, Unit: 'K/W' },
      { Category: 'Result', Parameter: 'Heat-Transfer Rate (Q)', Value: results.q, Unit: 'W' },
      { Category: 'Result', Parameter: 'Heat Flux (q flux)', Value: results.qFlux, Unit: 'W/m²' },
    ];
    downloadCsv(`THERMO_X_Conduction_Results_${Date.now()}.csv`, exportData);
  };

  const handleExportPdf = () => {
    generatePdfReport({
      analysisTitle: "1D Plane Wall Conduction Analysis (Fourier's Law)",
      analysisType: 'Conduction',
      governingEquation: "Q = (k * A * (T_hot - T_cold)) / L = ΔT / R_cond,  q'' = Q / A",
      inputs: [
        { name: 'Thermal Conductivity', symbol: 'k', value: String(inputs.k), unit: 'W/m·K' },
        { name: 'Cross-Sectional Area', symbol: 'A', value: String(inputs.area), unit: 'm²' },
        { name: 'Wall Thickness', symbol: 'L', value: String(inputs.length), unit: 'm' },
        { name: 'Hot Side Temperature', symbol: 'T_hot', value: String(inputs.tHot), unit: 'K' },
        { name: 'Cold Side Temperature', symbol: 'T_cold', value: String(inputs.tCold), unit: 'K' },
      ],
      results: tableRows,
      assumptions,
      interpretation,
      validationNotes: [
        'Calculations verify Fourier 1D steady-state conductive transport.',
        'Thermal resistance verified as R_cond = L / (k * A).',
        'Consistency verified: Q = ΔT / R_cond.',
      ],
    });
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-orange-400 font-bold text-xs uppercase tracking-wider mb-1">
            <Layers className="w-4 h-4 text-orange-400" />
            <span className="font-mono text-[11px]">THERMAL CONDUCTION ANALYSIS</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">Fourier&apos;s Law — 1D Solid Plane Wall</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            One-dimensional steady-state conduction through homogeneous plane materials.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            id="conduction-export-csv"
            onClick={handleExportCsv}
            className="px-3.5 py-1.5 bg-slate-800/90 hover:bg-slate-700/90 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700/80 flex items-center gap-1.5 transition-colors"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>
          <button
            id="conduction-export-pdf"
            onClick={handleExportPdf}
            className="px-3.5 py-1.5 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-orange-600/20 border border-orange-400/30 flex items-center gap-1.5 transition-all"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Export PDF Report</span>
          </button>
        </div>
      </div>

      {/* Warnings & Alerts */}
      {results.warnings.length > 0 && (
        <div className="space-y-2">
          {results.warnings.map((w, idx) => (
            <div
              key={idx}
              className={`p-3.5 rounded-xl border text-xs flex items-start gap-2.5 ${
                results.isValid
                  ? 'bg-amber-950/30 border-amber-500/40 text-amber-300'
                  : 'bg-red-950/30 border-red-500/40 text-red-300'
              }`}
            >
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{w}</span>
            </div>
          ))}
        </div>
      )}

      {/* Workspace: Inputs (Left) and Key Output Metrics (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* INPUTS COLUMN */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-orange-400" />
                <h2 className="font-bold text-white text-sm">Operating Parameters</h2>
              </div>
              <span className="text-[10px] bg-slate-800/90 text-slate-300 px-2 py-0.5 rounded font-mono border border-slate-700/60">SI Units</span>
            </div>

            {/* Material Preset */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Material Preset</label>
              <select
                id="conduction-material-select"
                value={inputs.materialPreset}
                onChange={(e) => handlePresetChange(e.target.value)}
                className="w-full bg-[#090d16] border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-medium text-slate-200 focus:ring-2 focus:ring-orange-500/50 focus:border-orange-500 focus:outline-none"
              >
                {MATERIAL_PRESETS.map((m) => (
                  <option key={m.name} value={m.name} className="bg-slate-900 text-slate-200">
                    {m.name} ({m.k} W/m·K)
                  </option>
                ))}
              </select>
            </div>

            {/* Thermal Conductivity k */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                <span>Thermal Conductivity (k)</span>
                <span className="text-slate-400 font-mono text-[11px]">W/m·K</span>
              </div>
              <input
                id="conduction-input-k"
                type="number"
                step="0.01"
                min="0.001"
                value={inputs.k}
                onChange={(e) =>
                  setInputs((prev) => ({
                    ...prev,
                    materialPreset: 'Custom Material',
                    k: parseFloat(e.target.value) || 0,
                  }))
                }
                className="w-full bg-[#090d16] border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-mono text-white focus:ring-2 focus:ring-orange-500/50 focus:border-orange-500 focus:outline-none"
              />
            </div>

            {/* Cross-sectional Area A */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                <span>Cross-Sectional Area (A)</span>
                <span className="text-slate-400 font-mono text-[11px]">m²</span>
              </div>
              <input
                id="conduction-input-area"
                type="number"
                step="0.1"
                min="0.001"
                value={inputs.area}
                onChange={(e) => setInputs((prev) => ({ ...prev, area: parseFloat(e.target.value) || 0 }))}
                className="w-full bg-[#090d16] border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-mono text-white focus:ring-2 focus:ring-orange-500/50 focus:border-orange-500 focus:outline-none"
              />
            </div>

            {/* Wall Thickness L */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                <span>Wall Thickness (L)</span>
                <span className="text-slate-400 font-mono text-[11px]">m</span>
              </div>
              <input
                id="conduction-input-length"
                type="number"
                step="0.01"
                min="0.0001"
                value={inputs.length}
                onChange={(e) => setInputs((prev) => ({ ...prev, length: parseFloat(e.target.value) || 0 }))}
                className="w-full bg-[#090d16] border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-mono text-white focus:ring-2 focus:ring-orange-500/50 focus:border-orange-500 focus:outline-none"
              />
            </div>

            {/* Temperatures: T_hot and T_cold */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                  <span>Hot Temp (T_hot)</span>
                  <span className="text-slate-400 font-mono text-[11px]">K</span>
                </div>
                <input
                  id="conduction-input-thot"
                  type="number"
                  step="1"
                  min="1"
                  value={inputs.tHot}
                  onChange={(e) => setInputs((prev) => ({ ...prev, tHot: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-[#090d16] border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-mono text-white focus:ring-2 focus:ring-orange-500/50 focus:border-orange-500 focus:outline-none"
                />
                <span className="text-[10px] font-mono text-slate-400 mt-1 block">
                  {(inputs.tHot - 273.15).toFixed(1)} °C
                </span>
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                  <span>Cold Temp (T_cold)</span>
                  <span className="text-slate-400 font-mono text-[11px]">K</span>
                </div>
                <input
                  id="conduction-input-tcold"
                  type="number"
                  step="1"
                  min="1"
                  value={inputs.tCold}
                  onChange={(e) => setInputs((prev) => ({ ...prev, tCold: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-[#090d16] border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-mono text-white focus:ring-2 focus:ring-orange-500/50 focus:border-orange-500 focus:outline-none"
                />
                <span className="text-[10px] font-mono text-slate-400 mt-1 block">
                  {(inputs.tCold - 273.15).toFixed(1)} °C
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* RESULTS & METRICS COLUMN */}
        <div className="lg:col-span-7 space-y-4">
          {/* Key Metric Cards Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-2 gap-3">
            <div className="bg-[#0e1628]/90 rounded-2xl p-4 border border-slate-800/90 shadow-xl">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">Heat Transfer Rate (Q)</div>
              <div className="text-2xl font-extrabold text-orange-400 mt-1 font-mono">
                {results.isValid ? formatEng(results.q, 3) + 'W' : '—'}
              </div>
              <div className="text-xs text-slate-400 mt-0.5 font-mono">
                {results.isValid ? `${formatNum(results.q, 2)} W` : 'Invalid Inputs'}
              </div>
            </div>

            <div className="bg-[#0e1628]/90 rounded-2xl p-4 border border-slate-800/90 shadow-xl">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">Heat Flux (q&apos;&apos;)</div>
              <div className="text-2xl font-extrabold text-white mt-1 font-mono">
                {results.isValid ? formatEng(results.qFlux, 3) + 'W/m²' : '—'}
              </div>
              <div className="text-xs text-slate-400 mt-0.5 font-mono">
                {results.isValid ? `${formatNum(results.qFlux, 2)} W/m²` : 'Invalid Inputs'}
              </div>
            </div>

            <div className="bg-[#0e1628]/90 rounded-2xl p-4 border border-slate-800/90 shadow-xl">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">Thermal Resistance (R_cond)</div>
              <div className="text-2xl font-extrabold text-white mt-1 font-mono">
                {results.isValid ? formatNum(results.rCond, 4) : '—'}
              </div>
              <div className="text-xs text-slate-400 mt-0.5 font-mono">K/W [Kelvin per Watt]</div>
            </div>

            <div className="bg-[#0e1628]/90 rounded-2xl p-4 border border-slate-800/90 shadow-xl">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">Temperature Potential (ΔT)</div>
              <div className="text-2xl font-extrabold text-amber-400 mt-1 font-mono">
                {results.isValid ? formatNum(results.deltaT, 2) : '—'}
              </div>
              <div className="text-xs text-slate-400 mt-0.5 font-mono">K (or °C difference)</div>
            </div>
          </div>

          {/* Dynamic Interactive Chart */}
          <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl">
            <div className="flex items-center justify-between mb-3 border-b border-slate-800/80 pb-2">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-orange-400" />
                <h3 className="font-bold text-white text-sm">Temperature Distribution T(x) Through Wall</h3>
              </div>
              <span className="text-xs text-slate-400 font-mono">x = 0 to {inputs.length} m</span>
            </div>

            <div className="h-56 w-full">
              {results.isValid && profileData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={profileData} margin={{ top: 10, right: 20, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis
                      dataKey="x"
                      stroke="#64748b"
                      label={{ value: 'Distance x [m]', position: 'insideBottomRight', offset: -5, fontSize: 11, fill: '#94a3b8' }}
                      tick={{ fontSize: 11, fill: '#94a3b8' }}
                    />
                    <YAxis
                      domain={['dataMin - 10', 'dataMax + 10']}
                      stroke="#64748b"
                      label={{ value: 'Temperature T [K]', angle: -90, position: 'insideLeft', fontSize: 11, fill: '#94a3b8' }}
                      tick={{ fontSize: 11, fill: '#94a3b8' }}
                    />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', color: '#f8fafc' }}
                      formatter={(val: any) => [`${val} K (${(Number(val) - 273.15).toFixed(1)} °C)`, 'Temperature']}
                      labelFormatter={(label) => `Position x: ${label} m`}
                    />
                    <Line
                      type="monotone"
                      dataKey="temperature"
                      name="Temperature Profile"
                      stroke="#f97316"
                      strokeWidth={2.5}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-xs text-slate-500">
                  Enter valid non-zero parameters to render temperature distribution.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Engineering Calculation Display (Prompt Section 14) */}
      <div className="bg-[#0e1628]/90 rounded-2xl p-5 sm:p-6 border border-slate-800/90 shadow-xl space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-800/80 pb-3">
          <Info className="w-4 h-4 text-orange-400" />
          <h2 className="font-bold text-white text-base">Engineering Calculation Breakdown</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
          <div className="p-4 bg-[#090d16]/90 rounded-xl border border-slate-800/80">
            <div className="font-sans font-bold text-slate-300 text-xs mb-2">1. Governing Equations</div>
            <div className="text-slate-200 font-bold space-y-1.5">
              <div>R_cond = L / (k &bull; A)</div>
              <div>Q = (k &bull; A &bull; ΔT) / L</div>
              <div>q&apos;&apos; = Q / A = ΔT / (R_cond &bull; A)</div>
            </div>
          </div>

          <div className="p-4 bg-[#090d16]/90 rounded-xl border border-slate-800/80">
            <div className="font-sans font-bold text-slate-300 text-xs mb-2">2. Numerical Substitution</div>
            <div className="text-slate-300 space-y-1.5">
              <div>R = {inputs.length} / ({inputs.k} &bull; {inputs.area}) = {formatNum(results.rCond, 4)} K/W</div>
              <div>ΔT = {inputs.tHot} - {inputs.tCold} = {formatNum(results.deltaT, 2)} K</div>
              <div>Q = {formatNum(results.deltaT, 2)} / {formatNum(results.rCond, 4)}</div>
            </div>
          </div>

          <div className="p-4 bg-orange-950/20 rounded-xl border border-orange-500/30">
            <div className="font-sans font-bold text-orange-400 text-xs mb-2">3. Final Computed Values</div>
            <div className="text-orange-300 font-bold space-y-1.5">
              <div>Q = {formatNum(results.q, 3)} W</div>
              <div>q&apos;&apos; = {formatNum(results.qFlux, 3)} W/m²</div>
              <div>R_cond = {formatNum(results.rCond, 4)} K/W</div>
            </div>
          </div>
        </div>
      </div>

      {/* Pandas-Style Results Table (Prompt Section 15) */}
      <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800/80 pb-3">
          <h3 className="font-bold text-white text-sm">Principal Engineering Results Table</h3>
          <span className="text-xs font-mono text-slate-400">SI Engineering Quantities</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#090d16] text-slate-300 font-bold border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Parameter Description</th>
                <th className="py-2.5 px-3">Symbol</th>
                <th className="py-2.5 px-3 text-right">Calculated Value</th>
                <th className="py-2.5 px-3">SI Unit</th>
                <th className="py-2.5 px-3">Engineering Definition</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 font-mono">
              {tableRows.map((row) => (
                <tr key={row.parameter} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-3 font-sans font-semibold text-slate-200">{row.parameter}</td>
                  <td className="py-2.5 px-3 text-orange-400 font-bold">{row.symbol}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-white">{row.value}</td>
                  <td className="py-2.5 px-3 text-slate-400 font-sans">{row.unit}</td>
                  <td className="py-2.5 px-3 text-slate-400 font-sans">{row.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Assumptions & Interpretation Sections (Prompt Section 19 & 22) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Assumptions */}
        <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl space-y-3">
          <div className="flex items-center gap-2 border-b border-slate-800/80 pb-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <h3 className="font-bold text-white text-sm">Governing Assumptions</h3>
          </div>
          <ul className="text-xs text-slate-300 space-y-2">
            {assumptions.map((item, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-orange-400 font-bold">&bull;</span>
                <span className="leading-relaxed">{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Engineering Interpretation */}
        <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl space-y-3">
          <div className="flex items-center gap-2 border-b border-slate-800/80 pb-2">
            <Info className="w-4 h-4 text-cyan-400" />
            <h3 className="font-bold text-white text-sm">Engineering Interpretation</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">{interpretation}</p>
        </div>
      </div>
    </div>
  );
};
