import React, { useState, useMemo } from 'react';
import {
  Network,
  FileSpreadsheet,
  FileText,
  AlertTriangle,
  CheckCircle2,
  Info,
  Sliders,
  TrendingUp,
  Plus,
  Trash2,
  Layers,
  Wind,
} from 'lucide-react';
import { ThermalResistanceInputs, ThermalResistanceLayer, ResultTableRow } from '../types';
import { calculateThermalResistance, formatEng, formatNum } from '../utils/calculations';
import { generatePdfReport, downloadCsv } from '../utils/reportGenerator';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
} from 'recharts';

export const ThermalResistanceView: React.FC = () => {
  const [inputs, setInputs] = useState<ThermalResistanceInputs>({
    tInletFluid: 370.0, // Hot inside fluid [K] (approx 96.85 °C)
    tOutletFluid: 290.0, // Cold outside fluid [K] (approx 16.85 °C)
    layers: [
      {
        id: '1',
        name: 'Inside Convection (Air)',
        type: 'convection',
        h: 25.0,
        area: 4.0,
      },
      {
        id: '2',
        name: 'Brick Wall Layer',
        type: 'conduction',
        k: 0.72,
        thickness: 0.12,
        area: 4.0,
      },
      {
        id: '3',
        name: 'Fiberglass Insulation',
        type: 'conduction',
        k: 0.038,
        thickness: 0.05,
        area: 4.0,
      },
      {
        id: '4',
        name: 'Outside Convection (Wind)',
        type: 'convection',
        h: 50.0,
        area: 4.0,
      },
    ],
  });

  const results = useMemo(() => calculateThermalResistance(inputs), [inputs]);

  // Chart data: Resistance contribution breakdown
  const chartData = useMemo(() => {
    return results.layers.map((l, idx) => ({
      name: `L${idx + 1}: ${l.layer.name}`,
      resistance: Number(l.rValue.toFixed(4)),
      percent: Number(l.percentOfTotal.toFixed(1)),
      deltaT: Number(l.deltaT.toFixed(1)),
    }));
  }, [results]);

  const tableRows: ResultTableRow[] = useMemo(() => {
    const rows: ResultTableRow[] = [
      {
        parameter: 'Overall Heat Transfer Rate',
        symbol: 'Q',
        value: `${formatNum(results.q, 2)} (${formatEng(results.q, 3)}W)`,
        unit: 'W',
        description: 'Total steady heat rate through resistance network (ΔT_total / R_total)',
      },
      {
        parameter: 'Total Thermal Resistance',
        symbol: 'R_total',
        value: formatNum(results.rTotal, 4),
        unit: 'K/W',
        description: 'Equivalent series network resistance (Σ R_i)',
      },
      {
        parameter: 'Overall Heat Transfer Coeff',
        symbol: 'U_overall',
        value: formatNum(results.uOverall, 3),
        unit: 'W/m²·K',
        description: 'Overall heat transfer coefficient (1 / [R_total · A])',
      },
      {
        parameter: 'Average Heat Flux',
        symbol: "q''",
        value: `${formatNum(results.qFlux, 2)} (${formatEng(results.qFlux, 3)}W/m²)`,
        unit: 'W/m²',
        description: 'Heat transfer rate per unit area (Q / A)',
      },
    ];

    // Append individual layers to table
    results.layers.forEach((l, idx) => {
      rows.push({
        parameter: `Layer ${idx + 1}: ${l.layer.name}`,
        symbol: `R_${idx + 1}`,
        value: `${formatNum(l.rValue, 4)} K/W (${l.percentOfTotal.toFixed(1)}%) | ΔT = ${formatNum(l.deltaT, 1)}K`,
        unit: 'K/W',
        description: `T_in = ${formatNum(l.tIn, 1)}K → T_out = ${formatNum(l.tOut, 1)}K`,
      });
    });

    return rows;
  }, [results]);

  const assumptions = [
    'One-dimensional steady-state heat flow through planar layers.',
    'Perfect thermal contact between adjacent solid layers (unless contact resistance is explicitly added).',
    'Uniform convective heat-transfer coefficients on both fluid boundaries.',
    'Material thermal conductivities and layer cross-sectional areas remain uniform and constant.',
  ];

  const interpretation = `Under steady-state conditions with total temperature driving potential ΔT = ${formatNum(
    results.deltaTTotal,
    1
  )} K, the total series thermal resistance is ${formatNum(
    results.rTotal,
    4
  )} K/W, yielding a net heat transfer rate of ${formatNum(
    results.q,
    2
  )} W (${formatEng(results.q, 2)}W). ${
    results.layers.length > 0
      ? `The dominant thermal resistance is layer "${
          results.layers.reduce((prev, curr) => (curr.rValue > prev.rValue ? curr : prev), results.layers[0]).layer.name
        }" which accounts for ${Math.max(...results.layers.map((l) => l.percentOfTotal)).toFixed(
          1
        )}% of total thermal resistance and sustains the largest temperature drop.`
      : ''
  }`;

  const handleAddLayer = (type: 'conduction' | 'convection') => {
    const newId = String(Date.now());
    const newLayer: ThermalResistanceLayer =
      type === 'conduction'
        ? {
            id: newId,
            name: `New Solid Layer`,
            type: 'conduction',
            k: 1.0,
            thickness: 0.05,
            area: inputs.layers[0]?.area || 4.0,
          }
        : {
            id: newId,
            name: `New Boundary Fluid`,
            type: 'convection',
            h: 30.0,
            area: inputs.layers[0]?.area || 4.0,
          };
    setInputs((prev) => ({
      ...prev,
      layers: [...prev.layers, newLayer],
    }));
  };

  const handleRemoveLayer = (id: string) => {
    setInputs((prev) => ({
      ...prev,
      layers: prev.layers.filter((l) => l.id !== id),
    }));
  };

  const handleUpdateLayer = (id: string, partial: Partial<ThermalResistanceLayer>) => {
    setInputs((prev) => ({
      ...prev,
      layers: prev.layers.map((l) => (l.id === id ? { ...l, ...partial } : l)),
    }));
  };

  const handleExportCsv = () => {
    const exportData = [
      { Category: 'Metadata', Parameter: 'Analysis Type', Value: 'Thermal Resistance Network (Series)', Unit: '-' },
      { Category: 'Metadata', Parameter: 'Timestamp', Value: new Date().toISOString(), Unit: '-' },
      { Category: 'Input', Parameter: 'Inside Fluid Temp (T_inlet)', Value: inputs.tInletFluid, Unit: 'K' },
      { Category: 'Input', Parameter: 'Outside Fluid Temp (T_outlet)', Value: inputs.tOutletFluid, Unit: 'K' },
      { Category: 'Result', Parameter: 'Total Thermal Resistance (R_total)', Value: results.rTotal, Unit: 'K/W' },
      { Category: 'Result', Parameter: 'Total Heat Rate (Q)', Value: results.q, Unit: 'W' },
      { Category: 'Result', Parameter: 'Overall U', Value: results.uOverall, Unit: 'W/m²·K' },
      ...results.layers.map((l, i) => ({
        Category: `Layer_${i + 1}`,
        Parameter: l.layer.name,
        Value: `${l.rValue.toFixed(4)} K/W (${l.percentOfTotal.toFixed(1)}%) [ΔT=${l.deltaT.toFixed(1)}K]`,
        Unit: 'K/W',
      })),
    ];
    downloadCsv(`THERMO_X_ThermalResistance_Results_${Date.now()}.csv`, exportData);
  };

  const handleExportPdf = () => {
    generatePdfReport({
      analysisTitle: 'Thermal Resistance Network Analysis (Series Composite)',
      analysisType: 'ThermalResistance',
      governingEquation: 'R_total = Σ R_i = R_conv,1 + Σ(L_i / k_i A) + R_conv,2,  Q = (T_in - T_out) / R_total',
      inputs: [
        { name: 'Inside Fluid Temperature', symbol: 'T_inlet', value: String(inputs.tInletFluid), unit: 'K' },
        { name: 'Outside Fluid Temperature', symbol: 'T_outlet', value: String(inputs.tOutletFluid), unit: 'K' },
        { name: 'Number of Series Layers', symbol: 'N', value: String(inputs.layers.length), unit: '-' },
      ],
      results: tableRows,
      assumptions,
      interpretation,
      validationNotes: [
        'Series thermal resistance network evaluated using electrical analogy.',
        'Verified: Q = ΔT_total / R_total = ΔT_i / R_i for each constituent layer.',
        'Interface temperatures verified across all solid/fluid boundaries.',
      ],
    });
  };

  const COLORS = ['#ea580c', '#3b82f6', '#10b981', '#8b5cf6', '#f59e0b', '#06b6d4'];

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase tracking-wider mb-1">
            <Network className="w-4 h-4 text-emerald-400" />
            <span className="font-mono text-[11px]">THERMAL RESISTANCE NETWORK</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">Series Composite Wall Network</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Combined conduction and boundary convection series resistance evaluation.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            id="tr-export-csv"
            onClick={handleExportCsv}
            className="px-3.5 py-1.5 bg-slate-800/90 hover:bg-slate-700/90 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700/80 flex items-center gap-1.5 transition-colors"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>
          <button
            id="tr-export-pdf"
            onClick={handleExportPdf}
            className="px-3.5 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-emerald-600/20 border border-emerald-400/30 flex items-center gap-1.5 transition-all"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Export PDF Report</span>
          </button>
        </div>
      </div>

      {/* Warnings */}
      {results.warnings.length > 0 && (
        <div className="space-y-2">
          {results.warnings.map((w, idx) => (
            <div
              key={idx}
              className={`p-3.5 rounded-xl border text-xs flex items-start gap-2.5 ${
                results.isValid
                  ? 'bg-amber-950/30 border-amber-500/40 text-amber-300'
                  : 'bg-red-950/30 border-red-500/40 text-red-300'
              }`}
            >
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{w}</span>
            </div>
          ))}
        </div>
      )}

      {/* Layer Configuration Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN: Layer Builder */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-emerald-400" />
                <h2 className="font-bold text-white text-sm">Boundary Temperatures &amp; Series Layers</h2>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  id="tr-add-conduction"
                  onClick={() => handleAddLayer('conduction')}
                  className="px-2.5 py-1 bg-slate-800/90 hover:bg-slate-700/90 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700/80 flex items-center gap-1 transition-colors"
                >
                  <Plus className="w-3 h-3 text-emerald-400" />
                  <span>Add Solid</span>
                </button>
                <button
                  type="button"
                  id="tr-add-convection"
                  onClick={() => handleAddLayer('convection')}
                  className="px-2.5 py-1 bg-slate-800/90 hover:bg-slate-700/90 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700/80 flex items-center gap-1 transition-colors"
                >
                  <Plus className="w-3 h-3 text-cyan-400" />
                  <span>Add Fluid</span>
                </button>
              </div>
            </div>

            {/* Overall Fluid Boundary Temperatures */}
            <div className="grid grid-cols-2 gap-3 p-3.5 bg-[#090d16]/90 rounded-xl border border-slate-800/80">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Inside Fluid Temp (T_in)</label>
                <input
                  id="tr-input-tin"
                  type="number"
                  step="1"
                  value={inputs.tInletFluid}
                  onChange={(e) => setInputs((prev) => ({ ...prev, tInletFluid: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-[#0e1628] border border-slate-700/80 rounded-lg px-2.5 py-1.5 text-xs font-mono text-white focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 focus:outline-none"
                />
                <span className="text-[10px] font-mono text-slate-400">{(inputs.tInletFluid - 273.15).toFixed(1)} °C</span>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Outside Fluid Temp (T_out)</label>
                <input
                  id="tr-input-tout"
                  type="number"
                  step="1"
                  value={inputs.tOutletFluid}
                  onChange={(e) => setInputs((prev) => ({ ...prev, tOutletFluid: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-[#0e1628] border border-slate-700/80 rounded-lg px-2.5 py-1.5 text-xs font-mono text-white focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 focus:outline-none"
                />
                <span className="text-[10px] font-mono text-slate-400">{(inputs.tOutletFluid - 273.15).toFixed(1)} °C</span>
              </div>
            </div>

            {/* Individual Layer Cards */}
            <div className="space-y-3">
              {inputs.layers.map((layer, idx) => (
                <div
                  key={layer.id}
                  className="p-3.5 rounded-xl border border-slate-800/80 bg-[#090d16]/90 hover:border-slate-700 space-y-2.5 transition-all"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center justify-center text-[10px] font-bold">
                        {idx + 1}
                      </span>
                      <input
                        type="text"
                        value={layer.name}
                        onChange={(e) => handleUpdateLayer(layer.id, { name: e.target.value })}
                        className="font-bold text-xs text-white bg-transparent border-b border-transparent hover:border-slate-600 focus:border-emerald-500 focus:outline-none px-1"
                      />
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800/90 text-slate-300 border border-slate-700/60">
                        {layer.type.toUpperCase()}
                      </span>
                    </div>

                    {inputs.layers.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleRemoveLayer(layer.id)}
                        className="text-slate-500 hover:text-red-400 p-1 transition-colors"
                        title="Remove layer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  {/* Layer parameter inputs */}
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    {layer.type === 'convection' ? (
                      <>
                        <div className="col-span-2">
                          <label className="block text-[10px] font-semibold text-slate-400">h [W/m²·K]</label>
                          <input
                            type="number"
                            step="1"
                            min="0.1"
                            value={layer.h || 0}
                            onChange={(e) => handleUpdateLayer(layer.id, { h: parseFloat(e.target.value) || 0 })}
                            className="w-full bg-[#0e1628] border border-slate-700/80 rounded-lg px-2 py-1 font-mono text-xs text-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-semibold text-slate-400">Area A [m²]</label>
                          <input
                            type="number"
                            step="0.1"
                            min="0.001"
                            value={layer.area}
                            onChange={(e) => handleUpdateLayer(layer.id, { area: parseFloat(e.target.value) || 0 })}
                            className="w-full bg-[#0e1628] border border-slate-700/80 rounded-lg px-2 py-1 font-mono text-xs text-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                          />
                        </div>
                      </>
                    ) : (
                      <>
                        <div>
                          <label className="block text-[10px] font-semibold text-slate-400">k [W/m·K]</label>
                          <input
                            type="number"
                            step="0.01"
                            min="0.001"
                            value={layer.k || 0}
                            onChange={(e) => handleUpdateLayer(layer.id, { k: parseFloat(e.target.value) || 0 })}
                            className="w-full bg-[#0e1628] border border-slate-700/80 rounded-lg px-2 py-1 font-mono text-xs text-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-semibold text-slate-400">Thickness L [m]</label>
                          <input
                            type="number"
                            step="0.01"
                            min="0.001"
                            value={layer.thickness || 0}
                            onChange={(e) =>
                              handleUpdateLayer(layer.id, { thickness: parseFloat(e.target.value) || 0 })
                            }
                            className="w-full bg-[#0e1628] border border-slate-700/80 rounded-lg px-2 py-1 font-mono text-xs text-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-semibold text-slate-400">Area A [m²]</label>
                          <input
                            type="number"
                            step="0.1"
                            min="0.001"
                            value={layer.area}
                            onChange={(e) => handleUpdateLayer(layer.id, { area: parseFloat(e.target.value) || 0 })}
                            className="w-full bg-[#0e1628] border border-slate-700/80 rounded-lg px-2 py-1 font-mono text-xs text-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                          />
                        </div>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Output Summary & Resistance Breakdown Chart */}
        <div className="lg:col-span-5 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[#0e1628]/90 rounded-2xl p-4 border border-slate-800/90 shadow-xl">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">Total Heat Rate (Q)</div>
              <div className="text-xl sm:text-2xl font-extrabold text-emerald-400 mt-1 font-mono">
                {results.isValid ? formatEng(results.q, 3) + 'W' : '—'}
              </div>
              <div className="text-xs text-slate-400 mt-0.5 font-mono">
                {results.isValid ? `${formatNum(results.q, 2)} W` : 'Invalid'}
              </div>
            </div>

            <div className="bg-[#0e1628]/90 rounded-2xl p-4 border border-slate-800/90 shadow-xl">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">Total Resistance (R_tot)</div>
              <div className="text-xl sm:text-2xl font-extrabold text-white mt-1 font-mono">
                {results.isValid ? formatNum(results.rTotal, 4) : '—'}
              </div>
              <div className="text-xs text-slate-400 mt-0.5 font-mono">K/W [Σ R_i]</div>
            </div>

            <div className="bg-[#0e1628]/90 rounded-2xl p-4 border border-slate-800/90 shadow-xl">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">Overall U-Value</div>
              <div className="text-xl sm:text-2xl font-extrabold text-white mt-1 font-mono">
                {results.isValid ? formatNum(results.uOverall, 3) : '—'}
              </div>
              <div className="text-xs text-slate-400 mt-0.5 font-mono">W/m²·K</div>
            </div>

            <div className="bg-[#0e1628]/90 rounded-2xl p-4 border border-slate-800/90 shadow-xl">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">Total ΔT Potential</div>
              <div className="text-xl sm:text-2xl font-extrabold text-white mt-1 font-mono">
                {results.isValid ? formatNum(results.deltaTTotal, 1) : '—'}
              </div>
              <div className="text-xs text-slate-400 mt-0.5 font-mono">K (or °C difference)</div>
            </div>
          </div>

          {/* Resistance Breakdown Chart */}
          <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl">
            <div className="flex items-center justify-between mb-3 border-b border-slate-800/80 pb-2">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <h3 className="font-bold text-white text-sm">Layer Resistance Contribution (K/W)</h3>
              </div>
              <span className="text-xs text-slate-400 font-mono">{inputs.layers.length} Series Layers</span>
            </div>

            <div className="h-56 w-full">
              {results.isValid && chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} layout="vertical" margin={{ top: 5, right: 20, left: 30, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis type="number" stroke="#64748b" tick={{ fontSize: 11, fill: '#94a3b8' }} label={{ value: 'R [K/W]', position: 'insideBottomRight', offset: -5, fontSize: 11, fill: '#94a3b8' }} />
                    <YAxis dataKey="name" stroke="#64748b" type="category" tick={{ fontSize: 10, fill: '#94a3b8' }} width={90} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', color: '#f8fafc' }}
                      formatter={(val: any, name: any, item: any) => [
                        `${val} K/W (${item.payload.percent}% of total) | ΔT = ${item.payload.deltaT}K`,
                        'Resistance',
                      ]}
                    />
                    <Bar dataKey="resistance" fill="#10b981" radius={[0, 4, 4, 0]}>
                      {chartData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-xs text-slate-500">
                  Configure layers to view resistance distribution.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Engineering Calculation Breakdown */}
      <div className="bg-[#0e1628]/90 rounded-2xl p-5 sm:p-6 border border-slate-800/90 shadow-xl space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-800/80 pb-3">
          <Info className="w-4 h-4 text-emerald-400" />
          <h2 className="font-bold text-white text-base">Engineering Calculation Breakdown</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
          <div className="p-4 bg-[#090d16]/90 rounded-xl border border-slate-800/80">
            <div className="font-sans font-bold text-slate-300 text-xs mb-2">1. Governing Equations</div>
            <div className="text-slate-200 font-bold space-y-1.5">
              <div>R_total = Σ R_i</div>
              <div>Q = (T_in - T_out) / R_total</div>
              <div>ΔT_i = Q &bull; R_i</div>
            </div>
          </div>

          <div className="p-4 bg-[#090d16]/90 rounded-xl border border-slate-800/80">
            <div className="font-sans font-bold text-slate-300 text-xs mb-2">2. Numerical Substitution</div>
            <div className="text-slate-300 space-y-1.5">
              <div>ΔT_total = {inputs.tInletFluid} - {inputs.tOutletFluid} = {formatNum(results.deltaTTotal, 1)} K</div>
              <div>R_total = {results.layers.map((l) => formatNum(l.rValue, 3)).join(' + ')}</div>
              <div>R_total = {formatNum(results.rTotal, 4)} K/W</div>
            </div>
          </div>

          <div className="p-4 bg-emerald-950/20 rounded-xl border border-emerald-500/30">
            <div className="font-sans font-bold text-emerald-400 text-xs mb-2">3. Final Computed Values</div>
            <div className="text-emerald-300 font-bold space-y-1.5">
              <div>Q = {formatNum(results.q, 3)} W</div>
              <div>U_overall = {formatNum(results.uOverall, 3)} W/m²·K</div>
              <div>q&apos;&apos; = {formatNum(results.qFlux, 3)} W/m²</div>
            </div>
          </div>
        </div>
      </div>

      {/* Results Table */}
      <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800/80 pb-3">
          <h3 className="font-bold text-white text-sm">Principal Engineering Results Table</h3>
          <span className="text-xs font-mono text-slate-400">SI Engineering Quantities</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#090d16] text-slate-300 font-bold border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Parameter Description</th>
                <th className="py-2.5 px-3">Symbol</th>
                <th className="py-2.5 px-3 text-right">Calculated Value</th>
                <th className="py-2.5 px-3">SI Unit</th>
                <th className="py-2.5 px-3">Engineering Definition</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 font-mono">
              {tableRows.map((row) => (
                <tr key={row.parameter} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-3 font-sans font-semibold text-slate-200">{row.parameter}</td>
                  <td className="py-2.5 px-3 text-emerald-400 font-bold">{row.symbol}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-white">{row.value}</td>
                  <td className="py-2.5 px-3 text-slate-400 font-sans">{row.unit}</td>
                  <td className="py-2.5 px-3 text-slate-400 font-sans">{row.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Assumptions & Interpretation */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl space-y-3">
          <div className="flex items-center gap-2 border-b border-slate-800/80 pb-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <h3 className="font-bold text-white text-sm">Governing Assumptions</h3>
          </div>
          <ul className="text-xs text-slate-300 space-y-2">
            {assumptions.map((item, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">&bull;</span>
                <span className="leading-relaxed">{item}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl space-y-3">
          <div className="flex items-center gap-2 border-b border-slate-800/80 pb-2">
            <Info className="w-4 h-4 text-emerald-400" />
            <h3 className="font-bold text-white text-sm">Engineering Interpretation</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">{interpretation}</p>
        </div>
      </div>
    </div>
  );
};
