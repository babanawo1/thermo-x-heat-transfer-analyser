import React, { useState, useMemo } from 'react';
import {
  GitCompare,
  FileSpreadsheet,
  FileText,
  AlertTriangle,
  CheckCircle2,
  Info,
  Sliders,
  TrendingUp,
  Activity,
} from 'lucide-react';
import { HeatExchangerInputs, ResultTableRow } from '../types';
import { calculateHeatExchanger, formatEng, formatNum } from '../utils/calculations';
import { generatePdfReport, downloadCsv } from '../utils/reportGenerator';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';

export const HeatExchangerView: React.FC = () => {
  const [inputs, setInputs] = useState<HeatExchangerInputs>({
    flowArrangement: 'counter_current',
    mDotHot: 1.5,
    cpHot: 4184.0, // Water J/kg·K
    tHotIn: 363.15, // 90 °C
    tHotOut: 323.15, // 50 °C
    mDotCold: 2.0,
    cpCold: 4184.0, // Water J/kg·K
    tColdIn: 293.15, // 20 °C
    tColdOut: 323.15, // 50 °C
    u: 850.0, // W/m²·K
    area: 12.0, // m²
  });

  const results = useMemo(() => calculateHeatExchanger(inputs), [inputs]);

  // Generate Profile Data for Temperature Distribution Chart along normalized length x/L = 0 to 1
  const profileData = useMemo(() => {
    if (!results.isValid) return [];
    const points = 21;
    const data = [];

    for (let i = 0; i < points; i++) {
      const xNorm = i / (points - 1);
      let tHotLocal = 0;
      let tColdLocal = 0;

      if (inputs.flowArrangement === 'counter_current') {
        // Linearized approximation for visualization along normalized length
        tHotLocal = inputs.tHotIn - (inputs.tHotIn - inputs.tHotOut) * xNorm;
        // In counter-flow, cold stream enters at xNorm = 1 and exits at xNorm = 0
        tColdLocal = inputs.tColdOut - (inputs.tColdOut - inputs.tColdIn) * xNorm;
      } else {
        // Parallel flow: both enter at xNorm = 0
        tHotLocal = inputs.tHotIn - (inputs.tHotIn - inputs.tHotOut) * (1 - Math.exp(-2.5 * xNorm));
        tColdLocal = inputs.tColdIn + (inputs.tColdOut - inputs.tColdIn) * (1 - Math.exp(-2.5 * xNorm));
      }

      data.push({
        x: Number(xNorm.toFixed(2)),
        hotTemp: Number(tHotLocal.toFixed(1)),
        coldTemp: Number(tColdLocal.toFixed(1)),
      });
    }
    return data;
  }, [inputs, results]);

  const tableRows: ResultTableRow[] = useMemo(() => {
    return [
      {
        parameter: 'Hot Stream Heat Capacity Rate',
        symbol: 'C_hot',
        value: `${formatNum(results.cHot, 1)} (${formatEng(results.cHot, 2)}W/K)`,
        unit: 'W/K',
        description: 'Heat capacity rate of hot fluid (ṁ_h · Cp_h)',
      },
      {
        parameter: 'Cold Stream Heat Capacity Rate',
        symbol: 'C_cold',
        value: `${formatNum(results.cCold, 1)} (${formatEng(results.cCold, 2)}W/K)`,
        unit: 'W/K',
        description: 'Heat capacity rate of cold fluid (ṁ_c · Cp_c)',
      },
      {
        parameter: 'Hot Stream Heat Released',
        symbol: 'Q_hot',
        value: `${formatNum(results.qHot, 1)} (${formatEng(results.qHot, 3)}W)`,
        unit: 'W',
        description: 'Thermal duty released by hot fluid stream',
      },
      {
        parameter: 'Cold Stream Heat Absorbed',
        symbol: 'Q_cold',
        value: `${formatNum(results.qCold, 1)} (${formatEng(results.qCold, 3)}W)`,
        unit: 'W',
        description: 'Thermal duty gained by cold fluid stream',
      },
      {
        parameter: 'Energy Balance Discrepancy',
        symbol: '|Q_h - Q_c|',
        value: `${formatNum(results.energyDiscrepancy, 1)} W (${results.energyDiscrepancyPercent.toFixed(2)}%)`,
        unit: 'W (%)',
        description: 'First Law adiabatic heat discrepancy',
      },
      {
        parameter: 'Log Mean Temperature Difference',
        symbol: 'LMTD',
        value: formatNum(results.lmtd, 2),
        unit: 'K',
        description: 'Effective mean driving temperature difference (ΔT1 - ΔT2) / ln(ΔT1/ΔT2)',
      },
      {
        parameter: 'Sizing Heat Transfer Rate',
        symbol: 'Q_sizing',
        value: `${formatNum(results.qSizing, 1)} (${formatEng(results.qSizing, 3)}W)`,
        unit: 'W',
        description: 'Exchanger heat duty from sizing relation (U · A · LMTD)',
      },
      {
        parameter: 'Maximum Possible Heat Rate',
        symbol: 'Q_max',
        value: `${formatNum(results.qMax, 1)} (${formatEng(results.qMax, 3)}W)`,
        unit: 'W',
        description: 'Thermodynamic maximum heat duty: C_min · (T_h,in - T_c,in)',
      },
      {
        parameter: 'Thermal Effectiveness',
        symbol: 'ε',
        value: formatNum(results.effectiveness, 4),
        unit: 'dimensionless',
        description: 'Ratio of actual heat transfer to maximum possible heat duty (Q / Q_max)',
      },
      {
        parameter: 'Number of Transfer Units',
        symbol: 'NTU',
        value: formatNum(results.ntu, 3),
        unit: 'dimensionless',
        description: 'Dimensionless sizing parameter (U · A / C_min)',
      },
    ];
  }, [results]);

  const assumptions = [
    'Steady-state operation with time-invariant flow rates and temperatures.',
    'Adiabatic outer shell (negligible heat loss to surrounding ambient environment).',
    'Constant specific heat capacities (Cp) and overall heat transfer coefficient (U) along exchanger length.',
    'Axial fluid conduction and kinetic/potential energy changes are negligible.',
    'No phase change (single-phase sensible heat transfer).',
  ];

  const interpretation = `The heat exchanger operating in ${
    inputs.flowArrangement === 'counter_current' ? 'Counter-Current' : 'Parallel Flow'
  } arrangement delivers an average heat duty of ${formatEng(results.qAverage, 2)}W. The Log Mean Temperature Difference (LMTD) is ${formatNum(
    results.lmtd,
    2
  )} K with a thermal effectiveness of ε = ${(results.effectiveness * 100).toFixed(
    1
  )}% and NTU = ${formatNum(results.ntu, 2)}. ${
    inputs.flowArrangement === 'counter_current'
      ? 'Counter-current flow maximizes the driving temperature difference across the entire length, allowing the cold outlet temperature to exceed the hot outlet temperature.'
      : 'In parallel flow, the maximum possible cold outlet temperature is asymptotically limited by the hot outlet temperature.'
  }`;

  const handleExportCsv = () => {
    const exportData = [
      { Category: 'Metadata', Parameter: 'Analysis Type', Value: 'Heat Exchanger (LMTD & ε-NTU)', Unit: '-' },
      { Category: 'Metadata', Parameter: 'Flow Arrangement', Value: inputs.flowArrangement, Unit: '-' },
      { Category: 'Input', Parameter: 'Hot Mass Flow (m_hot)', Value: inputs.mDotHot, Unit: 'kg/s' },
      { Category: 'Input', Parameter: 'Hot Specific Heat (Cp_hot)', Value: inputs.cpHot, Unit: 'J/kg·K' },
      { Category: 'Input', Parameter: 'Hot Inlet Temp (T_h,in)', Value: inputs.tHotIn, Unit: 'K' },
      { Category: 'Input', Parameter: 'Hot Outlet Temp (T_h,out)', Value: inputs.tHotOut, Unit: 'K' },
      { Category: 'Input', Parameter: 'Cold Mass Flow (m_cold)', Value: inputs.mDotCold, Unit: 'kg/s' },
      { Category: 'Input', Parameter: 'Cold Specific Heat (Cp_cold)', Value: inputs.cpCold, Unit: 'J/kg·K' },
      { Category: 'Input', Parameter: 'Cold Inlet Temp (T_c,in)', Value: inputs.tColdIn, Unit: 'K' },
      { Category: 'Input', Parameter: 'Cold Outlet Temp (T_c,out)', Value: inputs.tColdOut, Unit: 'K' },
      { Category: 'Input', Parameter: 'Overall U', Value: inputs.u, Unit: 'W/m²·K' },
      { Category: 'Input', Parameter: 'Area (A)', Value: inputs.area, Unit: 'm²' },
      { Category: 'Result', Parameter: 'LMTD', Value: results.lmtd, Unit: 'K' },
      { Category: 'Result', Parameter: 'Sizing Heat Rate (Q_sizing)', Value: results.qSizing, Unit: 'W' },
      { Category: 'Result', Parameter: 'Effectiveness (ε)', Value: results.effectiveness, Unit: '-' },
      { Category: 'Result', Parameter: 'NTU', Value: results.ntu, Unit: '-' },
    ];
    downloadCsv(`THERMO_X_HeatExchanger_Results_${Date.now()}.csv`, exportData);
  };

  const handleExportPdf = () => {
    generatePdfReport({
      analysisTitle: `Heat Exchanger Analysis (${inputs.flowArrangement === 'counter_current' ? 'Counter-Current' : 'Parallel'} Flow)`,
      analysisType: 'HeatExchanger',
      governingEquation: 'Q = U * A * LMTD,  LMTD = (ΔT1 - ΔT2) / ln(ΔT1 / ΔT2),  ε = Q_actual / Q_max',
      inputs: [
        { name: 'Flow Arrangement', symbol: 'Flow', value: inputs.flowArrangement, unit: '-' },
        { name: 'Hot Mass Flow Rate', symbol: 'ṁ_h', value: String(inputs.mDotHot), unit: 'kg/s' },
        { name: 'Hot Inlet / Outlet Temp', symbol: 'Th,in / Th,out', value: `${inputs.tHotIn} / ${inputs.tHotOut}`, unit: 'K' },
        { name: 'Cold Mass Flow Rate', symbol: 'ṁ_c', value: String(inputs.mDotCold), unit: 'kg/s' },
        { name: 'Cold Inlet / Outlet Temp', symbol: 'Tc,in / Tc,out', value: `${inputs.tColdIn} / ${inputs.tColdOut}`, unit: 'K' },
        { name: 'Overall Heat Transfer Coeff', symbol: 'U', value: String(inputs.u), unit: 'W/m²·K' },
        { name: 'Heat Transfer Area', symbol: 'A', value: String(inputs.area), unit: 'm²' },
      ],
      results: tableRows,
      assumptions,
      interpretation,
      validationNotes: [
        'First Law energy balances verified for both hot and cold streams.',
        'LMTD computed with automatic ΔT1 ≈ ΔT2 singularity handler.',
        'Second Law temperature crossover checks applied.',
        'Effectiveness-NTU parameters verified: ε = Q / Q_max, NTU = UA / C_min.',
      ],
    });
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-purple-400 font-bold text-xs uppercase tracking-wider mb-1">
            <GitCompare className="w-4 h-4 text-purple-400" />
            <span className="font-mono text-[11px]">HEAT EXCHANGER ANALYSIS</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">LMTD &amp; &epsilon;-NTU Analysis</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Thermal rating, sizing, energy balance validation, and effectiveness calculations.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            id="he-export-csv"
            onClick={handleExportCsv}
            className="px-3.5 py-1.5 bg-slate-800/90 hover:bg-slate-700/90 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700/80 flex items-center gap-1.5 transition-colors"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>
          <button
            id="he-export-pdf"
            onClick={handleExportPdf}
            className="px-3.5 py-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-purple-600/20 border border-purple-400/30 flex items-center gap-1.5 transition-all"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Export PDF Report</span>
          </button>
        </div>
      </div>

      {/* Warnings & Energy Balance Check */}
      {results.warnings.length > 0 && (
        <div className="space-y-2">
          {results.warnings.map((w, idx) => (
            <div
              key={idx}
              className={`p-3.5 rounded-xl border text-xs flex items-start gap-2.5 ${
                results.isValid
                  ? 'bg-amber-950/30 border-amber-500/40 text-amber-300'
                  : 'bg-red-950/30 border-red-500/40 text-red-300'
              }`}
            >
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{w}</span>
            </div>
          ))}
        </div>
      )}

      {/* Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* INPUTS COLUMN */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-purple-400" />
                <h2 className="font-bold text-white text-sm">Operating Parameters</h2>
              </div>
              <span className="text-[10px] bg-slate-800/90 text-slate-300 px-2 py-0.5 rounded font-mono border border-slate-700/60">SI Units</span>
            </div>

            {/* Flow Arrangement */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Flow Arrangement</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  id="he-flow-counter"
                  onClick={() => setInputs((prev) => ({ ...prev, flowArrangement: 'counter_current' }))}
                  className={`py-2 px-3 text-xs font-bold rounded-xl border transition-all ${
                    inputs.flowArrangement === 'counter_current'
                      ? 'bg-purple-600 text-white border-purple-500 shadow-md shadow-purple-600/30'
                      : 'bg-[#090d16] text-slate-400 border-slate-700/80 hover:bg-slate-800/60'
                  }`}
                >
                  Counter-Current Flow
                </button>
                <button
                  type="button"
                  id="he-flow-parallel"
                  onClick={() => setInputs((prev) => ({ ...prev, flowArrangement: 'parallel_flow' }))}
                  className={`py-2 px-3 text-xs font-bold rounded-xl border transition-all ${
                    inputs.flowArrangement === 'parallel_flow'
                      ? 'bg-purple-600 text-white border-purple-500 shadow-md shadow-purple-600/30'
                      : 'bg-[#090d16] text-slate-400 border-slate-700/80 hover:bg-slate-800/60'
                  }`}
                >
                  Parallel Flow
                </button>
              </div>
            </div>

            {/* Hot Stream Box */}
            <div className="p-3.5 bg-rose-950/20 rounded-xl border border-rose-500/30 space-y-2.5">
              <div className="text-xs font-bold text-rose-300 flex items-center justify-between">
                <span>Hot Fluid Stream</span>
                <span className="text-[10px] text-rose-400 font-mono">C_hot = {(results.cHot / 1e3).toFixed(2)} kW/K</span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-semibold text-slate-400">Mass Flow ṁ_h (kg/s)</label>
                  <input
                    id="he-input-mdothot"
                    type="number"
                    step="0.1"
                    min="0.001"
                    value={inputs.mDotHot}
                    onChange={(e) => setInputs((prev) => ({ ...prev, mDotHot: parseFloat(e.target.value) || 0 }))}
                    className="w-full bg-[#090d16] border border-slate-700/80 rounded-lg px-2 py-1 text-xs font-mono text-white focus:ring-1 focus:ring-rose-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-semibold text-slate-400">Spec. Heat Cp_h (J/kg·K)</label>
                  <input
                    id="he-input-cphot"
                    type="number"
                    step="10"
                    min="1"
                    value={inputs.cpHot}
                    onChange={(e) => setInputs((prev) => ({ ...prev, cpHot: parseFloat(e.target.value) || 0 }))}
                    className="w-full bg-[#090d16] border border-slate-700/80 rounded-lg px-2 py-1 text-xs font-mono text-white focus:ring-1 focus:ring-rose-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-semibold text-slate-400">Inlet Temp T_h,in (K)</label>
                  <input
                    id="he-input-thotin"
                    type="number"
                    step="1"
                    value={inputs.tHotIn}
                    onChange={(e) => setInputs((prev) => ({ ...prev, tHotIn: parseFloat(e.target.value) || 0 }))}
                    className="w-full bg-[#090d16] border border-slate-700/80 rounded-lg px-2 py-1 text-xs font-mono text-white focus:ring-1 focus:ring-rose-500 focus:outline-none"
                  />
                  <span className="text-[9px] font-mono text-slate-400">{(inputs.tHotIn - 273.15).toFixed(1)} °C</span>
                </div>
                <div>
                  <label className="block text-[10px] font-semibold text-slate-400">Outlet Temp T_h,out (K)</label>
                  <input
                    id="he-input-thotout"
                    type="number"
                    step="1"
                    value={inputs.tHotOut}
                    onChange={(e) => setInputs((prev) => ({ ...prev, tHotOut: parseFloat(e.target.value) || 0 }))}
                    className="w-full bg-[#090d16] border border-slate-700/80 rounded-lg px-2 py-1 text-xs font-mono text-white focus:ring-1 focus:ring-rose-500 focus:outline-none"
                  />
                  <span className="text-[9px] font-mono text-slate-400">{(inputs.tHotOut - 273.15).toFixed(1)} °C</span>
                </div>
              </div>
            </div>

            {/* Cold Stream Box */}
            <div className="p-3.5 bg-blue-950/20 rounded-xl border border-blue-500/30 space-y-2.5">
              <div className="text-xs font-bold text-cyan-300 flex items-center justify-between">
                <span>Cold Fluid Stream</span>
                <span className="text-[10px] text-cyan-400 font-mono">C_cold = {(results.cCold / 1e3).toFixed(2)} kW/K</span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-semibold text-slate-400">Mass Flow ṁ_c (kg/s)</label>
                  <input
                    id="he-input-mdotcold"
                    type="number"
                    step="0.1"
                    min="0.001"
                    value={inputs.mDotCold}
                    onChange={(e) => setInputs((prev) => ({ ...prev, mDotCold: parseFloat(e.target.value) || 0 }))}
                    className="w-full bg-[#090d16] border border-slate-700/80 rounded-lg px-2 py-1 text-xs font-mono text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-semibold text-slate-400">Spec. Heat Cp_c (J/kg·K)</label>
                  <input
                    id="he-input-cpcold"
                    type="number"
                    step="10"
                    min="1"
                    value={inputs.cpCold}
                    onChange={(e) => setInputs((prev) => ({ ...prev, cpCold: parseFloat(e.target.value) || 0 }))}
                    className="w-full bg-[#090d16] border border-slate-700/80 rounded-lg px-2 py-1 text-xs font-mono text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-semibold text-slate-400">Inlet Temp T_c,in (K)</label>
                  <input
                    id="he-input-tcoldin"
                    type="number"
                    step="1"
                    value={inputs.tColdIn}
                    onChange={(e) => setInputs((prev) => ({ ...prev, tColdIn: parseFloat(e.target.value) || 0 }))}
                    className="w-full bg-[#090d16] border border-slate-700/80 rounded-lg px-2 py-1 text-xs font-mono text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                  />
                  <span className="text-[9px] font-mono text-slate-400">{(inputs.tColdIn - 273.15).toFixed(1)} °C</span>
                </div>
                <div>
                  <label className="block text-[10px] font-semibold text-slate-400">Outlet Temp T_c,out (K)</label>
                  <input
                    id="he-input-tcoldout"
                    type="number"
                    step="1"
                    value={inputs.tColdOut}
                    onChange={(e) => setInputs((prev) => ({ ...prev, tColdOut: parseFloat(e.target.value) || 0 }))}
                    className="w-full bg-[#090d16] border border-slate-700/80 rounded-lg px-2 py-1 text-xs font-mono text-white focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                  />
                  <span className="text-[9px] font-mono text-slate-400">{(inputs.tColdOut - 273.15).toFixed(1)} °C</span>
                </div>
              </div>
            </div>

            {/* Sizing Parameters U & A */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Overall U (W/m²·K)</label>
                <input
                  id="he-input-u"
                  type="number"
                  step="10"
                  min="1"
                  value={inputs.u}
                  onChange={(e) => setInputs((prev) => ({ ...prev, u: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-[#090d16] border border-slate-700/80 rounded-xl px-3 py-1.5 text-xs font-mono text-white focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Area A (m²)</label>
                <input
                  id="he-input-area"
                  type="number"
                  step="0.5"
                  min="0.01"
                  value={inputs.area}
                  onChange={(e) => setInputs((prev) => ({ ...prev, area: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-[#090d16] border border-slate-700/80 rounded-xl px-3 py-1.5 text-xs font-mono text-white focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 focus:outline-none"
                />
              </div>
            </div>
          </div>
        </div>

        {/* RESULTS & METRICS COLUMN */}
        <div className="lg:col-span-7 space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="bg-[#0e1628]/90 rounded-2xl p-4 border border-slate-800/90 shadow-xl">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">Mean LMTD</div>
              <div className="text-xl font-extrabold text-purple-400 mt-1 font-mono">
                {results.isValid ? `${formatNum(results.lmtd, 2)} K` : '—'}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5 font-mono">
                ΔT1: {results.deltaT1.toFixed(1)}K, ΔT2: {results.deltaT2.toFixed(1)}K
              </div>
            </div>

            <div className="bg-[#0e1628]/90 rounded-2xl p-4 border border-slate-800/90 shadow-xl">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">Heat Duty (Q_sizing)</div>
              <div className="text-xl font-extrabold text-white mt-1 font-mono">
                {results.isValid ? formatEng(results.qSizing, 2) + 'W' : '—'}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5 font-mono">U &bull; A &bull; LMTD</div>
            </div>

            <div className="bg-[#0e1628]/90 rounded-2xl p-4 border border-slate-800/90 shadow-xl col-span-2 sm:col-span-1">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">Effectiveness (&epsilon;)</div>
              <div className="text-xl font-extrabold text-emerald-400 mt-1 font-mono">
                {results.isValid ? (results.effectiveness * 100).toFixed(1) + '%' : '—'}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5 font-mono">NTU: {formatNum(results.ntu, 2)}</div>
            </div>
          </div>

          {/* Temperature Profiles Chart */}
          <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl">
            <div className="flex items-center justify-between mb-3 border-b border-slate-800/80 pb-2">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-purple-400" />
                <h3 className="font-bold text-white text-sm">
                  Axial Temperature Trajectories ({inputs.flowArrangement === 'counter_current' ? 'Counter-Current' : 'Parallel Flow'})
                </h3>
              </div>
              <span className="text-xs text-slate-400 font-mono">x/L: 0.0 &rarr; 1.0</span>
            </div>

            <div className="h-56 w-full">
              {results.isValid && profileData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={profileData} margin={{ top: 10, right: 20, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis
                      dataKey="x"
                      stroke="#64748b"
                      label={{ value: 'Normalized Position (x/L)', position: 'insideBottomRight', offset: -5, fontSize: 11, fill: '#94a3b8' }}
                      tick={{ fontSize: 11, fill: '#94a3b8' }}
                    />
                    <YAxis
                      stroke="#64748b"
                      label={{ value: 'Temperature [K]', angle: -90, position: 'insideLeft', fontSize: 11, fill: '#94a3b8' }}
                      tick={{ fontSize: 11, fill: '#94a3b8' }}
                    />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', color: '#f8fafc' }}
                      formatter={(val: any, name: any) => [
                        `${val} K (${(Number(val) - 273.15).toFixed(1)} °C)`,
                        name === 'hotTemp' ? 'Hot Stream' : 'Cold Stream',
                      ]}
                      labelFormatter={(label) => `x/L: ${label}`}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '6px' }} />
                    <Line
                      type="monotone"
                      dataKey="hotTemp"
                      name="Hot Stream T_h(x)"
                      stroke="#ef4444"
                      strokeWidth={2.5}
                      dot={false}
                    />
                    <Line
                      type="monotone"
                      dataKey="coldTemp"
                      name="Cold Stream T_c(x)"
                      stroke="#06b6d4"
                      strokeWidth={2.5}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-xs text-slate-500">
                  Verify stream temperatures to render axial temperature profiles.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Engineering Calculation Breakdown */}
      <div className="bg-[#0e1628]/90 rounded-2xl p-5 sm:p-6 border border-slate-800/90 shadow-xl space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-800/80 pb-3">
          <Info className="w-4 h-4 text-purple-400" />
          <h2 className="font-bold text-white text-base">Engineering Calculation Breakdown</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
          <div className="p-4 bg-[#090d16]/90 rounded-xl border border-slate-800/80">
            <div className="font-sans font-bold text-slate-300 text-xs mb-2">1. Governing Equations</div>
            <div className="text-slate-200 font-bold space-y-1.5">
              <div>Q = U &bull; A &bull; LMTD</div>
              <div>LMTD = (ΔT1 - ΔT2) / ln(ΔT1 / ΔT2)</div>
              <div>ε = Q_actual / Q_max,  NTU = UA / C_min</div>
            </div>
          </div>

          <div className="p-4 bg-[#090d16]/90 rounded-xl border border-slate-800/80">
            <div className="font-sans font-bold text-slate-300 text-xs mb-2">2. Terminal &Delta;T &amp; LMTD</div>
            <div className="text-slate-300 space-y-1.5">
              <div>ΔT1 = {results.deltaT1.toFixed(2)} K,  ΔT2 = {results.deltaT2.toFixed(2)} K</div>
              <div>LMTD = ({results.deltaT1.toFixed(1)} - {results.deltaT2.toFixed(1)}) / ln({results.deltaT1.toFixed(1)}/{results.deltaT2.toFixed(1)}) = {formatNum(results.lmtd, 2)} K</div>
              <div>Q_sizing = {inputs.u} &bull; {inputs.area} &bull; {formatNum(results.lmtd, 2)}</div>
            </div>
          </div>

          <div className="p-4 bg-purple-950/20 rounded-xl border border-purple-500/30">
            <div className="font-sans font-bold text-purple-400 text-xs mb-2">3. Final Computed Values</div>
            <div className="text-purple-300 font-bold space-y-1.5">
              <div>LMTD = {formatNum(results.lmtd, 2)} K</div>
              <div>Q_sizing = {formatEng(results.qSizing, 2)}W ({formatNum(results.qSizing, 1)} W)</div>
              <div>ε = {(results.effectiveness * 100).toFixed(2)}%,  NTU = {formatNum(results.ntu, 3)}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Results Table */}
      <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800/80 pb-3">
          <h3 className="font-bold text-white text-sm">Principal Engineering Results Table</h3>
          <span className="text-xs font-mono text-slate-400">SI Engineering Quantities</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#090d16] text-slate-300 font-bold border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Parameter Description</th>
                <th className="py-2.5 px-3">Symbol</th>
                <th className="py-2.5 px-3 text-right">Calculated Value</th>
                <th className="py-2.5 px-3">SI Unit</th>
                <th className="py-2.5 px-3">Engineering Definition</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 font-mono">
              {tableRows.map((row) => (
                <tr key={row.parameter} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-3 font-sans font-semibold text-slate-200">{row.parameter}</td>
                  <td className="py-2.5 px-3 text-purple-400 font-bold">{row.symbol}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-white">{row.value}</td>
                  <td className="py-2.5 px-3 text-slate-400 font-sans">{row.unit}</td>
                  <td className="py-2.5 px-3 text-slate-400 font-sans">{row.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Assumptions & Interpretation */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl space-y-3">
          <div className="flex items-center gap-2 border-b border-slate-800/80 pb-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <h3 className="font-bold text-white text-sm">Governing Assumptions</h3>
          </div>
          <ul className="text-xs text-slate-300 space-y-2">
            {assumptions.map((item, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-purple-400 font-bold">&bull;</span>
                <span className="leading-relaxed">{item}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl space-y-3">
          <div className="flex items-center gap-2 border-b border-slate-800/80 pb-2">
            <Info className="w-4 h-4 text-purple-400" />
            <h3 className="font-bold text-white text-sm">Engineering Interpretation</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">{interpretation}</p>
        </div>
      </div>
    </div>
  );
};
