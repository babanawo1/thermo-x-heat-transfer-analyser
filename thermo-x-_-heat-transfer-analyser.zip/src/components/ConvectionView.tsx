import React, { useState, useMemo } from 'react';
import {
  Wind,
  FileSpreadsheet,
  FileText,
  AlertTriangle,
  CheckCircle2,
  Info,
  Sliders,
  TrendingUp,
} from 'lucide-react';
import { ConvectionInputs, ResultTableRow } from '../types';
import {
  calculateConvection,
  CONVECTION_PRESETS,
  formatEng,
  formatNum,
} from '../utils/calculations';
import { generatePdfReport, downloadCsv } from '../utils/reportGenerator';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';

export const ConvectionView: React.FC = () => {
  const [inputs, setInputs] = useState<ConvectionInputs>({
    preset: 'Custom Value',
    h: 20.0,
    area: 5.0,
    tSurface: 350.0,
    tFluid: 300.0,
  });

  const results = useMemo(() => calculateConvection(inputs), [inputs]);

  const handlePresetChange = (name: string) => {
    const found = CONVECTION_PRESETS.find((p) => p.name === name);
    if (found) {
      setInputs((prev) => ({
        ...prev,
        preset: name,
        h: found.h,
      }));
    }
  };

  // Interactive Chart Data: Heat Transfer Rate Q vs Surface Temperature Ts
  const chartData = useMemo(() => {
    if (!results.isValid || inputs.area <= 0 || inputs.h <= 0) return [];
    const minT = Math.max(10, inputs.tFluid - 100);
    const maxT = inputs.tFluid + 150;
    const points = 30;
    const step = (maxT - minT) / (points - 1);
    const data = [];

    for (let i = 0; i < points; i++) {
      const ts = minT + i * step;
      const qVal = inputs.h * inputs.area * (ts - inputs.tFluid);
      data.push({
        tSurface: Number(ts.toFixed(1)),
        heatRate: Number(qVal.toFixed(1)),
      });
    }
    return data;
  }, [inputs, results]);

  const tableRows: ResultTableRow[] = useMemo(() => {
    return [
      {
        parameter: 'Temperature Difference',
        symbol: 'ΔT = Ts - T∞',
        value: formatNum(results.deltaT, 2),
        unit: 'K',
        description: 'Convective temperature difference between solid boundary and bulk fluid',
      },
      {
        parameter: 'Convective Thermal Resistance',
        symbol: 'R_conv',
        value: formatNum(results.rConv, 5),
        unit: 'K/W',
        description: 'Thermal boundary layer resistance (1 / hA)',
      },
      {
        parameter: 'Heat-Transfer Rate',
        symbol: 'Q',
        value: `${formatNum(results.q, 2)} (${formatEng(results.q, 3)}W)`,
        unit: 'W',
        description: `Total convective heat dissipation (${results.mode.toUpperCase()} mode)`,
      },
      {
        parameter: 'Heat Flux',
        symbol: "q''",
        value: `${formatNum(results.qFlux, 2)} (${formatEng(results.qFlux, 3)}W/m²)`,
        unit: 'W/m²',
        description: 'Convective heat flux density (h * ΔT)',
      },
      {
        parameter: 'Convective Heat Direction',
        symbol: 'Mode',
        value: results.mode === 'cooling' ? 'Surface Cooling (Heat Lost to Fluid)' : results.mode === 'heating' ? 'Surface Heating (Heat Gained from Fluid)' : 'Thermal Equilibrium (Q = 0)',
        unit: '-',
        description: 'Thermodynamic direction of net convective transport',
      },
    ];
  }, [results]);

  const assumptions = [
    'Steady-state convective conditions with time-invariant boundary temperatures.',
    'Uniform surface temperature (isothermal boundary condition across area A).',
    "Uniform convective heat transfer coefficient (h) across the entire surface area.",
    "Newton's Law of Cooling is valid across the specified boundary layer regime.",
    'Fluid bulk temperature (T_fluid) remains constant (well-mixed or infinite reservoir).',
  ];

  const interpretation = `Under the specified operating conditions, Newton's law of cooling indicates a net convective heat-transfer rate of ${formatNum(
    results.q,
    2
  )} W (${formatEng(results.q, 2)}W) with a boundary convective thermal resistance of ${formatNum(
    results.rConv,
    5
  )} K/W. The heat flux is ${formatNum(
    results.qFlux,
    2
  )} W/m². Because T_surface (${inputs.tSurface} K) is ${
    inputs.tSurface > inputs.tFluid ? 'greater than' : 'less than'
  } T_fluid (${inputs.tFluid} K), the process operates in ${results.mode} mode. Increasing the heat transfer coefficient h (e.g. through forced flow or enhanced turbulence) directly decreases convective resistance R_conv and enhances heat transfer.`;

  const handleExportCsv = () => {
    const exportData = [
      { Category: 'Metadata', Parameter: 'Analysis Type', Value: 'Convection Analysis (Newton Cooling)', Unit: '-' },
      { Category: 'Metadata', Parameter: 'Timestamp', Value: new Date().toISOString(), Unit: '-' },
      { Category: 'Input', Parameter: 'Flow / Fluid Regime', Value: inputs.preset, Unit: '-' },
      { Category: 'Input', Parameter: 'Heat Transfer Coefficient (h)', Value: inputs.h, Unit: 'W/m²·K' },
      { Category: 'Input', Parameter: 'Surface Area (A)', Value: inputs.area, Unit: 'm²' },
      { Category: 'Input', Parameter: 'Surface Temperature (T_surface)', Value: inputs.tSurface, Unit: 'K' },
      { Category: 'Input', Parameter: 'Bulk Fluid Temperature (T_fluid)', Value: inputs.tFluid, Unit: 'K' },
      { Category: 'Result', Parameter: 'Temperature Difference (ΔT)', Value: results.deltaT, Unit: 'K' },
      { Category: 'Result', Parameter: 'Convective Resistance (R_conv)', Value: results.rConv, Unit: 'K/W' },
      { Category: 'Result', Parameter: 'Heat-Transfer Rate (Q)', Value: results.q, Unit: 'W' },
      { Category: 'Result', Parameter: 'Heat Flux (q flux)', Value: results.qFlux, Unit: 'W/m²' },
      { Category: 'Result', Parameter: 'Thermal Mode', Value: results.mode, Unit: '-' },
    ];
    downloadCsv(`THERMO_X_Convection_Results_${Date.now()}.csv`, exportData);
  };

  const handleExportPdf = () => {
    generatePdfReport({
      analysisTitle: "Convective Heat Transfer Analysis (Newton's Law of Cooling)",
      analysisType: 'Convection',
      governingEquation: "Q = h * A * (T_surface - T_fluid) = ΔT / R_conv,  q'' = h * (T_surface - T_fluid)",
      inputs: [
        { name: 'Heat Transfer Coefficient', symbol: 'h', value: String(inputs.h), unit: 'W/m²·K' },
        { name: 'Surface Area', symbol: 'A', value: String(inputs.area), unit: 'm²' },
        { name: 'Surface Temperature', symbol: 'T_surface', value: String(inputs.tSurface), unit: 'K' },
        { name: 'Fluid Temperature', symbol: 'T_fluid', value: String(inputs.tFluid), unit: 'K' },
      ],
      results: tableRows,
      assumptions,
      interpretation,
      validationNotes: [
        "Verified against Newton's Law of Cooling.",
        'Convective thermal resistance verified as R_conv = 1 / (h * A).',
        'Consistency verified: Q = ΔT / R_conv.',
      ],
    });
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs uppercase tracking-wider mb-1">
            <Wind className="w-4 h-4 text-cyan-400" />
            <span className="font-mono text-[11px]">THERMAL CONVECTION ANALYSIS</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">Newton&apos;s Law of Cooling</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Convective thermal boundary layer analysis for free and forced fluid regimes.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            id="convection-export-csv"
            onClick={handleExportCsv}
            className="px-3.5 py-1.5 bg-slate-800/90 hover:bg-slate-700/90 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700/80 flex items-center gap-1.5 transition-colors"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>
          <button
            id="convection-export-pdf"
            onClick={handleExportPdf}
            className="px-3.5 py-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-cyan-600/20 border border-cyan-400/30 flex items-center gap-1.5 transition-all"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Export PDF Report</span>
          </button>
        </div>
      </div>

      {/* Warnings */}
      {results.warnings.length > 0 && (
        <div className="space-y-2">
          {results.warnings.map((w, idx) => (
            <div
              key={idx}
              className={`p-3.5 rounded-xl border text-xs flex items-start gap-2.5 ${
                results.isValid
                  ? 'bg-amber-950/30 border-amber-500/40 text-amber-300'
                  : 'bg-red-950/30 border-red-500/40 text-red-300'
              }`}
            >
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{w}</span>
            </div>
          ))}
        </div>
      )}

      {/* Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* INPUTS COLUMN */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-cyan-400" />
                <h2 className="font-bold text-white text-sm">Operating Parameters</h2>
              </div>
              <span className="text-[10px] bg-slate-800/90 text-slate-300 px-2 py-0.5 rounded font-mono border border-slate-700/60">SI Units</span>
            </div>

            {/* Convection Preset */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Flow &amp; Fluid Regime Preset</label>
              <select
                id="convection-preset-select"
                value={inputs.preset}
                onChange={(e) => handlePresetChange(e.target.value)}
                className="w-full bg-[#090d16] border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-medium text-slate-200 focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500 focus:outline-none"
              >
                {CONVECTION_PRESETS.map((p) => (
                  <option key={p.name} value={p.name} className="bg-slate-900 text-slate-200">
                    {p.name} ({p.h} W/m²·K)
                  </option>
                ))}
              </select>
            </div>

            {/* Heat Transfer Coefficient h */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                <span>Convective Coefficient (h)</span>
                <span className="text-slate-400 font-mono text-[11px]">W/m²·K</span>
              </div>
              <input
                id="convection-input-h"
                type="number"
                step="1"
                min="0.1"
                value={inputs.h}
                onChange={(e) =>
                  setInputs((prev) => ({
                    ...prev,
                    preset: 'Custom Value',
                    h: parseFloat(e.target.value) || 0,
                  }))
                }
                className="w-full bg-[#090d16] border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-mono text-white focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500 focus:outline-none"
              />
            </div>

            {/* Surface Area A */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                <span>Wetted Surface Area (A)</span>
                <span className="text-slate-400 font-mono text-[11px]">m²</span>
              </div>
              <input
                id="convection-input-area"
                type="number"
                step="0.1"
                min="0.001"
                value={inputs.area}
                onChange={(e) => setInputs((prev) => ({ ...prev, area: parseFloat(e.target.value) || 0 }))}
                className="w-full bg-[#090d16] border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-mono text-white focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500 focus:outline-none"
              />
            </div>

            {/* Temperatures: T_surface and T_fluid */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                  <span>Surface Temp (Ts)</span>
                  <span className="text-slate-400 font-mono text-[11px]">K</span>
                </div>
                <input
                  id="convection-input-ts"
                  type="number"
                  step="1"
                  min="1"
                  value={inputs.tSurface}
                  onChange={(e) => setInputs((prev) => ({ ...prev, tSurface: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-[#090d16] border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-mono text-white focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500 focus:outline-none"
                />
                <span className="text-[10px] font-mono text-slate-400 mt-1 block">
                  {(inputs.tSurface - 273.15).toFixed(1)} °C
                </span>
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                  <span>Fluid Temp (T∞)</span>
                  <span className="text-slate-400 font-mono text-[11px]">K</span>
                </div>
                <input
                  id="convection-input-tfluid"
                  type="number"
                  step="1"
                  min="1"
                  value={inputs.tFluid}
                  onChange={(e) => setInputs((prev) => ({ ...prev, tFluid: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-[#090d16] border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-mono text-white focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500 focus:outline-none"
                />
                <span className="text-[10px] font-mono text-slate-400 mt-1 block">
                  {(inputs.tFluid - 273.15).toFixed(1)} °C
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* RESULTS & CHARTS COLUMN */}
        <div className="lg:col-span-7 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[#0e1628]/90 rounded-2xl p-4 border border-slate-800/90 shadow-xl">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">Heat Transfer Rate (Q)</div>
              <div className="text-2xl font-extrabold text-cyan-400 mt-1 font-mono">
                {results.isValid ? formatEng(results.q, 3) + 'W' : '—'}
              </div>
              <div className="text-xs text-slate-400 mt-0.5 font-mono">
                {results.isValid ? `${formatNum(results.q, 2)} W` : 'Invalid Inputs'}
              </div>
            </div>

            <div className="bg-[#0e1628]/90 rounded-2xl p-4 border border-slate-800/90 shadow-xl">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">Convective Heat Flux (q&apos;&apos;)</div>
              <div className="text-2xl font-extrabold text-white mt-1 font-mono">
                {results.isValid ? formatEng(results.qFlux, 3) + 'W/m²' : '—'}
              </div>
              <div className="text-xs text-slate-400 mt-0.5 font-mono">
                {results.isValid ? `${formatNum(results.qFlux, 2)} W/m²` : 'Invalid Inputs'}
              </div>
            </div>

            <div className="bg-[#0e1628]/90 rounded-2xl p-4 border border-slate-800/90 shadow-xl">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">Convective Resistance (R_conv)</div>
              <div className="text-2xl font-extrabold text-white mt-1 font-mono">
                {results.isValid ? formatNum(results.rConv, 5) : '—'}
              </div>
              <div className="text-xs text-slate-400 mt-0.5 font-mono">K/W [1 / (h &bull; A)]</div>
            </div>

            <div className="bg-[#0e1628]/90 rounded-2xl p-4 border border-slate-800/90 shadow-xl">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">Temperature Potential (ΔT)</div>
              <div className="text-2xl font-extrabold text-amber-400 mt-1 font-mono">
                {results.isValid ? formatNum(results.deltaT, 2) : '—'}
              </div>
              <div className="text-xs text-slate-400 mt-0.5 font-mono">K (Ts - T∞)</div>
            </div>
          </div>

          {/* Interactive Chart: Q vs T_surface */}
          <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl">
            <div className="flex items-center justify-between mb-3 border-b border-slate-800/80 pb-2">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-cyan-400" />
                <h3 className="font-bold text-white text-sm">Heat Transfer Rate Q vs Surface Temperature Ts</h3>
              </div>
              <span className="text-xs text-slate-400 font-mono">h = {inputs.h} W/m²·K</span>
            </div>

            <div className="h-56 w-full">
              {results.isValid && chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis
                      dataKey="tSurface"
                      stroke="#64748b"
                      label={{ value: 'Surface Temperature Ts [K]', position: 'insideBottomRight', offset: -5, fontSize: 11, fill: '#94a3b8' }}
                      tick={{ fontSize: 11, fill: '#94a3b8' }}
                    />
                    <YAxis
                      stroke="#64748b"
                      label={{ value: 'Heat Rate Q [W]', angle: -90, position: 'insideLeft', fontSize: 11, fill: '#94a3b8' }}
                      tick={{ fontSize: 11, fill: '#94a3b8' }}
                    />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', color: '#f8fafc' }}
                      formatter={(val: any) => [`${val} W (${formatEng(Number(val), 2)}W)`, 'Heat Rate Q']}
                      labelFormatter={(label) => `Ts: ${label} K (${(Number(label) - 273.15).toFixed(1)} °C)`}
                    />
                    <Line
                      type="monotone"
                      dataKey="heatRate"
                      name="Heat Rate Q"
                      stroke="#06b6d4"
                      strokeWidth={2.5}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-xs text-slate-500">
                  Enter valid parameters to render convective characteristic curve.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Engineering Calculation Display */}
      <div className="bg-[#0e1628]/90 rounded-2xl p-5 sm:p-6 border border-slate-800/90 shadow-xl space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-800/80 pb-3">
          <Info className="w-4 h-4 text-cyan-400" />
          <h2 className="font-bold text-white text-base">Engineering Calculation Breakdown</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
          <div className="p-4 bg-[#090d16]/90 rounded-xl border border-slate-800/80">
            <div className="font-sans font-bold text-slate-300 text-xs mb-2">1. Governing Equations</div>
            <div className="text-slate-200 font-bold space-y-1.5">
              <div>R_conv = 1 / (h &bull; A)</div>
              <div>Q = h &bull; A &bull; (Ts - T∞)</div>
              <div>q&apos;&apos; = h &bull; (Ts - T∞) = ΔT / (R_conv &bull; A)</div>
            </div>
          </div>

          <div className="p-4 bg-[#090d16]/90 rounded-xl border border-slate-800/80">
            <div className="font-sans font-bold text-slate-300 text-xs mb-2">2. Numerical Substitution</div>
            <div className="text-slate-300 space-y-1.5">
              <div>R_conv = 1 / ({inputs.h} &bull; {inputs.area}) = {formatNum(results.rConv, 5)} K/W</div>
              <div>ΔT = {inputs.tSurface} - {inputs.tFluid} = {formatNum(results.deltaT, 2)} K</div>
              <div>Q = {formatNum(results.deltaT, 2)} / {formatNum(results.rConv, 5)}</div>
            </div>
          </div>

          <div className="p-4 bg-cyan-950/20 rounded-xl border border-cyan-500/30">
            <div className="font-sans font-bold text-cyan-400 text-xs mb-2">3. Final Computed Values</div>
            <div className="text-cyan-300 font-bold space-y-1.5">
              <div>Q = {formatNum(results.q, 3)} W</div>
              <div>q&apos;&apos; = {formatNum(results.qFlux, 3)} W/m²</div>
              <div>R_conv = {formatNum(results.rConv, 5)} K/W</div>
            </div>
          </div>
        </div>
      </div>

      {/* Results Table */}
      <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800/80 pb-3">
          <h3 className="font-bold text-white text-sm">Principal Engineering Results Table</h3>
          <span className="text-xs font-mono text-slate-400">SI Engineering Quantities</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#090d16] text-slate-300 font-bold border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Parameter Description</th>
                <th className="py-2.5 px-3">Symbol</th>
                <th className="py-2.5 px-3 text-right">Calculated Value</th>
                <th className="py-2.5 px-3">SI Unit</th>
                <th className="py-2.5 px-3">Engineering Definition</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 font-mono">
              {tableRows.map((row) => (
                <tr key={row.parameter} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-3 font-sans font-semibold text-slate-200">{row.parameter}</td>
                  <td className="py-2.5 px-3 text-cyan-400 font-bold">{row.symbol}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-white">{row.value}</td>
                  <td className="py-2.5 px-3 text-slate-400 font-sans">{row.unit}</td>
                  <td className="py-2.5 px-3 text-slate-400 font-sans">{row.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Assumptions & Interpretation */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl space-y-3">
          <div className="flex items-center gap-2 border-b border-slate-800/80 pb-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <h3 className="font-bold text-white text-sm">Governing Assumptions</h3>
          </div>
          <ul className="text-xs text-slate-300 space-y-2">
            {assumptions.map((item, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-cyan-400 font-bold">&bull;</span>
                <span className="leading-relaxed">{item}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl space-y-3">
          <div className="flex items-center gap-2 border-b border-slate-800/80 pb-2">
            <Info className="w-4 h-4 text-cyan-400" />
            <h3 className="font-bold text-white text-sm">Engineering Interpretation</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">{interpretation}</p>
        </div>
      </div>
    </div>
  );
};
