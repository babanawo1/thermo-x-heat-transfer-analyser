import React, { useState, useMemo } from 'react';
import {
  SunMedium,
  FileSpreadsheet,
  FileText,
  AlertTriangle,
  CheckCircle2,
  Info,
  Sliders,
  TrendingUp,
} from 'lucide-react';
import { RadiationInputs, ResultTableRow } from '../types';
import {
  calculateRadiation,
  EMISSIVITY_PRESETS,
  STEFAN_BOLTZMANN_CONSTANT,
  formatEng,
  formatNum,
} from '../utils/calculations';
import { generatePdfReport, downloadCsv } from '../utils/reportGenerator';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';

export const RadiationView: React.FC = () => {
  const [inputs, setInputs] = useState<RadiationInputs>({
    preset: 'Custom Surface',
    emissivity: 0.8,
    area: 2.0,
    tSurface: 500.0,
    tSurr: 300.0,
  });

  const results = useMemo(() => calculateRadiation(inputs), [inputs]);

  const handlePresetChange = (name: string) => {
    const found = EMISSIVITY_PRESETS.find((e) => e.name === name);
    if (found) {
      setInputs((prev) => ({
        ...prev,
        preset: name,
        emissivity: found.emissivity,
      }));
    }
  };

  // Interactive Chart Data: Q_rad vs T_surface (showing T^4 curvature)
  const chartData = useMemo(() => {
    if (!results.isValid || inputs.area <= 0 || inputs.emissivity <= 0) return [];
    const minT = Math.max(50, inputs.tSurr - 150);
    const maxT = Math.max(inputs.tSurface + 200, 800);
    const points = 35;
    const step = (maxT - minT) / (points - 1);
    const data = [];

    for (let i = 0; i < points; i++) {
      const ts = minT + i * step;
      const qVal =
        inputs.emissivity *
        STEFAN_BOLTZMANN_CONSTANT *
        inputs.area *
        (Math.pow(ts, 4) - Math.pow(inputs.tSurr, 4));
      data.push({
        tSurface: Number(ts.toFixed(1)),
        qRad: Number(qVal.toFixed(1)),
      });
    }
    return data;
  }, [inputs, results]);

  const tableRows: ResultTableRow[] = useMemo(() => {
    return [
      {
        parameter: 'Net Radiative Heat-Transfer Rate',
        symbol: 'Q_rad',
        value: `${formatNum(results.q, 2)} (${formatEng(results.q, 3)}W)`,
        unit: 'W',
        description: 'Net thermal radiation exchange with surroundings',
      },
      {
        parameter: 'Radiative Heat Flux',
        symbol: "q''_rad",
        value: `${formatNum(results.qFlux, 2)} (${formatEng(results.qFlux, 3)}W/m²)`,
        unit: 'W/m²',
        description: 'Radiative heat transfer per unit surface area',
      },
      {
        parameter: 'Linearized Radiation Coefficient',
        symbol: 'h_r',
        value: formatNum(results.hr, 3),
        unit: 'W/m²·K',
        description: 'Effective radiative heat transfer coefficient: ε·σ·(Ts+Tsurr)·(Ts²+Tsurr²)',
      },
      {
        parameter: 'Radiative Thermal Resistance',
        symbol: 'R_rad',
        value: formatNum(results.rRad, 5),
        unit: 'K/W',
        description: 'Linearized equivalent radiative resistance: 1 / (h_r · A)',
      },
      {
        parameter: 'Surface Fourth-Power Potential',
        symbol: 'Ts⁴',
        value: results.ts4.toExponential(4),
        unit: 'K⁴',
        description: 'Absolute emissive potential of surface (T_surface⁴)',
      },
      {
        parameter: 'Surroundings Fourth-Power Potential',
        symbol: 'T_surr⁴',
        value: results.tsurr4.toExponential(4),
        unit: 'K⁴',
        description: 'Absolute incident radiation potential of surroundings (T_surr⁴)',
      },
    ];
  }, [results]);

  const assumptions = [
    'Surface is diffuse and gray (absorptivity equals emissivity: α = ε).',
    'Enclosed surroundings behave as a blackbody at effective uniform temperature T_surroundings.',
    'Surface area (A) is small relative to the surrounding enclosure area (view factor F_12 = 1.0).',
    'Medium between surface and surroundings is non-participating (vacuum or transparent dry air).',
    'Stefan-Boltzmann constant σ = 5.670374419 × 10⁻⁸ W/m²·K⁴.',
  ];

  const interpretation = `Under the specified absolute temperatures, the net radiative heat-transfer rate is ${formatNum(
    results.q,
    2
  )} W (${formatEng(results.q, 2)}W) with a radiative heat flux of ${formatNum(
    results.qFlux,
    2
  )} W/m². Because thermal radiation is governed by the fourth power of absolute temperature (T⁴), higher surface temperatures cause heat transfer to grow exponentially rather than linearly. The linearized radiation coefficient is h_r = ${formatNum(
    results.hr,
    3
  )} W/m²·K, which can be coupled in parallel with convection when analysing combined surface dissipation.`;

  const handleExportCsv = () => {
    const exportData = [
      { Category: 'Metadata', Parameter: 'Analysis Type', Value: 'Thermal Radiation (Stefan-Boltzmann)', Unit: '-' },
      { Category: 'Metadata', Parameter: 'Timestamp', Value: new Date().toISOString(), Unit: '-' },
      { Category: 'Input', Parameter: 'Surface Preset', Value: inputs.preset, Unit: '-' },
      { Category: 'Input', Parameter: 'Surface Emissivity (ε)', Value: inputs.emissivity, Unit: '-' },
      { Category: 'Input', Parameter: 'Surface Area (A)', Value: inputs.area, Unit: 'm²' },
      { Category: 'Input', Parameter: 'Surface Temperature (T_surface)', Value: inputs.tSurface, Unit: 'K' },
      { Category: 'Input', Parameter: 'Surroundings Temperature (T_surr)', Value: inputs.tSurr, Unit: 'K' },
      { Category: 'Constant', Parameter: 'Stefan-Boltzmann Constant (σ)', Value: STEFAN_BOLTZMANN_CONSTANT, Unit: 'W/m²·K⁴' },
      { Category: 'Result', Parameter: 'Net Radiative Rate (Q_rad)', Value: results.q, Unit: 'W' },
      { Category: 'Result', Parameter: 'Radiative Heat Flux (q flux)', Value: results.qFlux, Unit: 'W/m²' },
      { Category: 'Result', Parameter: 'Linearized Rad Coeff (h_r)', Value: results.hr, Unit: 'W/m²·K' },
      { Category: 'Result', Parameter: 'Radiative Resistance (R_rad)', Value: results.rRad, Unit: 'K/W' },
    ];
    downloadCsv(`THERMO_X_Radiation_Results_${Date.now()}.csv`, exportData);
  };

  const handleExportPdf = () => {
    generatePdfReport({
      analysisTitle: 'Thermal Radiation Analysis (Stefan-Boltzmann Law)',
      analysisType: 'Radiation',
      governingEquation: 'Q_rad = ε * σ * A * (T_surface⁴ - T_surroundings⁴),  σ = 5.670374419 × 10⁻⁸ W/m²·K⁴',
      inputs: [
        { name: 'Surface Emissivity', symbol: 'ε', value: String(inputs.emissivity), unit: '-' },
        { name: 'Surface Area', symbol: 'A', value: String(inputs.area), unit: 'm²' },
        { name: 'Surface Temperature', symbol: 'T_surface', value: String(inputs.tSurface), unit: 'K' },
        { name: 'Surroundings Temperature', symbol: 'T_surroundings', value: String(inputs.tSurr), unit: 'K' },
      ],
      results: tableRows,
      assumptions,
      interpretation,
      validationNotes: [
        'Verified against Stefan-Boltzmann T⁴ law.',
        'Emissivity validated within 0 ≤ ε ≤ 1.',
        'Linearized radiative coefficient verified: h_r = ε·σ·(Ts+Tsurr)·(Ts²+Tsurr²).',
      ],
    });
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider mb-1">
            <SunMedium className="w-4 h-4 text-amber-400" />
            <span className="font-mono text-[11px]">THERMAL RADIATION ANALYSIS</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">Stefan-Boltzmann T⁴ Law</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Diffuse-gray net radiation exchange with blackbody surrounding enclosure.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            id="radiation-export-csv"
            onClick={handleExportCsv}
            className="px-3.5 py-1.5 bg-slate-800/90 hover:bg-slate-700/90 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700/80 flex items-center gap-1.5 transition-colors"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>
          <button
            id="radiation-export-pdf"
            onClick={handleExportPdf}
            className="px-3.5 py-1.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-amber-600/20 border border-amber-400/30 flex items-center gap-1.5 transition-all"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Export PDF Report</span>
          </button>
        </div>
      </div>

      {/* Warnings */}
      {results.warnings.length > 0 && (
        <div className="space-y-2">
          {results.warnings.map((w, idx) => (
            <div
              key={idx}
              className={`p-3.5 rounded-xl border text-xs flex items-start gap-2.5 ${
                results.isValid
                  ? 'bg-amber-950/30 border-amber-500/40 text-amber-300'
                  : 'bg-red-950/30 border-red-500/40 text-red-300'
              }`}
            >
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{w}</span>
            </div>
          ))}
        </div>
      )}

      {/* Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* INPUTS COLUMN */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-amber-400" />
                <h2 className="font-bold text-white text-sm">Operating Parameters</h2>
              </div>
              <span className="text-[10px] bg-slate-800/90 text-slate-300 px-2 py-0.5 rounded font-mono border border-slate-700/60">SI Units</span>
            </div>

            {/* Surface Preset */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Surface Finish Preset</label>
              <select
                id="radiation-preset-select"
                value={inputs.preset}
                onChange={(e) => handlePresetChange(e.target.value)}
                className="w-full bg-[#090d16] border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-medium text-slate-200 focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 focus:outline-none"
              >
                {EMISSIVITY_PRESETS.map((p) => (
                  <option key={p.name} value={p.name} className="bg-slate-900 text-slate-200">
                    {p.name} (ε = {p.emissivity})
                  </option>
                ))}
              </select>
            </div>

            {/* Emissivity */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                <span>Surface Emissivity (ε)</span>
                <span className="text-slate-400 font-mono text-[11px]">0.0 ≤ ε ≤ 1.0</span>
              </div>
              <input
                id="radiation-input-emissivity"
                type="number"
                step="0.01"
                min="0.0"
                max="1.0"
                value={inputs.emissivity}
                onChange={(e) =>
                  setInputs((prev) => ({
                    ...prev,
                    preset: 'Custom Surface',
                    emissivity: parseFloat(e.target.value) || 0,
                  }))
                }
                className="w-full bg-[#090d16] border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-mono text-white focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 focus:outline-none"
              />
            </div>

            {/* Surface Area A */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                <span>Radiating Surface Area (A)</span>
                <span className="text-slate-400 font-mono text-[11px]">m²</span>
              </div>
              <input
                id="radiation-input-area"
                type="number"
                step="0.1"
                min="0.001"
                value={inputs.area}
                onChange={(e) => setInputs((prev) => ({ ...prev, area: parseFloat(e.target.value) || 0 }))}
                className="w-full bg-[#090d16] border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-mono text-white focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 focus:outline-none"
              />
            </div>

            {/* Temperatures: T_surface and T_surroundings */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                  <span>Surface Temp (Ts)</span>
                  <span className="text-slate-400 font-mono text-[11px]">K</span>
                </div>
                <input
                  id="radiation-input-ts"
                  type="number"
                  step="1"
                  min="1"
                  value={inputs.tSurface}
                  onChange={(e) => setInputs((prev) => ({ ...prev, tSurface: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-[#090d16] border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-mono text-white focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 focus:outline-none"
                />
                <span className="text-[10px] font-mono text-slate-400 mt-1 block">
                  {(inputs.tSurface - 273.15).toFixed(1)} °C
                </span>
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                  <span>Surr. Temp (T_surr)</span>
                  <span className="text-slate-400 font-mono text-[11px]">K</span>
                </div>
                <input
                  id="radiation-input-tsurr"
                  type="number"
                  step="1"
                  min="1"
                  value={inputs.tSurr}
                  onChange={(e) => setInputs((prev) => ({ ...prev, tSurr: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-[#090d16] border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-mono text-white focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 focus:outline-none"
                />
                <span className="text-[10px] font-mono text-slate-400 mt-1 block">
                  {(inputs.tSurr - 273.15).toFixed(1)} °C
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* RESULTS & CHARTS COLUMN */}
        <div className="lg:col-span-7 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[#0e1628]/90 rounded-2xl p-4 border border-slate-800/90 shadow-xl">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">Net Radiative Rate (Q_rad)</div>
              <div className="text-2xl font-extrabold text-amber-400 mt-1 font-mono">
                {results.isValid ? formatEng(results.q, 3) + 'W' : '—'}
              </div>
              <div className="text-xs text-slate-400 mt-0.5 font-mono">
                {results.isValid ? `${formatNum(results.q, 2)} W` : 'Invalid Inputs'}
              </div>
            </div>

            <div className="bg-[#0e1628]/90 rounded-2xl p-4 border border-slate-800/90 shadow-xl">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">Radiative Heat Flux (q&apos;&apos;_rad)</div>
              <div className="text-2xl font-extrabold text-white mt-1 font-mono">
                {results.isValid ? formatEng(results.qFlux, 3) + 'W/m²' : '—'}
              </div>
              <div className="text-xs text-slate-400 mt-0.5 font-mono">
                {results.isValid ? `${formatNum(results.qFlux, 2)} W/m²` : 'Invalid Inputs'}
              </div>
            </div>

            <div className="bg-[#0e1628]/90 rounded-2xl p-4 border border-slate-800/90 shadow-xl">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">Linearized Rad Coeff (h_r)</div>
              <div className="text-2xl font-extrabold text-white mt-1 font-mono">
                {results.isValid ? formatNum(results.hr, 3) : '—'}
              </div>
              <div className="text-xs text-slate-400 mt-0.5 font-mono">W/m²·K</div>
            </div>

            <div className="bg-[#0e1628]/90 rounded-2xl p-4 border border-slate-800/90 shadow-xl">
              <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">Radiative Resistance (R_rad)</div>
              <div className="text-2xl font-extrabold text-white mt-1 font-mono">
                {results.isValid ? formatNum(results.rRad, 5) : '—'}
              </div>
              <div className="text-xs text-slate-400 mt-0.5 font-mono">K/W [1 / (h_r &bull; A)]</div>
            </div>
          </div>

          {/* Non-linear T^4 Chart */}
          <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl">
            <div className="flex items-center justify-between mb-3 border-b border-slate-800/80 pb-2">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-amber-400" />
                <h3 className="font-bold text-white text-sm">Stefan-Boltzmann T⁴ Characteristic Curve</h3>
              </div>
              <span className="text-xs text-slate-400 font-mono">ε = {inputs.emissivity}</span>
            </div>

            <div className="h-56 w-full">
              {results.isValid && chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis
                      dataKey="tSurface"
                      stroke="#64748b"
                      label={{ value: 'Surface Temperature Ts [K]', position: 'insideBottomRight', offset: -5, fontSize: 11, fill: '#94a3b8' }}
                      tick={{ fontSize: 11, fill: '#94a3b8' }}
                    />
                    <YAxis
                      stroke="#64748b"
                      label={{ value: 'Net Radiation Q_rad [W]', angle: -90, position: 'insideLeft', fontSize: 11, fill: '#94a3b8' }}
                      tick={{ fontSize: 11, fill: '#94a3b8' }}
                    />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', color: '#f8fafc' }}
                      formatter={(val: any) => [`${val} W (${formatEng(Number(val), 2)}W)`, 'Q_rad']}
                      labelFormatter={(label) => `Ts: ${label} K (${(Number(label) - 273.15).toFixed(1)} °C)`}
                    />
                    <Line
                      type="monotone"
                      dataKey="qRad"
                      name="Q_rad (T⁴ curve)"
                      stroke="#f59e0b"
                      strokeWidth={2.5}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-xs text-slate-500">
                  Enter valid parameters to render Stefan-Boltzmann fourth-power curve.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Engineering Calculation Display */}
      <div className="bg-[#0e1628]/90 rounded-2xl p-5 sm:p-6 border border-slate-800/90 shadow-xl space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-800/80 pb-3">
          <Info className="w-4 h-4 text-amber-400" />
          <h2 className="font-bold text-white text-base">Engineering Calculation Breakdown</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
          <div className="p-4 bg-[#090d16]/90 rounded-xl border border-slate-800/80">
            <div className="font-sans font-bold text-slate-300 text-xs mb-2">1. Governing Equations</div>
            <div className="text-slate-200 font-bold space-y-1.5">
              <div>Q_rad = ε &bull; σ &bull; A &bull; (Ts⁴ - T_surr⁴)</div>
              <div>σ = 5.670374419 &times; 10⁻⁸ W/m²·K⁴</div>
              <div>h_r = ε &bull; σ &bull; (Ts + T_surr)(Ts² + T_surr²)</div>
            </div>
          </div>

          <div className="p-4 bg-[#090d16]/90 rounded-xl border border-slate-800/80">
            <div className="font-sans font-bold text-slate-300 text-xs mb-2">2. Numerical Substitution</div>
            <div className="text-slate-300 space-y-1.5">
              <div>Ts⁴ = {inputs.tSurface}⁴ = {results.ts4.toExponential(3)} K⁴</div>
              <div>T_surr⁴ = {inputs.tSurr}⁴ = {results.tsurr4.toExponential(3)} K⁴</div>
              <div>Q = {inputs.emissivity} &bull; 5.6704e-8 &bull; {inputs.area} &bull; ({results.ts4.toExponential(2)} - {results.tsurr4.toExponential(2)})</div>
            </div>
          </div>

          <div className="p-4 bg-amber-950/20 rounded-xl border border-amber-500/30">
            <div className="font-sans font-bold text-amber-400 text-xs mb-2">3. Final Computed Values</div>
            <div className="text-amber-300 font-bold space-y-1.5">
              <div>Q_rad = {formatNum(results.q, 3)} W</div>
              <div>q&apos;&apos;_rad = {formatNum(results.qFlux, 3)} W/m²</div>
              <div>h_r = {formatNum(results.hr, 3)} W/m²·K</div>
            </div>
          </div>
        </div>
      </div>

      {/* Results Table */}
      <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800/80 pb-3">
          <h3 className="font-bold text-white text-sm">Principal Engineering Results Table</h3>
          <span className="text-xs font-mono text-slate-400">SI Engineering Quantities</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#090d16] text-slate-300 font-bold border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Parameter Description</th>
                <th className="py-2.5 px-3">Symbol</th>
                <th className="py-2.5 px-3 text-right">Calculated Value</th>
                <th className="py-2.5 px-3">SI Unit</th>
                <th className="py-2.5 px-3">Engineering Definition</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 font-mono">
              {tableRows.map((row) => (
                <tr key={row.parameter} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-3 font-sans font-semibold text-slate-200">{row.parameter}</td>
                  <td className="py-2.5 px-3 text-amber-400 font-bold">{row.symbol}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-white">{row.value}</td>
                  <td className="py-2.5 px-3 text-slate-400 font-sans">{row.unit}</td>
                  <td className="py-2.5 px-3 text-slate-400 font-sans">{row.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Assumptions & Interpretation */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl space-y-3">
          <div className="flex items-center gap-2 border-b border-slate-800/80 pb-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <h3 className="font-bold text-white text-sm">Governing Assumptions</h3>
          </div>
          <ul className="text-xs text-slate-300 space-y-2">
            {assumptions.map((item, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-amber-400 font-bold">&bull;</span>
                <span className="leading-relaxed">{item}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-xl space-y-3">
          <div className="flex items-center gap-2 border-b border-slate-800/80 pb-2">
            <Info className="w-4 h-4 text-amber-400" />
            <h3 className="font-bold text-white text-sm">Engineering Interpretation</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">{interpretation}</p>
        </div>
      </div>
    </div>
  );
};
