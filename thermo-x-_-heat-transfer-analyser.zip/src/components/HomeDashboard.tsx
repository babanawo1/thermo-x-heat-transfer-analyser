import React from 'react';
import {
  Layers,
  Wind,
  SunMedium,
  GitCompare,
  Network,
  ArrowRight,
  ShieldCheck,
  Download,
  CheckCircle,
  Table,
  Cpu,
  Zap,
} from 'lucide-react';
import { AnalysisType } from '../types';
import { MATERIAL_PRESETS, CONVECTION_PRESETS, EMISSIVITY_PRESETS } from '../utils/calculations';

interface HomeDashboardProps {
  onNavigate: (view: AnalysisType) => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({ onNavigate }) => {
  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Hero / Master Title Banner with sleek glass dark gradients */}
      <div
        id="app-intro-banner"
        className="app-intro-banner relative rounded-2xl p-6 sm:p-8 bg-gradient-to-br from-[#0e1628] via-[#11192d] to-[#0a0e1a] text-white border border-slate-800/90 shadow-2xl overflow-hidden group"
      >
        {/* Subtle decorative glow overlay */}
        <div className="absolute -right-20 -top-20 w-80 h-80 bg-orange-500/10 rounded-full blur-3xl pointer-events-none group-hover:bg-orange-500/15 transition-all duration-700"></div>
        <div className="absolute -left-20 -bottom-20 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-500/10 text-orange-400 text-xs font-semibold border border-orange-500/30 mb-4 tracking-wide shadow-sm">
            <Cpu className="w-3.5 h-3.5 text-orange-400" />
            <span className="font-mono text-[11px]">THERMAL ANALYSIS SUITE &bull; SI COMPLIANT</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white mb-2 leading-tight">
            THERMO<span className="text-orange-500">-X</span>{' '}
            <span className="text-slate-500 font-light">|</span>{' '}
            <span className="text-slate-200 text-2xl sm:text-3xl font-semibold">Heat Transfer Analyser</span>
          </h1>

          <p className="text-base sm:text-lg text-slate-300 font-medium mb-3">
            Engineering-grade thermal analysis for students, engineers, and researchers.
          </p>

          <p className="text-xs sm:text-sm text-slate-400 leading-relaxed mb-6 max-w-2xl">
            THERMO-X is an interactive engineering workspace for analysing heat-transfer systems using rigorous thermal equations. Select a thermal discipline, configure operating parameters in SI units, and inspect real-time calculated metrics, sensitivity plots, step-by-step substitutions, and PDF/CSV reports.
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <button
              id="hero-quickstart-btn"
              onClick={() => onNavigate('conduction')}
              className="px-5 py-2.5 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white rounded-xl font-semibold text-xs sm:text-sm transition-all duration-150 shadow-lg shadow-orange-600/30 flex items-center gap-2 border border-orange-400/30"
            >
              <span>Launch First Analysis</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              id="hero-benchmarks-btn"
              onClick={() => onNavigate('verification')}
              className="px-4 py-2.5 bg-slate-800/90 hover:bg-slate-700/90 text-slate-200 rounded-xl font-semibold text-xs sm:text-sm border border-slate-700/80 transition-all duration-150 flex items-center gap-2 hover:text-white"
            >
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>Validation Test Suite</span>
            </button>

            <button
              id="hero-python-btn"
              onClick={() => onNavigate('python_repo')}
              className="px-4 py-2.5 bg-slate-800/90 hover:bg-slate-700/90 text-slate-200 rounded-xl font-semibold text-xs sm:text-sm border border-slate-700/80 transition-all duration-150 flex items-center gap-2 hover:text-white"
            >
              <Download className="w-4 h-4 text-cyan-400" />
              <span>Python / Streamlit Package</span>
            </button>
          </div>
        </div>
      </div>

      {/* Analysis Modules Grid (Prompt Section 25) */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-bold text-white">Analysis Modules</h2>
            <p className="text-xs text-slate-400">Interactive physics calculators for primary thermal mechanisms</p>
          </div>
          <span className="text-[11px] font-mono bg-slate-800/90 text-slate-300 px-2.5 py-1 rounded-lg border border-slate-700">
            5 CORE MODULES
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* 1. Conduction */}
          <div
            id="card-conduction"
            onClick={() => onNavigate('conduction')}
            className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-lg hover:border-orange-500/60 hover:shadow-orange-500/10 hover:shadow-xl transition-all duration-200 cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-orange-500/15 text-orange-400 border border-orange-500/30 flex items-center justify-center group-hover:bg-orange-500 group-hover:text-white transition-all">
                  <Layers className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-mono font-semibold text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700/60">
                  Q = kAΔT/L
                </span>
              </div>
              <h3 className="text-base font-bold text-white group-hover:text-orange-400 transition-colors mb-1.5">
                Conduction Analysis
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                Analyse 1D steady-state conductive heat transfer through homogeneous solid plane walls using Fourier&apos;s Law.
              </p>
            </div>
            <div className="flex items-center justify-between text-xs font-semibold text-orange-400 pt-3 border-t border-slate-800/80 group-hover:text-orange-300">
              <span>Launch Calculator</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* 2. Convection */}
          <div
            id="card-convection"
            onClick={() => onNavigate('convection')}
            className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-lg hover:border-cyan-500/60 hover:shadow-cyan-500/10 hover:shadow-xl transition-all duration-200 cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 flex items-center justify-center group-hover:bg-cyan-500 group-hover:text-white transition-all">
                  <Wind className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-mono font-semibold text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700/60">
                  Q = hA(Ts - T∞)
                </span>
              </div>
              <h3 className="text-base font-bold text-white group-hover:text-cyan-400 transition-colors mb-1.5">
                Convection Analysis
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                Evaluate convective boundary heat rates, cooling/heating directions, and convective resistances using Newton&apos;s Law.
              </p>
            </div>
            <div className="flex items-center justify-between text-xs font-semibold text-cyan-400 pt-3 border-t border-slate-800/80 group-hover:text-cyan-300">
              <span>Launch Calculator</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* 3. Radiation */}
          <div
            id="card-radiation"
            onClick={() => onNavigate('radiation')}
            className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-lg hover:border-amber-500/60 hover:shadow-amber-500/10 hover:shadow-xl transition-all duration-200 cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30 flex items-center justify-center group-hover:bg-amber-500 group-hover:text-white transition-all">
                  <SunMedium className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-mono font-semibold text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700/60">
                  Q = εσA(T⁴ - T_surr⁴)
                </span>
              </div>
              <h3 className="text-base font-bold text-white group-hover:text-amber-400 transition-colors mb-1.5">
                Radiation Analysis
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                Calculate net thermal radiative exchange and fourth-power temperature dependencies with Stefan-Boltzmann Law.
              </p>
            </div>
            <div className="flex items-center justify-between text-xs font-semibold text-amber-400 pt-3 border-t border-slate-800/80 group-hover:text-amber-300">
              <span>Launch Calculator</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* 4. Heat Exchanger */}
          <div
            id="card-heat-exchanger"
            onClick={() => onNavigate('heat_exchanger')}
            className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-lg hover:border-purple-500/60 hover:shadow-purple-500/10 hover:shadow-xl transition-all duration-200 cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-purple-500/15 text-purple-400 border border-purple-500/30 flex items-center justify-center group-hover:bg-purple-500 group-hover:text-white transition-all">
                  <GitCompare className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-mono font-semibold text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700/60">
                  LMTD &amp; ε-NTU
                </span>
              </div>
              <h3 className="text-base font-bold text-white group-hover:text-purple-400 transition-colors mb-1.5">
                Heat Exchanger Analysis
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                Analyse counter-current and parallel flow heat exchangers, verify energy balances, calculate LMTD and effectiveness ε.
              </p>
            </div>
            <div className="flex items-center justify-between text-xs font-semibold text-purple-400 pt-3 border-t border-slate-800/80 group-hover:text-purple-300">
              <span>Launch Calculator</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* 5. Thermal Resistance */}
          <div
            id="card-thermal-resistance"
            onClick={() => onNavigate('thermal_resistance')}
            className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-lg hover:border-emerald-500/60 hover:shadow-emerald-500/10 hover:shadow-xl transition-all duration-200 cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center justify-center group-hover:bg-emerald-500 group-hover:text-white transition-all">
                  <Network className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-mono font-semibold text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700/60">
                  R_tot = Σ R_i
                </span>
              </div>
              <h3 className="text-base font-bold text-white group-hover:text-emerald-400 transition-colors mb-1.5">
                Thermal Resistance Network
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                Build series composite walls with internal/external convection layers, calculate total thermal resistance and interface temperatures.
              </p>
            </div>
            <div className="flex items-center justify-between text-xs font-semibold text-emerald-400 pt-3 border-t border-slate-800/80 group-hover:text-emerald-300">
              <span>Launch Calculator</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* 6. Verification Suite */}
          <div
            id="card-verification"
            onClick={() => onNavigate('verification')}
            className="bg-[#0e1628]/90 rounded-2xl p-5 border border-slate-800/90 shadow-lg hover:border-emerald-500/60 hover:shadow-emerald-500/10 hover:shadow-xl transition-all duration-200 cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center justify-center group-hover:bg-emerald-500 group-hover:text-white transition-all">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-mono font-semibold text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700/60">
                  BENCHMARKS
                </span>
              </div>
              <h3 className="text-base font-bold text-white group-hover:text-emerald-400 transition-colors mb-1.5">
                Physical Validation Suite
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                Automated unit test runner verifying Section 34 benchmark test cases, physical edge cases, and numerical tolerances.
              </p>
            </div>
            <div className="flex items-center justify-between text-xs font-semibold text-emerald-400 pt-3 border-t border-slate-800/80 group-hover:text-emerald-300">
              <span>Run Validation Tests</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>
      </div>

      {/* Thermophysical Properties Quick Reference Table */}
      <div className="bg-[#0e1628]/90 rounded-2xl p-5 sm:p-6 border border-slate-800/90 shadow-xl">
        <div className="flex items-center justify-between mb-4 border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <Table className="w-4 h-4 text-orange-400" />
            <h2 className="text-base font-bold text-white">Thermophysical Reference Data (at ~300 K)</h2>
          </div>
          <span className="text-[11px] font-mono text-slate-400">SI Units Standard Reference</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 text-xs">
          <div className="border border-slate-800/80 rounded-xl p-3.5 bg-[#090d16]/90">
            <h4 className="font-bold text-slate-200 mb-2 border-b border-slate-800/80 pb-1 flex justify-between">
              <span>Thermal Conductivities k</span>
              <span className="text-slate-400 font-mono text-[10px]">[W/m·K]</span>
            </h4>
            <div className="space-y-1.5 font-mono text-[11px]">
              {MATERIAL_PRESETS.slice(1, 7).map((m) => (
                <div key={m.name} className="flex justify-between py-0.5 text-slate-300 border-b border-slate-800/40 last:border-0">
                  <span className="truncate pr-2 text-slate-400">{m.name}</span>
                  <span className="font-bold text-amber-400">{m.k}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="border border-slate-800/80 rounded-xl p-3.5 bg-[#090d16]/90">
            <h4 className="font-bold text-slate-200 mb-2 border-b border-slate-800/80 pb-1 flex justify-between">
              <span>Convective Coeffs. h</span>
              <span className="text-slate-400 font-mono text-[10px]">[W/m²·K]</span>
            </h4>
            <div className="space-y-1.5 font-mono text-[11px]">
              {CONVECTION_PRESETS.slice(1, 7).map((c) => (
                <div key={c.name} className="flex justify-between py-0.5 text-slate-300 border-b border-slate-800/40 last:border-0">
                  <span className="truncate pr-2 text-slate-400">{c.name.split('—')[1] || c.name}</span>
                  <span className="font-bold text-cyan-400">{c.h}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="border border-slate-800/80 rounded-xl p-3.5 bg-[#090d16]/90">
            <h4 className="font-bold text-slate-200 mb-2 border-b border-slate-800/80 pb-1 flex justify-between">
              <span>Surface Emissivity ε</span>
              <span className="text-slate-400 font-mono text-[10px]">[-]</span>
            </h4>
            <div className="space-y-1.5 font-mono text-[11px]">
              {EMISSIVITY_PRESETS.slice(1, 7).map((e) => (
                <div key={e.name} className="flex justify-between py-0.5 text-slate-300 border-b border-slate-800/40 last:border-0">
                  <span className="truncate pr-2 text-slate-400">{e.name}</span>
                  <span className="font-bold text-emerald-400">{e.emissivity}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

