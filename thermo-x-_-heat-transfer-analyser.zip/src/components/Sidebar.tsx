import React from 'react';
import {
  LayoutDashboard,
  BookOpen,
  Layers,
  Wind,
  SunMedium,
  GitCompare,
  Network,
  CheckCircle2,
  FileCode2,
  X,
  Zap,
} from 'lucide-react';
import { AnalysisType } from '../types';

interface SidebarProps {
  currentView: AnalysisType;
  onSelectView: (view: AnalysisType) => void;
  isOpen?: boolean;
  onClose?: () => void;
}

interface NavItem {
  id: AnalysisType;
  label: string;
  sublabel: string;
  icon: React.ElementType;
  badge?: string;
}

const navItems: NavItem[] = [
  {
    id: 'home',
    label: 'Dashboard',
    sublabel: 'Overview & Principles',
    icon: LayoutDashboard,
  },
  {
    id: 'how_to_use',
    label: 'How to Use',
    sublabel: '6-Step Workflow Guide',
    icon: BookOpen,
    badge: '6 STEPS',
  },
  {
    id: 'conduction',
    label: 'Conduction',
    sublabel: "Fourier's Law — 1D Solid",
    icon: Layers,
    badge: '1D',
  },
  {
    id: 'convection',
    label: 'Convection',
    sublabel: "Newton's Law of Cooling",
    icon: Wind,
    badge: 'h',
  },
  {
    id: 'radiation',
    label: 'Radiation',
    sublabel: 'Stefan-Boltzmann T⁴ Law',
    icon: SunMedium,
    badge: 'T⁴',
  },
  {
    id: 'heat_exchanger',
    label: 'Heat Exchanger',
    sublabel: 'LMTD & ε-NTU Methods',
    icon: GitCompare,
    badge: 'LMTD',
  },
  {
    id: 'thermal_resistance',
    label: 'Thermal Resistance',
    sublabel: 'Series Composite Network',
    icon: Network,
    badge: 'ΣR',
  },
  {
    id: 'verification',
    label: 'Validation Suite',
    sublabel: 'Benchmark Physical Tests',
    icon: CheckCircle2,
    badge: 'TEST',
  },
  {
    id: 'python_repo',
    label: 'Python Repo & Docs',
    sublabel: 'app.py & Cloud Deployment',
    icon: FileCode2,
  },
];

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onSelectView,
  isOpen = false,
  onClose,
}) => {
  return (
    <>
      {/* Mobile Backdrop Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      <aside
        id="thermo-sidebar"
        className={`fixed lg:static inset-y-0 left-0 z-40 w-72 lg:w-64 bg-[#0d131f]/95 lg:bg-[#0d131f]/80 backdrop-blur-md text-slate-300 p-4 shrink-0 flex flex-col justify-between border-r border-slate-800/80 transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="space-y-5 overflow-y-auto">
          {/* Mobile Header in Drawer */}
          <div className="flex items-center justify-between lg:hidden pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-white text-base">THERMO-X</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-orange-500/20 text-orange-400 font-bold border border-orange-500/30">
                PRO SI
              </span>
            </div>
            {onClose && (
              <button
                onClick={onClose}
                className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>

          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3 mb-2 flex items-center justify-between">
              <span>Navigation & Modules</span>
              <span className="text-[9px] text-orange-400 font-mono">SI STANDARD</span>
            </div>
            <nav className="space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentView === item.id;
                return (
                  <button
                    key={item.id}
                    id={`nav-btn-${item.id}`}
                    onClick={() => {
                      onSelectView(item.id);
                      if (onClose) onClose();
                    }}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all duration-150 relative group ${
                      isActive
                        ? 'bg-gradient-to-r from-orange-500/20 via-orange-500/10 to-transparent text-white font-medium border border-orange-500/40 shadow-sm shadow-orange-500/10'
                        : 'hover:bg-slate-800/60 hover:text-slate-100 text-slate-400 border border-transparent'
                    }`}
                  >
                    {/* Active vertical pill accent */}
                    {isActive && (
                      <span className="absolute left-0 top-1.5 bottom-1.5 w-1 rounded-r-full bg-orange-500 shadow-sm shadow-orange-500" />
                    )}

                    <div
                      className={`p-1.5 rounded-lg transition-colors ${
                        isActive
                          ? 'bg-orange-500 text-white shadow-sm shadow-orange-500/40'
                          : 'bg-slate-800/80 text-slate-400 group-hover:text-slate-200 group-hover:bg-slate-800'
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-1">
                        <span
                          className={`text-xs font-bold truncate ${
                            isActive ? 'text-white' : 'text-slate-300'
                          }`}
                        >
                          {item.label}
                        </span>
                        {item.badge && (
                          <span
                            className={`text-[9px] px-1.5 py-0.2 rounded font-mono ${
                              isActive
                                ? 'bg-orange-500/30 text-orange-200 border border-orange-500/40'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {item.badge}
                          </span>
                        )}
                      </div>
                      <div
                        className={`text-[10px] truncate ${
                          isActive ? 'text-orange-200/80' : 'text-slate-400'
                        }`}
                      >
                        {item.sublabel}
                      </div>
                    </div>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Quick Engineering Constants Summary Card */}
          <div className="bg-[#0b0f19]/90 rounded-xl p-3.5 border border-slate-800/90 text-xs space-y-2.5 shadow-inner">
            <div className="font-semibold text-slate-200 flex items-center justify-between border-b border-slate-800/80 pb-1.5">
              <span className="text-[11px] font-bold text-slate-300">Engineering Constants</span>
              <span className="text-[9px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded font-mono border border-slate-700/60">
                SI UNITS
              </span>
            </div>
            <div className="space-y-1.5 text-slate-400 font-mono text-[10px]">
              <div className="flex justify-between items-center py-0.5">
                <span className="text-slate-400">&sigma; (Stefan-Boltz.)</span>
                <span className="text-amber-400 font-semibold">5.6704e-8</span>
              </div>
              <div className="flex justify-between items-center py-0.5">
                <span className="text-slate-400">Absolute Zero</span>
                <span className="text-cyan-400 font-semibold">0.00 K</span>
              </div>
              <div className="flex justify-between items-center py-0.5">
                <span className="text-slate-400">T Scale Conv.</span>
                <span className="text-slate-300">K = °C + 273.15</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Info */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 text-[10px] text-slate-400 flex flex-col gap-1">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-slate-300">THERMO-X Engine</span>
            <span className="text-emerald-400 font-mono flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              ONLINE
            </span>
          </div>
          <p className="text-slate-400 text-[10px]">SI Standard Compliant &bull; Streamlit Ready</p>
        </div>
      </aside>
    </>
  );
};
