import React, { useState, useRef, useEffect } from 'react';
import {
  Flame,
  ShieldCheck,
  Cpu,
  Download,
  Menu,
  ChevronDown,
  LayoutDashboard,
  BookOpen,
  Layers,
  Wind,
  SunMedium,
  GitCompare,
  Network,
  CheckCircle2,
  FileCode2,
  Moon,
  Sun,
} from 'lucide-react';
import { AnalysisType } from '../types';

interface HeaderProps {
  currentView: AnalysisType;
  onNavigate?: (view: AnalysisType) => void;
  onToggleSidebar?: () => void;
  onNavigateHome?: () => void;
  theme?: 'dark' | 'light';
  onToggleTheme?: (theme: 'dark' | 'light') => void;
}

interface DropdownItem {
  id: AnalysisType;
  label: string;
  sublabel: string;
  icon: React.ElementType;
  badge?: string;
  color: string;
}

const dropdownItems: DropdownItem[] = [
  {
    id: 'home',
    label: 'Dashboard',
    sublabel: 'Overview & Thermophysical Constants',
    icon: LayoutDashboard,
    color: 'text-slate-300',
  },
  {
    id: 'how_to_use',
    label: 'How to Use THERMO-X',
    sublabel: '6-Step Engineering Workflow Guide',
    icon: BookOpen,
    badge: '6 STEPS',
    color: 'text-orange-400',
  },
  {
    id: 'conduction',
    label: 'Conduction Analysis',
    sublabel: "Fourier's Law — 1D Solid Plane Wall",
    icon: Layers,
    badge: '1D',
    color: 'text-orange-400',
  },
  {
    id: 'convection',
    label: 'Convection Analysis',
    sublabel: "Newton's Law of Cooling & Fluid Bounds",
    icon: Wind,
    badge: 'h',
    color: 'text-cyan-400',
  },
  {
    id: 'radiation',
    label: 'Radiation Analysis',
    sublabel: 'Stefan-Boltzmann T⁴ Radiation Law',
    icon: SunMedium,
    badge: 'T⁴',
    color: 'text-amber-400',
  },
  {
    id: 'heat_exchanger',
    label: 'Heat Exchanger Analysis',
    sublabel: 'LMTD & ε-NTU Rating Methods',
    icon: GitCompare,
    badge: 'LMTD',
    color: 'text-purple-400',
  },
  {
    id: 'thermal_resistance',
    label: 'Thermal Resistance Network',
    sublabel: 'Series Composite Layers & Interfaces',
    icon: Network,
    badge: 'ΣR',
    color: 'text-emerald-400',
  },
  {
    id: 'verification',
    label: 'Validation Test Suite',
    sublabel: 'Benchmark Physical Assertions & Checks',
    icon: CheckCircle2,
    badge: 'TEST',
    color: 'text-emerald-400',
  },
  {
    id: 'python_repo',
    label: 'Python Repo & Docs',
    sublabel: 'app.py & Streamlit Cloud Code',
    icon: FileCode2,
    badge: 'PY',
    color: 'text-cyan-400',
  },
];

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onNavigate,
  onToggleSidebar,
  onNavigateHome,
  theme = 'dark',
  onToggleTheme,
}) => {
  const [dropdownOpen, setDropdownOpen] = useState<boolean>(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const handleNav = (view: AnalysisType) => {
    if (onNavigate) onNavigate(view);
    else if (view === 'home' && onNavigateHome) onNavigateHome();
    setDropdownOpen(false);
  };

  // Close dropdown when clicked outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const activeItem = dropdownItems.find((item) => item.id === currentView) || dropdownItems[0];
  const ActiveIcon = activeItem.icon;

  return (
    <header
      id="thermo-header"
      className="bg-[#0b0f19]/90 backdrop-blur-md text-white border-b border-slate-800/80 sticky top-0 z-50 shadow-lg shadow-black/20"
    >
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2.5 sm:py-3 flex items-center justify-between gap-3">
        {/* Left Branding & Drop Down Button at Top Left */}
        <div className="flex items-center gap-2 sm:gap-3">
          {onToggleSidebar && (
            <button
              id="mobile-sidebar-toggle"
              onClick={onToggleSidebar}
              className="lg:hidden p-2 rounded-xl bg-slate-800/80 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors border border-slate-700/60"
              aria-label="Toggle Navigation Drawer"
            >
              <Menu className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          )}

          {/* Brand Logo Button */}
          <div
            id="brand-logo-button"
            onClick={() => handleNav('home')}
            className="flex items-center gap-2 sm:gap-2.5 cursor-pointer group select-none mr-1"
          >
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-br from-orange-500 via-amber-500 to-red-600 flex items-center justify-center shadow-lg shadow-orange-500/25 ring-1 ring-white/20 group-hover:scale-105 transition-transform duration-200">
              <Flame className="w-4 h-4 sm:w-5 sm:h-5 text-white drop-shadow" />
            </div>
            <div className="hidden sm:block">
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-base sm:text-lg tracking-tight text-white font-sans">
                  THERMO<span className="text-orange-500">-X</span>
                </span>
                <span className="text-[9px] sm:text-[10px] px-1.5 py-0.2 rounded-full bg-orange-500/15 text-orange-400 font-bold border border-orange-500/30 tracking-wider font-mono">
                  PRO SI
                </span>
              </div>
            </div>
          </div>

          {/* Top-Left View Switcher Dropdown Button */}
          <div className="relative" ref={dropdownRef}>
            <button
              id="top-left-dropdown-btn"
              onClick={() => setDropdownOpen((prev) => !prev)}
              className={`flex items-center gap-2 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-xl border text-xs font-semibold transition-all duration-150 shadow-sm ${
                dropdownOpen
                  ? 'bg-slate-800 text-white border-orange-500/60 ring-1 ring-orange-500/30'
                  : 'bg-[#0e1628]/90 hover:bg-slate-800/90 text-slate-200 border-slate-700/80 hover:border-slate-600'
              }`}
              aria-expanded={dropdownOpen}
              aria-label="Select Analysis Module Dropdown"
            >
              <div className={`p-1 rounded-md bg-slate-800 ${activeItem.color}`}>
                <ActiveIcon className="w-3.5 h-3.5" />
              </div>
              <span className="max-w-[110px] sm:max-w-[160px] truncate font-bold text-white text-[11px] sm:text-xs">
                {activeItem.label}
              </span>
              <ChevronDown
                className={`w-3.5 h-3.5 text-slate-400 transition-transform duration-200 ${
                  dropdownOpen ? 'rotate-180 text-orange-400' : ''
                }`}
              />
            </button>

            {/* Drop Down Menu Panel */}
            {dropdownOpen && (
              <div
                id="top-left-dropdown-menu"
                className="absolute left-0 mt-2 w-72 sm:w-80 bg-[#0e1628] rounded-2xl border border-slate-800/90 shadow-2xl shadow-black/80 py-2 z-50 animate-in fade-in zoom-in-95 duration-100 divide-y divide-slate-800/60"
              >
                {/* Theme Mode Switcher Section in Dropdown */}
                <div className="px-3 py-2 bg-slate-900/40">
                  <div className="flex items-center justify-between text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400 mb-1.5 px-0.5">
                    <span>INTERFACE THEME</span>
                    <span className="text-orange-400">
                      {theme === 'light' ? 'WHITE MODE' : 'DARK MODE'}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-slate-950/60 border border-slate-800">
                    <button
                      id="theme-mode-dark-btn"
                      onClick={() => onToggleTheme?.('dark')}
                      className={`flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                        theme === 'dark'
                          ? 'bg-gradient-to-r from-orange-500 to-amber-600 text-white shadow-sm shadow-orange-500/30'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                      }`}
                    >
                      <Moon className="w-3.5 h-3.5" />
                      <span>Dark Mode</span>
                    </button>
                    <button
                      id="theme-mode-light-btn"
                      onClick={() => onToggleTheme?.('light')}
                      className={`flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                        theme === 'light'
                          ? 'bg-gradient-to-r from-orange-500 to-amber-600 text-white shadow-sm shadow-orange-500/30'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                      }`}
                    >
                      <Sun className="w-3.5 h-3.5" />
                      <span>White Mode</span>
                    </button>
                  </div>
                </div>

                <div className="px-3.5 py-1.5 text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
                  <span>SELECT MODULE OR GUIDE</span>
                  <span className="text-orange-400">9 OPTIONS</span>
                </div>

                <div className="py-1 max-h-[75vh] overflow-y-auto space-y-0.5 px-1.5">
                  {dropdownItems.map((item) => {
                    const Icon = item.icon;
                    const isCurrent = item.id === currentView;
                    return (
                      <button
                        key={item.id}
                        id={`dropdown-item-${item.id}`}
                        onClick={() => handleNav(item.id)}
                        className={`w-full text-left px-2.5 py-2 rounded-xl flex items-center gap-2.5 transition-all group ${
                          isCurrent
                            ? 'bg-gradient-to-r from-orange-500/20 via-orange-500/10 to-transparent text-white font-semibold border border-orange-500/40'
                            : 'hover:bg-slate-800/70 text-slate-300 hover:text-white border border-transparent'
                        }`}
                      >
                        <div
                          className={`p-1.5 rounded-lg transition-colors ${
                            isCurrent
                              ? 'bg-orange-500 text-white shadow-sm shadow-orange-500/30'
                              : 'bg-slate-800/90 text-slate-400 group-hover:text-white group-hover:bg-slate-700'
                          }`}
                        >
                          <Icon className="w-4 h-4 shrink-0" />
                        </div>

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between gap-1">
                            <span
                              className={`text-xs truncate ${
                                isCurrent ? 'text-white font-bold' : 'text-slate-200'
                              }`}
                            >
                              {item.label}
                            </span>
                            {item.badge && (
                              <span
                                className={`text-[9px] px-1.5 py-0.2 rounded font-mono font-bold ${
                                  isCurrent
                                    ? 'bg-orange-500/30 text-orange-200 border border-orange-500/40'
                                    : 'bg-slate-800 text-slate-400 border border-slate-700/50'
                                }`}
                              >
                                {item.badge}
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-slate-400 truncate">
                            {item.sublabel}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Status Badges & Quick Action */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          <div className="hidden lg:flex items-center gap-2 text-xs bg-slate-900/80 px-3 py-1.5 rounded-xl border border-slate-800 text-slate-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-mono text-[11px]">SI VALIDATED</span>
          </div>

          <div className="hidden md:flex items-center gap-2 text-xs bg-slate-900/80 px-3 py-1.5 rounded-xl border border-slate-800 text-slate-300">
            <Cpu className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-mono text-[11px]">100% DETERMINISTIC</span>
          </div>

          <button
            id="header-nav-repo"
            onClick={() => handleNav('python_repo')}
            className={`text-xs px-3 sm:px-3.5 py-1.5 rounded-xl font-semibold flex items-center gap-2 transition-all duration-150 ${
              currentView === 'python_repo'
                ? 'bg-orange-600 text-white shadow-lg shadow-orange-600/30 border border-orange-500/50'
                : 'bg-slate-800/90 hover:bg-slate-700 text-slate-200 border border-slate-700 hover:border-slate-600 hover:text-white'
            }`}
          >
            <Download className="w-3.5 h-3.5 text-orange-400" />
            <span className="hidden sm:inline">Python / Streamlit Hub</span>
            <span className="sm:hidden">Code</span>
          </button>
        </div>
      </div>
    </header>
  );
};
