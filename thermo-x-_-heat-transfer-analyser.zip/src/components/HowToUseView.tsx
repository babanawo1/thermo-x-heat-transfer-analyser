import React, { useState } from 'react';
import {
  BookOpen,
  Layers,
  Wind,
  SunMedium,
  GitCompare,
  Network,
  ShieldCheck,
  FileSpreadsheet,
  FileText,
  Sliders,
  TrendingUp,
  Info,
  CheckCircle2,
  ArrowRight,
  Calculator,
  Compass,
  AlertTriangle,
  Flame,
  Download,
  Terminal,
} from 'lucide-react';
import { AnalysisType } from '../types';

interface HowToUseViewProps {
  onNavigate: (view: AnalysisType) => void;
}

export const HowToUseView: React.FC<HowToUseViewProps> = ({ onNavigate }) => {
  const [activeStep, setActiveStep] = useState<number>(1);
  const [testTempC, setTestTempC] = useState<number>(25);

  const steps = [
    {
      num: 1,
      title: 'Select Analysis Type',
      subtitle: 'Pick the relevant thermal mechanism or engineering simulation',
      icon: Compass,
      color: 'text-orange-400',
      borderColor: 'border-orange-500/40',
      bgColor: 'bg-orange-500/10',
    },
    {
      num: 2,
      title: 'Enter Parameters & SI Units',
      subtitle: 'Input verified geometry, temperatures in Kelvin, or choose presets',
      icon: Sliders,
      color: 'text-cyan-400',
      borderColor: 'border-cyan-500/40',
      bgColor: 'bg-cyan-500/10',
    },
    {
      num: 3,
      title: 'Review Results & Validations',
      subtitle: 'Inspect live calculated Q, flux, resistances, and physical checks',
      icon: CheckCircle2,
      color: 'text-emerald-400',
      borderColor: 'border-emerald-500/40',
      bgColor: 'bg-emerald-500/10',
    },
    {
      num: 4,
      title: 'Examine Visual Charts',
      subtitle: 'Explore temperature trajectories, T(x) profiles, and resistance charts',
      icon: TrendingUp,
      color: 'text-purple-400',
      borderColor: 'border-purple-500/40',
      bgColor: 'bg-purple-500/10',
    },
    {
      num: 5,
      title: 'Inspect Equations & Proofs',
      subtitle: 'Review analytical substitutions, assumptions, and engineering definitions',
      icon: Info,
      color: 'text-amber-400',
      borderColor: 'border-amber-500/40',
      bgColor: 'bg-amber-500/10',
    },
    {
      num: 6,
      title: 'Export CSV & PDF Reports',
      subtitle: 'Generate professional reports and download tabular data for submissions',
      icon: Download,
      color: 'text-rose-400',
      borderColor: 'border-rose-500/40',
      bgColor: 'bg-rose-500/10',
    },
  ];

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header Banner */}
      <div className="bg-[#0e1628]/90 rounded-2xl p-5 sm:p-6 border border-slate-800/90 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-orange-400 font-bold text-xs uppercase tracking-wider mb-1">
            <BookOpen className="w-4 h-4 text-orange-400" />
            <span className="font-mono text-[11px]">THERMO-X USER WORKFLOW &bull; 6 STEPS</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
            How to Use THERMO-X
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
            A comprehensive, step-by-step operational guide for conducting engineering-grade heat transfer evaluations, verifying physics, and exporting formal analytical reports.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="how-to-use-quickstart"
            onClick={() => onNavigate('conduction')}
            className="px-4 py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-orange-600/20 border border-orange-400/30 flex items-center gap-1.5 transition-all"
          >
            <span>Start with Step 1</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 6-Step Interactive Timeline Bar */}
      <div className="bg-[#0e1628]/90 rounded-2xl p-4 sm:p-5 border border-slate-800/90 shadow-xl">
        <div className="text-xs font-mono font-bold uppercase text-slate-400 mb-3 px-1 flex items-center justify-between">
          <span>Workflow Roadmap</span>
          <span className="text-orange-400">Step {activeStep} of 6 Selected</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {steps.map((s) => {
            const Icon = s.icon;
            const isSelected = activeStep === s.num;
            return (
              <button
                key={s.num}
                id={`step-nav-btn-${s.num}`}
                onClick={() => setActiveStep(s.num)}
                className={`p-3 rounded-xl text-left border transition-all flex flex-col justify-between ${
                  isSelected
                    ? 'bg-slate-800/90 border-orange-500/80 shadow-md shadow-orange-500/10 ring-1 ring-orange-500/40'
                    : 'bg-[#090d16]/90 border-slate-800/80 hover:border-slate-700 text-slate-400'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span
                    className={`w-6 h-6 rounded-lg flex items-center justify-center font-mono text-xs font-bold ${
                      isSelected
                        ? 'bg-orange-500 text-white shadow-sm shadow-orange-500/40'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {s.num}
                  </span>
                  <Icon className={`w-4 h-4 ${isSelected ? s.color : 'text-slate-500'}`} />
                </div>
                <div className={`text-xs font-bold truncate ${isSelected ? 'text-white' : 'text-slate-300'}`}>
                  {s.title}
                </div>
                <div className="text-[10px] text-slate-500 truncate mt-0.5">
                  Step {s.num}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Detailed Step Breakdown (Showing All 6 Steps with Highlight on Selected) */}
      <div className="space-y-5">
        {/* STEP 1 */}
        <div
          id="guide-step-1"
          className={`bg-[#0e1628]/90 rounded-2xl p-5 sm:p-6 border transition-all ${
            activeStep === 1
              ? 'border-orange-500/60 shadow-xl shadow-orange-500/5 ring-1 ring-orange-500/20'
              : 'border-slate-800/90 shadow-lg'
          }`}
        >
          <div className="flex items-start justify-between gap-4 border-b border-slate-800/80 pb-4 mb-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-orange-500/20 text-orange-400 border border-orange-500/30 flex items-center justify-center font-bold font-mono text-sm">
                1
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                  Step 1: Select Analysis Type
                </h2>
                <p className="text-xs text-slate-400">
                  Choose the physical mode or system configuration suited to your problem.
                </p>
              </div>
            </div>
            <span className="text-[10px] font-mono bg-orange-500/10 text-orange-400 px-2.5 py-1 rounded-lg border border-orange-500/20 hidden sm:inline-block">
              NAVIGATION
            </span>
          </div>

          <div className="space-y-4">
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Use the <strong>Top-Left Dropdown Menu</strong> or the <strong>Left Sidebar Navigation</strong> to switch between the 5 primary thermal disciplines and the automated validation suites:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <div
                onClick={() => onNavigate('conduction')}
                className="p-3.5 bg-[#090d16]/90 rounded-xl border border-slate-800/80 hover:border-orange-500/50 cursor-pointer transition-all group"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2 text-orange-400 font-bold text-xs">
                    <Layers className="w-4 h-4" />
                    <span>Conduction</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500">Fourier 1D</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed mb-2">
                  Solid plane wall conduction with Fourier&apos;s Law: Q = kA(Th - Tc)/L.
                </p>
                <span className="text-[10px] text-orange-400 font-semibold flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                  Launch Conduction &rarr;
                </span>
              </div>

              <div
                onClick={() => onNavigate('convection')}
                className="p-3.5 bg-[#090d16]/90 rounded-xl border border-slate-800/80 hover:border-cyan-500/50 cursor-pointer transition-all group"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs">
                    <Wind className="w-4 h-4" />
                    <span>Convection</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500">Newton&apos;s Law</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed mb-2">
                  Fluid-to-surface heat exchange: Q = hA(Ts - T∞) with auto heating/cooling modes.
                </p>
                <span className="text-[10px] text-cyan-400 font-semibold flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                  Launch Convection &rarr;
                </span>
              </div>

              <div
                onClick={() => onNavigate('radiation')}
                className="p-3.5 bg-[#090d16]/90 rounded-xl border border-slate-800/80 hover:border-amber-500/50 cursor-pointer transition-all group"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
                    <SunMedium className="w-4 h-4" />
                    <span>Radiation</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500">Stefan-Boltzmann</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed mb-2">
                  Fourth-power radiative exchange: Q = εσA(Ts⁴ - Tsurr⁴) with linearized hr.
                </p>
                <span className="text-[10px] text-amber-400 font-semibold flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                  Launch Radiation &rarr;
                </span>
              </div>

              <div
                onClick={() => onNavigate('heat_exchanger')}
                className="p-3.5 bg-[#090d16]/90 rounded-xl border border-slate-800/80 hover:border-purple-500/50 cursor-pointer transition-all group"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2 text-purple-400 font-bold text-xs">
                    <GitCompare className="w-4 h-4" />
                    <span>Heat Exchanger</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500">LMTD / ε-NTU</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed mb-2">
                  Counter-current and parallel flow rating, thermal effectiveness, NTU, and energy balance.
                </p>
                <span className="text-[10px] text-purple-400 font-semibold flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                  Launch Exchanger &rarr;
                </span>
              </div>

              <div
                onClick={() => onNavigate('thermal_resistance')}
                className="p-3.5 bg-[#090d16]/90 rounded-xl border border-slate-800/80 hover:border-emerald-500/50 cursor-pointer transition-all group"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                    <Network className="w-4 h-4" />
                    <span>Thermal Resistance</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500">Series Network</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed mb-2">
                  Series composite solid walls, boundary fluid convection layers, and interface temperatures.
                </p>
                <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                  Launch Network &rarr;
                </span>
              </div>

              <div
                onClick={() => onNavigate('verification')}
                className="p-3.5 bg-[#090d16]/90 rounded-xl border border-slate-800/80 hover:border-emerald-500/50 cursor-pointer transition-all group"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                    <ShieldCheck className="w-4 h-4" />
                    <span>Validation Suite</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500">Unit Tests</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed mb-2">
                  Automated verification benchmarks validating physical bounds and exact solutions.
                </p>
                <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                  Run Benchmarks &rarr;
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* STEP 2 */}
        <div
          id="guide-step-2"
          className={`bg-[#0e1628]/90 rounded-2xl p-5 sm:p-6 border transition-all ${
            activeStep === 2
              ? 'border-cyan-500/60 shadow-xl shadow-cyan-500/5 ring-1 ring-cyan-500/20'
              : 'border-slate-800/90 shadow-lg'
          }`}
        >
          <div className="flex items-start justify-between gap-4 border-b border-slate-800/80 pb-4 mb-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 flex items-center justify-center font-bold font-mono text-sm">
                2
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                  Step 2: Enter Operating Parameters (SI Units)
                </h2>
                <p className="text-xs text-slate-400">
                  Configure numerical values in standard SI units or load verified material presets.
                </p>
              </div>
            </div>
            <span className="text-[10px] font-mono bg-cyan-500/10 text-cyan-400 px-2.5 py-1 rounded-lg border border-cyan-500/20 hidden sm:inline-block">
              INPUTS & PRESETS
            </span>
          </div>

          <div className="space-y-4 text-xs text-slate-300 leading-relaxed">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-[#090d16]/90 rounded-xl border border-slate-800/80 space-y-2">
                <h3 className="font-bold text-white text-xs flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Standard SI Unit Conventions</span>
                </h3>
                <ul className="space-y-1.5 text-slate-400 font-mono text-[11px]">
                  <li>&bull; <strong className="text-slate-200">Temperature (T)</strong>: Kelvin [K] (K = °C + 273.15)</li>
                  <li>&bull; <strong className="text-slate-200">Thermal Conductivity (k)</strong>: [W/m&middot;K]</li>
                  <li>&bull; <strong className="text-slate-200">Heat Transfer Coeff (h)</strong>: [W/m&sup2;&middot;K]</li>
                  <li>&bull; <strong className="text-slate-200">Area (A) &amp; Thickness (L)</strong>: [m&sup2;] and [m]</li>
                  <li>&bull; <strong className="text-slate-200">Mass Flow Rate (m&#775;)</strong>: [kg/s]</li>
                  <li>&bull; <strong className="text-slate-200">Specific Heat (Cp)</strong>: [J/kg&middot;K]</li>
                </ul>
              </div>

              {/* Interactive Mini Kelvin Converter */}
              <div className="p-4 bg-[#090d16]/90 rounded-xl border border-slate-800/80 space-y-3">
                <h3 className="font-bold text-white text-xs flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Calculator className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Quick Temperature Scale Reference</span>
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">T [K] = T [°C] + 273.15</span>
                </h3>

                <div className="flex items-center gap-3">
                  <div className="flex-1">
                    <label className="block text-[10px] font-semibold text-slate-400 mb-1">Enter Celsius (°C):</label>
                    <input
                      type="number"
                      value={testTempC}
                      onChange={(e) => setTestTempC(parseFloat(e.target.value) || 0)}
                      className="w-full bg-[#0e1628] border border-slate-700/80 rounded-lg px-2.5 py-1 text-xs font-mono text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                    />
                  </div>
                  <div className="flex items-center justify-center pt-4 text-slate-500 font-bold">&rarr;</div>
                  <div className="flex-1">
                    <label className="block text-[10px] font-semibold text-slate-400 mb-1">Result in Kelvin (K):</label>
                    <div className="w-full bg-[#0e1628] border border-cyan-500/40 rounded-lg px-2.5 py-1 text-xs font-mono text-cyan-300 font-bold">
                      {(testTempC + 273.15).toFixed(2)} K
                    </div>
                  </div>
                </div>
                <p className="text-[10px] text-slate-500">
                  Every calculator shows live Celsius conversions below the Kelvin input fields for intuitive reference.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* STEP 3 */}
        <div
          id="guide-step-3"
          className={`bg-[#0e1628]/90 rounded-2xl p-5 sm:p-6 border transition-all ${
            activeStep === 3
              ? 'border-emerald-500/60 shadow-xl shadow-emerald-500/5 ring-1 ring-emerald-500/20'
              : 'border-slate-800/90 shadow-lg'
          }`}
        >
          <div className="flex items-start justify-between gap-4 border-b border-slate-800/80 pb-4 mb-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold font-mono text-sm">
                3
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                  Step 3: Review Results &amp; Real-Time Validations
                </h2>
                <p className="text-xs text-slate-400">
                  Instant auto-computation of primary metrics with automatic Second Law &amp; physical safety checks.
                </p>
              </div>
            </div>
            <span className="text-[10px] font-mono bg-emerald-500/10 text-emerald-400 px-2.5 py-1 rounded-lg border border-emerald-500/20 hidden sm:inline-block">
              PHYSICS GUARDS
            </span>
          </div>

          <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
            <p>
              As you type, the calculation engine instantly recomputes all governing equations and checks physical validity:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-[11px]">
              <div className="p-3 bg-[#090d16]/90 rounded-xl border border-emerald-500/30 space-y-1">
                <div className="font-bold text-emerald-400 font-sans text-xs flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Directional Heat Flow</span>
                </div>
                <p className="text-slate-400 font-sans text-[11px]">
                  Detects heating vs cooling modes; validates that heat naturally flows from higher to lower temperature.
                </p>
              </div>

              <div className="p-3 bg-[#090d16]/90 rounded-xl border border-amber-500/30 space-y-1">
                <div className="font-bold text-amber-400 font-sans text-xs flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Boundary &amp; Zero Guards</span>
                </div>
                <p className="text-slate-400 font-sans text-[11px]">
                  Warns on T &lt; 0 K (absolute zero breach), non-positive areas (A &le; 0), or zero wall thickness (L &le; 0).
                </p>
              </div>

              <div className="p-3 bg-[#090d16]/90 rounded-xl border border-purple-500/30 space-y-1">
                <div className="font-bold text-purple-400 font-sans text-xs flex items-center gap-1.5">
                  <GitCompare className="w-3.5 h-3.5" />
                  <span>Energy Balance Checks</span>
                </div>
                <p className="text-slate-400 font-sans text-[11px]">
                  Validates |Q_hot - Q_cold| discrepancy in heat exchangers and alerts if temperature crossover occurs.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* STEP 4 */}
        <div
          id="guide-step-4"
          className={`bg-[#0e1628]/90 rounded-2xl p-5 sm:p-6 border transition-all ${
            activeStep === 4
              ? 'border-purple-500/60 shadow-xl shadow-purple-500/5 ring-1 ring-purple-500/20'
              : 'border-slate-800/90 shadow-lg'
          }`}
        >
          <div className="flex items-start justify-between gap-4 border-b border-slate-800/80 pb-4 mb-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30 flex items-center justify-center font-bold font-mono text-sm">
                4
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                  Step 4: Examine Visual Charts &amp; Spatial Profiles
                </h2>
                <p className="text-xs text-slate-400">
                  Interactive graphs illustrate temperature fields, thermal trajectories, and sensitivity sweeps.
                </p>
              </div>
            </div>
            <span className="text-[10px] font-mono bg-purple-500/10 text-purple-400 px-2.5 py-1 rounded-lg border border-purple-500/20 hidden sm:inline-block">
              VISUALIZATION
            </span>
          </div>

          <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
            <p>
              Every module features dedicated, interactive vector visualizers rendered with high-contrast color palettes:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              <div className="p-3.5 bg-[#090d16]/90 rounded-xl border border-slate-800/80 space-y-1.5">
                <h3 className="font-bold text-purple-400 text-xs flex items-center gap-1.5">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>1D Spatial Temperature Profile T(x)</span>
                </h3>
                <p className="text-slate-400 text-[11px]">
                  In <strong>Conduction</strong>, observe the linear temperature gradient dT/dx plotted across the wall thickness from x = 0 (T_hot) to x = L (T_cold).
                </p>
              </div>

              <div className="p-3.5 bg-[#090d16]/90 rounded-xl border border-slate-800/80 space-y-1.5">
                <h3 className="font-bold text-cyan-400 text-xs flex items-center gap-1.5">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>Axial Exchanger Trajectories</span>
                </h3>
                <p className="text-slate-400 text-[11px]">
                  In <strong>Heat Exchangers</strong>, compare hot stream T_h(x) and cold stream T_c(x) trajectories for both Counter-Current and Parallel Flow configurations.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* STEP 5 */}
        <div
          id="guide-step-5"
          className={`bg-[#0e1628]/90 rounded-2xl p-5 sm:p-6 border transition-all ${
            activeStep === 5
              ? 'border-amber-500/60 shadow-xl shadow-amber-500/5 ring-1 ring-amber-500/20'
              : 'border-slate-800/90 shadow-lg'
          }`}
        >
          <div className="flex items-start justify-between gap-4 border-b border-slate-800/80 pb-4 mb-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-bold font-mono text-sm">
                5
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                  Step 5: Inspect Equations &amp; Step-by-Step Proofs
                </h2>
                <p className="text-xs text-slate-400">
                  Full mathematical transparency: formula, numerical substitutions, and assumptions.
                </p>
              </div>
            </div>
            <span className="text-[10px] font-mono bg-amber-500/10 text-amber-400 px-2.5 py-1 rounded-lg border border-amber-500/20 hidden sm:inline-block">
              TRANSPARENCY
            </span>
          </div>

          <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
            <p>
              Under each calculation panel, an <strong>Engineering Calculation Breakdown</strong> panel provides 3 clear sections:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-[11px]">
              <div className="p-3 bg-[#090d16]/90 rounded-xl border border-slate-800/80">
                <div className="font-bold text-slate-200 font-sans text-xs mb-1">1. Governing Equations</div>
                <div className="text-slate-400">Pure analytical formulation with symbolic parameters.</div>
              </div>
              <div className="p-3 bg-[#090d16]/90 rounded-xl border border-slate-800/80">
                <div className="font-bold text-slate-200 font-sans text-xs mb-1">2. Numerical Substitution</div>
                <div className="text-slate-400">Your exact numerical values substituted step-by-step into the formula.</div>
              </div>
              <div className="p-3 bg-[#090d16]/90 rounded-xl border border-amber-500/30">
                <div className="font-bold text-amber-400 font-sans text-xs mb-1">3. Final Output</div>
                <div className="text-amber-300 font-bold">Standard decimal and engineering scientific notation outputs.</div>
              </div>
            </div>
          </div>
        </div>

        {/* STEP 6 */}
        <div
          id="guide-step-6"
          className={`bg-[#0e1628]/90 rounded-2xl p-5 sm:p-6 border transition-all ${
            activeStep === 6
              ? 'border-rose-500/60 shadow-xl shadow-rose-500/5 ring-1 ring-rose-500/20'
              : 'border-slate-800/90 shadow-lg'
          }`}
        >
          <div className="flex items-start justify-between gap-4 border-b border-slate-800/80 pb-4 mb-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center font-bold font-mono text-sm">
                6
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                  Step 6: Export CSV &amp; PDF Engineering Reports
                </h2>
                <p className="text-xs text-slate-400">
                  Generate professional PDF reports or download structured CSV datasets with a single click.
                </p>
              </div>
            </div>
            <span className="text-[10px] font-mono bg-rose-500/10 text-rose-400 px-2.5 py-1 rounded-lg border border-rose-500/20 hidden sm:inline-block">
              REPORTS & EXPORTS
            </span>
          </div>

          <div className="space-y-4 text-xs text-slate-300 leading-relaxed">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 bg-[#090d16]/90 rounded-xl border border-slate-800/80 space-y-2">
                <div className="flex items-center gap-2 text-rose-400 font-bold text-xs">
                  <FileText className="w-4 h-4" />
                  <span>PDF Engineering Report</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Generates a branded, publication-ready PDF document including full calculation tables, operating parameters, SI units, governing equations, mathematical substitutions, physical assumptions, and academic verification notes.
                </p>
              </div>

              <div className="p-4 bg-[#090d16]/90 rounded-xl border border-slate-800/80 space-y-2">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>CSV Raw Data Export</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Downloads a standardized Comma-Separated Values (CSV) file containing all parameter names, SI symbols, numeric values, units, and definitions ready for import into Microsoft Excel, MATLAB, Pandas, or R.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Launch Call-to-Action Bar */}
      <div className="bg-gradient-to-r from-orange-950/30 via-[#0e1628] to-cyan-950/30 rounded-2xl p-6 border border-slate-800/90 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-bold text-white">Ready to begin thermal calculations?</h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Select any calculator from the navigation dropdown above or launch conduction analysis now.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('conduction')}
            className="px-5 py-2.5 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white rounded-xl font-semibold text-xs transition-all shadow-lg shadow-orange-600/20 border border-orange-400/30 flex items-center gap-2"
          >
            <span>Launch Conduction Module</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
