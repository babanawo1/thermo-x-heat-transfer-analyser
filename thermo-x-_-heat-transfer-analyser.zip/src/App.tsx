/**
 * THERMO-X | Heat Transfer Analyser
 * React / TypeScript Web Application Shell
 */

import React, { useState, useEffect } from 'react';
import { AnalysisType } from './types';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { HomeDashboard } from './components/HomeDashboard';
import { HowToUseView } from './components/HowToUseView';
import { ConductionView } from './components/ConductionView';
import { ConvectionView } from './components/ConvectionView';
import { RadiationView } from './components/RadiationView';
import { HeatExchangerView } from './components/HeatExchangerView';
import { ThermalResistanceView } from './components/ThermalResistanceView';
import { VerificationSuite } from './components/VerificationSuite';
import { PythonRepoHub } from './components/PythonRepoHub';

export default function App() {
  const [currentView, setCurrentView] = useState<AnalysisType>('home');
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    try {
      const saved = localStorage.getItem('thermo_theme');
      return saved === 'light' ? 'light' : 'dark';
    } catch {
      return 'dark';
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('thermo_theme', theme);
      document.documentElement.setAttribute('data-theme', theme);
    } catch (e) {
      console.warn('Could not persist theme preference', e);
    }
  }, [theme]);

  const handleToggleTheme = (newTheme: 'dark' | 'light') => {
    setTheme(newTheme);
  };

  const renderActiveView = () => {
    switch (currentView) {
      case 'home':
        return <HomeDashboard onNavigate={(type) => setCurrentView(type)} />;
      case 'how_to_use':
        return <HowToUseView onNavigate={(type) => setCurrentView(type)} />;
      case 'conduction':
        return <ConductionView />;
      case 'convection':
        return <ConvectionView />;
      case 'radiation':
        return <RadiationView />;
      case 'heat_exchanger':
        return <HeatExchangerView />;
      case 'thermal_resistance':
        return <ThermalResistanceView />;
      case 'verification':
        return <VerificationSuite />;
      case 'python_repo':
        return <PythonRepoHub />;
      default:
        return <HomeDashboard onNavigate={(type) => setCurrentView(type)} />;
    }
  };

  return (
    <div
      data-theme={theme}
      className={`min-h-screen ${
        theme === 'light' ? 'bg-[#f8fafc] text-[#0a192f]' : 'bg-[#090D16] text-slate-100'
      } flex flex-col font-sans antialiased selection:bg-orange-500 selection:text-white transition-colors duration-200`}
    >
      {/* Top Application Header */}
      <Header
        currentView={currentView}
        theme={theme}
        onToggleTheme={handleToggleTheme}
        onToggleSidebar={() => setSidebarOpen((prev) => !prev)}
        onNavigate={(view) => {
          setCurrentView(view);
          setSidebarOpen(false);
        }}
        onNavigateHome={() => {
          setCurrentView('home');
          setSidebarOpen(false);
        }}
      />

      {/* Main Workspace Layout */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Navigation Sidebar */}
        <Sidebar
          currentView={currentView}
          onSelectView={(view) => {
            setCurrentView(view);
            setSidebarOpen(false);
          }}
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
        />

        {/* Dynamic Content View Area */}
        <main className="flex-1 p-3 sm:p-5 lg:p-7 overflow-y-auto max-w-7xl w-full mx-auto">
          {renderActiveView()}
        </main>
      </div>

      {/* Bottom Status / Footer */}
      <footer className="bg-[#0b0f19]/90 border-t border-slate-800/80 py-2.5 px-6 text-center text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-2 z-30">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span className="font-semibold text-slate-200">THERMO-X Engine</span>
          <span className="text-slate-400 font-mono text-[11px]">| SI-Compliant Physics</span>
        </div>
        <div className="text-[11px] text-slate-400 font-medium">
          Conduction &bull; Convection &bull; Radiation &bull; Heat Exchangers &bull; Resistance Networks &bull; Streamlit Cloud
        </div>
      </footer>
    </div>
  );
}

